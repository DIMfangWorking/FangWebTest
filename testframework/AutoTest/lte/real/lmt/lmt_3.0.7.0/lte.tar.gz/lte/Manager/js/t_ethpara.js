$(function(){

	//表单校验
	var isNum=/^\d+$/;
	var isMac=/^[0-9A-Fa-f]{2}$/;
	$("#submit_add").click(function(){
		//转移值
		var au8Mac1 = $("#au8Mac1").val()+"";
		var au8Mac2 = $("#au8Mac2").val()+"";
		var au8Mac3 = $("#au8Mac3").val()+"";
		var au8Mac4 = $("#au8Mac4").val()+"";
		var au8Mac5 = $("#au8Mac5").val()+"";
		var au8Mac6 = $("#au8Mac6").val()+"";
		
		var sr = au8Mac1+au8Mac2+au8Mac3+au8Mac4+au8Mac5+au8Mac6;
		$("#au8Mac").val(sr);
			
		var index = 0;
		if(!(isNum.test($("#u8PortID").val()) && $("#u8PortID").val()<=6  && $("#u8PortID").val()>=0)){
			$("#u8PortIDError").text("/* 请输入0~6之间的整数 */");
			index++;
		}else{
			$("#u8PortIDError").text("");
		}
		if(!(isNum.test($("#u32RsvBdWidth").val()) && $("#u32RsvBdWidth").val()<=65535 && $("#u32RsvBdWidth").val()>=0)){
			$("#u32RsvBdWidthError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u32RsvBdWidthError").text("");
		}
		if(!(isNum.test($("#u32FdBdWidth").val()) && $("#u32FdBdWidth").val()<=65535  && $("#u32FdBdWidth").val()>=0)){
			$("#u32FdBdWidthError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u32FdBdWidthError").text("");
		}
		if($("#u8RackNO option").length<1){
			$("#u8RackNOError").text("/* 没有可用的机架号选项 */");
			index++;
		}else{
			$("#u8RackNOError").text("");
		}
		if($("#u8ShelfNO option").length<1){
			$("#u8ShelfNOError").text("/* 没有可用的机框号选项 */");
			index++;
		}else{
			$("#u8ShelfNOError").text("");
		}
		if($("#u8SlotNO option").length<1){
			$("#u8SlotNOError").text("/* 没有可用的槽位号选项 */");
			index++;
		}else{
			$("#u8SlotNOError").text("");
		}
		if(!(isNum.test($("#u8EthPort").val()) && $("#u8EthPort").val()<=255  && $("#u8EthPort").val()>=0)){
			$("#u8EthPortError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8EthPortError").text("");
		}
		if(!(isMac.test($("#au8Mac1").val())&&isMac.test($("#au8Mac2").val())&&isMac.test($("#au8Mac3").val())&&isMac.test($("#au8Mac4").val())&&isMac.test($("#au8Mac5").val())&&isMac.test($("#au8Mac6").val()))){
			$("#au8Mac1Error").text("/* 请输入正确的物理地址 */");	
			index++;
		}else{
			$("#au8Mac1Error").text("");	
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_ethpara tr").each(function(index){
		//u8WorkMode
		//u8ManualOP
		if($("#t_ethpara tr:eq("+index+") td:eq(11)").text() == 0){
			$("#t_ethpara tr:eq("+index+") td:eq(11)").text("解闭塞");
		}else{
			$("#t_ethpara tr:eq("+index+") td:eq(11)").text("闭塞");
		}	
		//u32Status
		if($("#t_ethpara tr:eq("+index+") td:eq(12)").text() == 0){
			$("#t_ethpara tr:eq("+index+") td:eq(12)").text("正常");
		}else{
			$("#t_ethpara tr:eq("+index+") td:eq(12)").text("不正常");
		}
		//au8Mac//query
		var au8Mac = $("#t_ethpara tr:eq("+index+") td:eq(10)").text().split("");
		var str1 = au8Mac[0] + au8Mac[1] + "" ;
		var str2 = au8Mac[2] + au8Mac[3] + "";
		var str3 = au8Mac[4] + au8Mac[5] + "";
		var str4 = au8Mac[6] + au8Mac[7] + "";
		var str5 = au8Mac[8] + au8Mac[9] + "";
		var str6 = au8Mac[10] + au8Mac[11] + "";
		var result = str1 + "-" + str2 + "-" + str3 + "-" + str4 + "-" + str5 + "-" + str6;
		$("#t_ethpara tr:eq("+index+") td:eq(10)").text(result);	
	});	
	$("#t_ethpara td.u8PortWorkType").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("自适应");
			break;
		case "1":
			$(this).text("电口");
			break;
		case "2":
			$(this).text("光口");
			break;
		}	
	});
	$("#t_ethpara td.u8ElecWorkMode").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("自协商");
			break;
		case "1":
			$(this).text("10M全双工");
			break;
		case "2":
			$(this).text("100M全双工");
			break;
		case "3":
			$(this).text("1000M全双工");
			break;
		}	
	});
	$("#t_ethpara td.u8OptiWorkMode").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("1000M全双工");
			break;
		}	
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_ethpara"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_ethpara tr").each(function(index){
		$("#t_ethpara tr:eq("+index+") td:eq(14)").click(function(){
			var u8PortID = $("#t_ethpara tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_ethpara&u8PortID="+u8PortID+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_ethpara input[type=checkbox]").each(function(index){
			if($("#t_ethpara input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_ethpara tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_ethpara&u8PortID="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_ethpara"
	});
});