$(function(){ 	
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8Indx").val()) && $("#u8Indx").val()<=99  && $("#u8Indx").val()>=0)){
			$("#u8IndxError").text("/* 请输入0~99之间的整数 */");
			index++;
		}else{ 
			$("#u8IndxError").text("");
		}
		if(!(isNum.test($("#u32AlarmID").val()) && $("#u32AlarmID").val()<=5000  && $("#u32AlarmID").val()>=1)){
			$("#u32AlarmIDError").text("/* 请输入1~5000之间的整数 */");
			index++;
		}else{
			$("#u32AlarmIDError").text("");
		}
		if(!(isNum.test($("#u8FaultCode").val()) && $("#u8FaultCode").val()<=255  && $("#u8FaultCode").val()>=0)){
			$("#u8FaultCodeError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8FaultCodeError").text("");
		}
		if(!(isNum.test($("#u32ReportDelayTime").val()) && $("#u32ReportDelayTime").val()<=31536000  && $("#u32ReportDelayTime").val()>=0)){
			$("#u32ReportDelayTimeError").text("/* 请输入0~31536000之间的整数 */");
			index++;
		}else{
			$("#u32ReportDelayTimeError").text("");
		}
		if(!(isNum.test($("#u32MaxJitterTimes").val()) && $("#u32MaxJitterTimes").val()<=31536000  && $("#u32MaxJitterTimes").val()>=1)){
			$("#u32MaxJitterTimesError").text("/* 请输入1~31536000之间的整数 */");
			index++;
		}else{
			$("#u32MaxJitterTimesError").text("");
		}
		if(!(isNum.test($("#u32RecoverDelayTime").val()) && $("#u32RecoverDelayTime").val()<=31536000  && $("#u32RecoverDelayTime").val()>=0)){
			$("#u32RecoverDelayTimeError").text("/* 请输入0~31536000之间的整数 */");
			index++;
		}else{
			$("#u32RecoverDelayTimeError").text("");
		}
		if(!(isNum.test($("#u32RestDelayTime").val()) && $("#u32RestDelayTime").val()<=31536000  && $("#u32RestDelayTime").val()>=0)){
			$("#u32RestDelayTimeError").text("/* 请输入0~31536000之间的整数 */");
			index++;
		}else{
			$("#u32RestDelayTimeError").text("");
		}
		if(!(isNum.test($("#u32DetIntervalTime").val()) && $("#u32DetIntervalTime").val()<=86400  && $("#u32DetIntervalTime").val()>=0)){
			$("#u32DetIntervalTimeError").text("/* 请输入0~86400之间的整数 */");
			index++;
		}else{
			$("#u32DetIntervalTimeError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_alarm_para"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});	
	//删除
	$("#t_alarm_para tr").each(function(index){
		$("#t_alarm_para tr:eq("+index+") td:eq(9)").click(function(){
			var u8Indx = $("#t_alarm_para tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href="lteBts?operationType=delete&target=single&tableName=t_alarm_para&u8Indx="+u8Indx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_alarm_para input[type=checkbox]").each(function(index){
			if($("#t_alarm_para input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_alarm_para tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_alarm_para&u8Indx="+str+"";
			}
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_alarm_para"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_alarm_para"
	});
});