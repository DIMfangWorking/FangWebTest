$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	$("#submit_add").click(function(){
		if($("#u8BearerType").val()==1){
			if($("#cocoType").val() == "insert"){
				$("#cocoTarget").val("insert1");	
			}else{
				$("#cocoTarget").val("update1");
			}	
			var index = 0;
			if(!(isNum.test($("#u32MaxBitRate").val()) && $("#u32MaxBitRate").val()<=1250000  && $("#u32MaxBitRate").val()>=0)){
				$("#u32MaxBitRateError").text("/* 请输入0~1250000之间的整数 */");
				index++;
			}else{
				$("#u32MaxBitRateError").text("");
			}
			if(!(isNum.test($("#u32PBR").val()) && $("#u32PBR").val()<=1250000  && $("#u32PBR").val()>=0)){
				$("#u32PBRError").text("/* 请输入0~1250000之间的整数 */");
				index++;
			}else{
				$("#u32PBRError").text("");
			}	
			if(!(isNum.test($("#u8SrvMacCfgIdx").val()) && $("#u8SrvMacCfgIdx").val()<=255  && $("#u8SrvMacCfgIdx").val()>=0)){
				$("#u8SrvMacCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvMacCfgIdxError").text("");
			}	
			if(!(isNum.test($("#u8SrvPcCfgIdx").val()) && $("#u8SrvPcCfgIdx").val()<=255  && $("#u8SrvPcCfgIdx").val()>=0)){
				$("#u8SrvPcCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvPcCfgIdxError").text("");
			}
			if(!(isNum.test($("#u8SrvPDCPCfgIdx").val()) && $("#u8SrvPDCPCfgIdx").val()<=255  && $("#u8SrvPDCPCfgIdx").val()>=0)){
				$("#u8SrvPDCPCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvPDCPCfgIdxError").text("");
			}
			if(!(isNum.test($("#u8SrvRLCCfgIdx").val()) && $("#u8SrvRLCCfgIdx").val()<=255  && $("#u8SrvRLCCfgIdx").val()>=0)){
				$("#u8SrvRLCCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvRLCCfgIdxError").text("");
			}
			if(index==0){
				$("#form_add").submit();	
			}
		}else{
			if($("#cocoType").val() == "insert"){
				$("#cocoTarget").val("insert2");	
			}else{
				$("#cocoTarget").val("update2");
			}	
			var index = 0;
			if(!(isNum.test($("#u32MaxBitRate").val()) && $("#u32MaxBitRate").val()<=1250000  && $("#u32MaxBitRate").val()>=0)){
				$("#u32MaxBitRateError").text("/* 请输入0~1250000之间的整数 */");
				index++;
			}else{
				$("#u32MaxBitRateError").text("");
			}
			if(!(isNum.test($("#u8SrvMacCfgIdx").val()) && $("#u8SrvMacCfgIdx").val()<=255  && $("#u8SrvMacCfgIdx").val()>=0)){
				$("#u8SrvMacCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvMacCfgIdxError").text("");
			}	
			if(!(isNum.test($("#u8SrvPcCfgIdx").val()) && $("#u8SrvPcCfgIdx").val()<=255  && $("#u8SrvPcCfgIdx").val()>=0)){
				$("#u8SrvPcCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvPcCfgIdxError").text("");
			}
			if(!(isNum.test($("#u8SrvPDCPCfgIdx").val()) && $("#u8SrvPDCPCfgIdx").val()<=255  && $("#u8SrvPDCPCfgIdx").val()>=0)){
				$("#u8SrvPDCPCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvPDCPCfgIdxError").text("");
			}
			if(!(isNum.test($("#u8SrvRLCCfgIdx").val()) && $("#u8SrvRLCCfgIdx").val()<=255  && $("#u8SrvRLCCfgIdx").val()>=0)){
				$("#u8SrvRLCCfgIdxError").text("/* 请输入0~255之间的整数 */");
				index++;
			}else{
				$("#u8SrvRLCCfgIdxError").text("");
			}
			if(index==0){
				$("#form_add").submit();	
			}			
		}
		
		
	});
	//内存值转为显示值
	$("#t_enb_srvqos1 tr").each(function(index){
		//
		if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text("上行");
		}else{
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text("下行");
		}
		//
		if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == 0){
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text("GBR");
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(2)").text("");
		}else if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == 1){
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text("NGBR");
		}else{
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text("SRB");
			$("#t_enb_srvqos1 tr:eq("+index+") td:eq(2)").text("");
		}
	});	
	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvqos"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_srvqos1 tr").each(function(index){
		$("#t_enb_srvqos1 tr:eq("+index+") td:eq(9)").click(function(){
			var u8BearerType = "";
			if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == "GBR"){
				u8BearerType = 0;	
			}else if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == "NGBR"){
				u8BearerType = 1;
			}else{
				u8BearerType = 2;	
			}
			var u32MaxBitRate = $("#t_enb_srvqos1 tr:eq("+index+") td:eq(1)").text();
			var u8Direction = "";
			if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text() == "上行"){
				u8Direction = 0;
			}else{
				u8Direction = 1;	
			}
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_srvqos&u8BearerType="+u8BearerType+"&u32MaxBitRate="+u32MaxBitRate+"&u8Direction="+u8Direction+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str1=[];var str2=[];var str3=[];
		$("#t_enb_srvqos1 input[type=checkbox]").each(function(index){
			if($("#t_enb_srvqos1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp1 = "";
				if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == "GBR"){
					temp1 = 0;	
				}else if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == "NGBR"){
					temp1 = 1;
				}else if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(0)").text() == "SRB"){
					temp1 = 2;	
				}
				var temp2 = $("#t_enb_srvqos1 tr:eq("+index+") td:eq(1)").text();
				var temp3 = "";
				if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text() == "上行"){
					temp3 = 0;
				}else if($("#t_enb_srvqos1 tr:eq("+index+") td:eq(3)").text() == "下行"){
					temp3 = 1;	
				}
				str1.push(temp1);
				str2.push(temp2);
				str3.push(temp3);
			}
		});	
		/*for(var i=0;i<str1.length;i++){
			if(str1[i]== "" || str1[i]== null){
				str1.splice(i,1);
			}
		}
		for(var i=0;i<str2.length;i++){
			if(str2[i]== "" || str2[i]== null){
				str2.splice(i,1);
			}
		}
		for(var i=0;i<str3.length;i++){
			if(str3[i]== "" || str3[i]== null){
				str3.splice(i,1);
			}
		}*/
		if(str1.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_srvqos&u8BearerType="+str1+"&u32MaxBitRate="+str2+"&u8Direction="+str3+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_srvqos"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvqos"
	});
});