$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8QCI").val()) && $("#u8QCI").val()<=255  && $("#u8QCI").val()>=1)){
			$("#u8QCIError").text("/* 请输入1~255之间的整数 */");
			index++;
		}else{
			$("#u8QCIError").text("");
		}
		if(!(isNum.test($("#u16SrvPacketDelay").val()) && $("#u16SrvPacketDelay").val()<=65535  && $("#u16SrvPacketDelay").val()>=0)){
			$("#u16SrvPacketDelayError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u16SrvPacketDelayError").text("");
		}
		if(!(isNum.test($("#u32SrvPacketLoss").val()) && $("#u32SrvPacketLoss").val()<=1000000  && $("#u32SrvPacketLoss").val()>=0)){
			$("#u32SrvPacketLossError").text("/* 请输入0~1000000之间的整数 */");
			index++;
		}else{
			$("#u32SrvPacketLossError").text("");
		}
		//
		if(!(isNum.test($("#u16RohcMaxCid").val()) && $("#u16RohcMaxCid").val()<=16383  && $("#u16RohcMaxCid").val()>=1)){
			$("#u16RohcMaxCidError").text("/* 请输入1~16383之间的整数 */");
			index++;
		}else{
			$("#u16RohcMaxCidError").text("");
		}
		if(!checkInputInForm(isNum,"u8UPheaderRatio",100,0)){
			index++;
			$("#u8UPheaderRatioError").text(dynamicInfo(10000,generateArgments_i18n_num(100,0)));
		}
		if(!checkInputInForm(isNum,"u8ServiceActiveFactor",10,1)){
			index++;
			$("#u8ServiceActiveFactorError").text(dynamicInfo(10000,generateArgments_i18n_num(10,1)));
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_enb_srvqci tr").each(function(index){
		//					   
		if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 1){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("CVoIP");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 2){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("CLSoIP");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 3){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("RealGaming");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 4){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("BSoIP");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 5){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("IMS Signaling");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 6){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("Prior IP Service");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 7){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("LSoIP");
		}else if($("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text() == 8){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("VIP Default Bearer");
		}else{
			$("#t_enb_srvqci tr:eq("+index+") td:eq(3)").text("NVIP Default Bearer");
		}
		//					   
		if($("#t_enb_srvqci tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(5)").text("GBR");
		}else{
			$("#t_enb_srvqci tr:eq("+index+") td:eq(5)").text("Non-GBR");
		}
		//					   
		if($("#t_enb_srvqci tr:eq("+index+") td:eq(6)").text() == 1){
			$("#t_enb_srvqci tr:eq("+index+") td:eq(6)").text("确认模式");
		}else{
			$("#t_enb_srvqci tr:eq("+index+") td:eq(6)").text("非确认模式");
		}
	});	
	$("#t_enb_srvqci td.u8RohcRTP").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_enb_srvqci td.u8RohcUDP").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_enb_srvqci td.u8RohcIP").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvqci"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_srvqci tr").each(function(index){
		$("#t_enb_srvqci tr:eq("+index+") td:eq(14)").click(function(){
			var u8QCI = $("#t_enb_srvqci tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_srvqci&u8QCI="+u8QCI+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_srvqci input[type=checkbox]").each(function(index){
			if($("#t_enb_srvqci input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_enb_srvqci tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_srvqci&u8QCI="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_srvqci"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvqci"
	});
});