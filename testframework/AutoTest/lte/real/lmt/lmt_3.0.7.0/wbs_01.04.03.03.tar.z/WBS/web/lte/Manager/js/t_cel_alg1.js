$(function(){
		   
		 $(".amcSelect").html(
				'<option value="0">0.05</option>'
				+'<option value="1">0.1</option>'
				+'<option value="2">0.15</option>'
				+'<option value="3">0.2</option>'
				+'<option value="4">0.25</option>'
				+'<option value="5">0.3</option>'
				+'<option value="6">0.35</option>'
				+'<option value="7">0.4</option>'
				+'<option value="8">0.45</option>'
				+'<option value="9">0.5</option>'
				+'<option value="10">0.55</option>'
				+'<option value="11">0.6</option>'
				+'<option value="12">0.65</option>'
				+'<option value="13">0.7</option>'
				+'<option value="14">0.75</option>'
				+'<option value="15">0.8</option>'
				+'<option value="16">0.85</option>'
				+'<option value="17">0.9</option>'
				+'<option value="18">0.95</option>'
				+'<option value="19">1</option>'		 					 
		);
		   
		   //初始化au8UlCebBitmap
		var ulBitMapIndex = 0;	
		var ulBitMapLi = ""
		for(var i = 0 ;i<13;i++){
			var li = "";
			for(var j = 0;j<8;j++){
				li = li+"<input type='checkbox' id='ulBitMapId"+ulBitMapIndex+"' value='"+i+"' class='ulBitMapSon'> </input>"
				ulBitMapIndex++;
			}
			li = "<li>"+li+"<input type = 'checkbox' style='margin-left:20px;' value='"+i+"' class='ulBitMapFather'>全选</li>"
			ulBitMapLi = ulBitMapLi + li
		}
		$("#au8UlCebBitmapUL").html(ulBitMapLi);
		//控制au8UlCebBitmap有效位数
		for(var i = 100 ;i<104;i++){
			$("#ulBitMapId"+i).attr("disabled",true);
		}
		//控制au8UlCebBitmap全选
		$(".ulBitMapFather").live("click",function(){
			var flag = this.checked;
			var value = $(this).val();
			$(".ulBitMapSon").each(function(){
				var sonVal = $(this).val();
				var isEnable = $(this).attr("disabled");
				if(value == sonVal && !isEnable){
					$(this).attr("checked",flag);
				}
			})
		});
		$(".ulBitMapSon").live("click",function(){
			var flag=true;
			var sonVal = $(this).val();
			$(".ulBitMapSon").each(function(){
				var sonValTwo = $(this).val();
				var isEnable = $(this).attr("disabled");
				if(sonValTwo == sonVal && !isEnable){
					if(!this.checked){
						flag=false;
					}
				}				
			})
			$(".ulBitMapFather").each(function(){
				var value = $(this).val();
				if(sonVal == value){
					$(this).attr("checked",flag);
				}
			});
		});
		
		
		//初始化au8DlCebBitmap
		var dlBitMapIndex = 0;	
		var dlBitMapLi = ""
		for(var i = 0 ;i<4;i++){
			var li = "";
			for(var j = 0;j<8;j++){
				li = li+"<input type='checkbox' id='dlBitMapId"+dlBitMapIndex+"' value='"+i+"' class='dlBitMapSon'> </input>"
				dlBitMapIndex++;
			}
			li = "<li>"+li+"<input type = 'checkbox' style='margin-left:20px;' value='"+i+"' class='dlBitMapFather'>全选</li>"
			dlBitMapLi = dlBitMapLi + li
		}
		$("#au8DlCebBitmapUL").html(dlBitMapLi);
		//控制au8DlCebBitmap有效位数
		for(var i = 25 ;i<32;i++){
			$("#dlBitMapId"+i).attr("disabled",true);
		}
		//控制au8DlCebBitmap全选
		$(".dlBitMapFather").live("click",function(){
			var flag = this.checked;
			var value = $(this).val();
			$(".dlBitMapSon").each(function(){
				var sonVal = $(this).val();
				var isEnable = $(this).attr("disabled");
				if(value == sonVal && !isEnable){
					$(this).attr("checked",flag);
				}
			})
		});
		$(".dlBitMapSon").live("click",function(){
			var flag=true;
			var sonVal = $(this).val();
			$(".dlBitMapSon").each(function(){
				var sonValTwo = $(this).val();
				var isEnable = $(this).attr("disabled");
				if(sonValTwo == sonVal && !isEnable){
					if(!this.checked){
						flag=false;
					}
				}				
			})
			$(".dlBitMapFather").each(function(){
				var value = $(this).val();
				if(sonVal == value){
					$(this).attr("checked",flag);
				}
			});
		});
		   
		   
		   
		   
		   
		$("#u8PAForCCU option").each(function(index){
			if($("#u8PAForCCU option:eq("+index+")").val() ==  $("#u8PAForCCUAAA").val() ){
				$("#u8PAForCCU option:eq("+index+")").attr("selected",true);
			}
		});	
		$("#u8PAForCEU option").each(function(index){
			if($("#u8PAForCEU option:eq("+index+")").val() == $("#u8PAForCEUAAA").val()){
				$("#u8PAForCEU option:eq("+index+")").attr("selected",true);
			}
		});	
		$("#u8T0 option").each(function(index){
			if($("#u8T0 option:eq("+index+")").val() == $("#u8T0AAA").val()){
				$("#u8T0 option:eq("+index+")").attr("selected",true);
			}
		});
		$("#u8UlAmcTargetBler option").each(function(index){
			if($("#u8UlAmcTargetBler option:eq("+index+")").val() == $("#u8UlAmcTargetBlerAAA").val()){
				$("#u8UlAmcTargetBler option:eq("+index+")").attr("selected",true);
			}
		});
		$("#u8DlAmcTargetBler option").each(function(index){
			if($("#u8DlAmcTargetBler option:eq("+index+")").val() == $("#u8DlAmcTargetBlerAAA").val()){
				$("#u8DlAmcTargetBler option:eq("+index+")").attr("selected",true);
			}
		});
		$("#u8TS option").each(function(index){
			if($("#u8TS option:eq("+index+")").val() == $("#u8TSAAA").val()){
				$("#u8TS option:eq("+index+")").attr("selected",true);
			}
		});
		$("#u8Cfi option").each(function(index){
			if($("#u8Cfi option:eq("+index+")").val() == $("#u8CfiAAA").val()){
				$("#u8Cfi option:eq("+index+")").attr("selected",true);
			}
		});
		$("#u8CceNum option").each(function(index){
			if($("#u8CceNum option:eq("+index+")").val() == $("#u8CceNumAAA").val()){
				$("#u8CceNum option:eq("+index+")").attr("selected",true);
			}
		});	
		for(var i=1;i<3;i++){
			if($("#radio"+i).val() == $("#b8UlPreSchEnableAAA").val()){
				$("#radio"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioZ"+i).val() == $("#b8DlPreSchEnableAAA").val()){
				$("#radioZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioA"+i).val() == $("#b8DlAmcEnableAAA").val()){
				$("#radioA"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioB"+i).val() == $("#b8UlRbEnableAAA").val()){
				$("#radioB"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioC"+i).val() == $("#b8DlRbEnableAAA").val()){
				$("#radioC"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioD"+i).val() == $("#b8UlAmcEnableAAA").val()){
				$("#radioD"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioUE"+i).val() == $("#b8SingleEnableAAA").val()){
				$("#radioUE"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioRF"+i).val() == $("#b8RlfEnableAAA").val()){
				$("#radioRF"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioPU"+i).val() == $("#b8PucchPcAlgSwitchAAA").val()){
				$("#radioPU"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioTA"+i).val() == $("#b8TAAlgoSwitchAAA").val()){
				$("#radioTA"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSB"+i).val() == $("#b8SibRandSwitchAAA").val()){
				$("#radioSB"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioDlIcic"+i).val() == $("#b8DlIcicSwitchAAA").val()){
				$("#radioDlIcic"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSinrUJ"+i).val() == $("#b8SinrUJSwitchAAA").val()){
				$("#radioSinrUJ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioIcicSwitch"+i).val() == $("#b8UlIcicSwitchAAA").val()){
				$("#radioIcicSwitch"+i).attr("checked","checked");
			}
		}	
		//解析au8DlCebBitmap
		var au8DlCebBitmap = $("#au8DlCebBitmap").val().split("");
		var au8DlCebBitmapLength = au8DlCebBitmap.length;
		var au8DlCebBitmapBin = "";
		for(var i = 0 ; i<au8DlCebBitmapLength;i=i+2){
			var bitHex = au8DlCebBitmap[i]+au8DlCebBitmap[i+1];
			var bitBin = parseInt(bitHex,16).toString(2);
			var bitBinStr = bitBin.split("");
			var bitBinLength = bitBinStr.length;
			for(var j = 0;j<8-bitBinLength;j++){
				bitBin = "0" + bitBin;
			}
			au8DlCebBitmapBin = au8DlCebBitmapBin + bitBin;
		}
		var au8DlCebBitmapBinStr = au8DlCebBitmapBin.split("");
		for(var i = 0;i<25;i++){
			if(au8DlCebBitmapBinStr[i] == "1"){
				$("#dlBitMapId"+i).attr("checked",true);
			}else{
				$("#dlBitMapId"+i).attr("checked",false);
			}		
		}
		
		//解析au8UlCebBitmap
		var au8UlCebBitmap = $("#au8UlCebBitmap").val().split("");
		var au8UlCebBitmapLength = au8UlCebBitmap.length;
		var au8UlCebBitmapBin = "";
		for(var i = 0 ; i<au8UlCebBitmapLength;i=i+2){
			var bitHex = au8UlCebBitmap[i]+au8UlCebBitmap[i+1];
			var bitBin = parseInt(bitHex,16).toString(2);
			var bitBinStr = bitBin.split("");
			var bitBinLength = bitBinStr.length;
			for(var j = 0;j<8-bitBinLength;j++){
				bitBin = "0" + bitBin;
			}
			au8UlCebBitmapBin = au8UlCebBitmapBin + bitBin;
		}
		var au8UlCebBitmapBinStr = au8UlCebBitmapBin.split("");
		for(var i = 0;i<100;i++){
			if(au8UlCebBitmapBinStr[i] == "1"){
				$("#ulBitMapId"+i).attr("checked",true);
			}else{
				$("#ulBitMapId"+i).attr("checked",false);
			}		
		}
		var ab8UlSubfrmFlag1 = $("#ab8UlSubfrmFlagAAA").val();
		var ab8UlSubfrmFlag = ab8UlSubfrmFlag1.split("");
		
		for(var i=1;i<3;i++){
			if($("#radioOne"+i).val() == ab8UlSubfrmFlag[1]){
				$("#radioOne"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioTwo"+i).val() == ab8UlSubfrmFlag[3]){
				$("#radioTwo"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioThree"+i).val() == ab8UlSubfrmFlag[5]){
				$("#radioThree"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioFour"+i).val() == ab8UlSubfrmFlag[7]){
				$("#radioFour"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioFive"+i).val() == ab8UlSubfrmFlag[9]){
				$("#radioFive"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSix"+i).val() == ab8UlSubfrmFlag[11]){
				$("#radioSix"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSeven"+i).val() == ab8UlSubfrmFlag[13]){
				$("#radioSeven"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioEight"+i).val() == ab8UlSubfrmFlag[15]){
				$("#radioEight"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioNine"+i).val() == ab8UlSubfrmFlag[17]){
				$("#radioNine"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioTen"+i).val() == ab8UlSubfrmFlag[19]){
				$("#radioTen"+i).attr("checked","checked");
			}
		}
		var ab8DlSubfrmFlag1 = $("#ab8DlSubfrmFlagAAA").val();
		var ab8DlSubfrmFlag = ab8DlSubfrmFlag1.split("");
		
		for(var i=1;i<3;i++){
			if($("#radioOneZ"+i).val() == ab8DlSubfrmFlag[1]){
				$("#radioOneZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioTwoZ"+i).val() == ab8DlSubfrmFlag[3]){
				$("#radioTwoZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioThreeZ"+i).val() == ab8DlSubfrmFlag[5]){
				$("#radioThreeZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioFourZ"+i).val() == ab8DlSubfrmFlag[7]){
				$("#radioFourZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioFiveZ"+i).val() == ab8DlSubfrmFlag[9]){
				$("#radioFiveZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSixZ"+i).val() == ab8DlSubfrmFlag[11]){
				$("#radioSixZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioSevenZ"+i).val() == ab8DlSubfrmFlag[13]){
				$("#radioSevenZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioEightZ"+i).val() == ab8DlSubfrmFlag[15]){
				$("#radioEightZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioNineZ"+i).val() == ab8DlSubfrmFlag[17]){
				$("#radioNineZ"+i).attr("checked","checked");
			}
		}
		for(var i=1;i<3;i++){
			if($("#radioTenZ"+i).val() == ab8DlSubfrmFlag[19]){
				$("#radioTenZ"+i).attr("checked","checked");
			}
		}
		checkRadio("u8UlHarqComb",$("#u8UlHarqCombAAA").val());
		checkRadio("u8DlHarqComb",$("#u8DlHarqCombAAA").val());
		checkRadio("u8CommSchdCCEAggre",$("#u8CommSchdCCEAggreAAA").val());
		checkRadio("b8DvrbEnable",$("#b8DvrbEnableAAA").val());
		$("#u8UlSchedAlg").val($("#u8UlSchedAlgAAA").val());
		$("#u8DlSchedAlg").val($("#u8DlSchedAlgAAA").val());
		
		
			
});
		function accAdd(arg1,arg2){
			var r1,r2,m;
			try{
				r1 = arg1.toString().split(".")[1].length;	
			}catch(e){
				r1 = 0;	
			}
			try{
				r2 = arg2.toString().split(".")[1].length;	
			}catch(e){
				r2 = 0;	
			}
			m = Math.pow(10,Math.max(r1,r2));
			return (arg1*m + arg2*m)/m;
		}
		function accSub(arg1,arg2){
			var r1,r2,m,n;
			try{
				r1 = arg1.toString().split(".")[1].length;	
			}catch(e){
				r1 = 0;	
			}
			try{
				r2 = arg2.toString().split(".")[1].length;	
			}catch(e){
				r2 = 0;	
			}
			m = Math.pow(10,Math.max(r1,r2));
			n = (r1>=r2)?r1:r2;
			return ((arg1*m - arg2*m)/m).toFixed(n);
		}
		function accMul(arg1,arg2){
			var m = 0;
			var s1 = arg1.toString();
			var s2 = arg2.toString();
			try{
				m += s1.split(".")[1].length	
			}catch(e){}
			try{
				m += s2.split(".")[1].length	
			}catch(e){}
			return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
		}
		function accDiv(arg1,arg2){
			var t1 = 0;
			var t2 = 0;
			var r1,r2;
			try{
				t1 = arg1.toString().split(".")[1].length;
			}catch(e){}
			try{
				t2 = arg2.toString().split(".")[1].length;	
			}catch(e){}
			with(Math){
				r1 = Number(arg1.toString().replace(".",""));
				r2 = Number(arg2.toString().replace(".",""));
				return (r1/r2)*pow(10,t2-t1);
			}
		}