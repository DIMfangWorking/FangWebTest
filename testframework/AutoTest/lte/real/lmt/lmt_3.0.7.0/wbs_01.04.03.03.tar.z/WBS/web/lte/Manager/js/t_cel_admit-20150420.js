$(function(){
	//表单校验
	//整数正则
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8CellId",254,0)){
			index++;
			$("#u8CellIdError").text(dynamicInfo(10000,generateArgments_i18n_num(254,0)));
		}
		if(!checkInputInForm(isNum,"u8MaxPrmtErabNum",5,1)){
			index++;
			$("#u8MaxPrmtErabNumError").text(dynamicInfo(10000,generateArgments_i18n_num(5,1)));
		}
		if(!checkInputInForm(isNum,"u16AdmitMaxUeNum",3600,1)){
			index++;
			$("#u16AdmitMaxUeNumError").text(dynamicInfo(10000,generateArgments_i18n_num(3600,1)));
		}
		if(!checkInputInForm(isNum,"u8AdmitUeMaxErabNum",8,1)){
			index++;
			$("#u8AdmitUeMaxErabNumError").text(dynamicInfo(10000,generateArgments_i18n_num(8,1)));
		}
		if(!checkInputInForm(isNum,"u16AdmitMaxErabNum",2250,1)){
			index++;
			$("#u16AdmitMaxErabNumError").text(dynamicInfo(10000,generateArgments_i18n_num(2250,1)));
		}
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_cel_admit td.u8CongestPrmtType").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("不选择本UE作为强拆对象");
			break;
		case "1":
			$(this).text("优先选择本UE作为强拆对象");
			break;
		}
	});
	$("#t_cel_admit td.b8AdmitSwitch").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_cel_admit td.b8CongestSwitch").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_admit"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_admit"
	});
});

