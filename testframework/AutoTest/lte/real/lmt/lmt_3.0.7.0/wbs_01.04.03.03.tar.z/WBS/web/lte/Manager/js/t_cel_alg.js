$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	var isLit = /^(-)?\d+(\.[0-9]{1}){0,1}$/;
	//精确至0.01的正则
	var isFloatPointTwo = /^-?\d+(\.\d{1,2}){0,1}$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8CId").val()) && $("#u8CId").val()<=254  && $("#u8CId").val()>=0)){
			$("#u8CIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CIdError").text("");
		}
		if(!(isNum.test($("#u8UlRbNum").val()) && $("#u8UlRbNum").val()<=100  && $("#u8UlRbNum").val()>=0)){
			$("#u8UlRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else if(!(     parseInt($("#u8UlRbNum").val())%3 == 0  ||  parseInt($("#u8UlRbNum").val())%5 == 0   ||parseInt($("#u8UlRbNum").val())%2 == 0    )){
			$("#u8UlRbNumError").text("/* 需要可以被2、3、5整除 */");
			index++;
		}else{
			$("#u8UlRbNumError").text("");
		}
		if(!(isNum.test($("#u8DlRbNum").val()) && $("#u8DlRbNum").val()<=100  && $("#u8DlRbNum").val()>=0)){
			$("#u8DlRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else{
			$("#u8DlRbNumError").text("");
		}
		if(!(isNum.test($("#u8UlMaxMcs").val()) && $("#u8UlMaxMcs").val()<=28  && $("#u8UlMaxMcs").val()>=0)){
			$("#u8UlMaxMcsError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8UlMaxMcsError").text("");
		}
		if(!(isNum.test($("#u8UlMinMcs").val()) && $("#u8UlMinMcs").val()<=28  && $("#u8UlMinMcs").val()>=0)){
			$("#u8UlMinMcsError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8UlMinMcsError").text("");
		}
		if(!(isNum.test($("#u8DlMaxMcs").val()) && $("#u8DlMaxMcs").val()<=28  && $("#u8DlMaxMcs").val()>=0)){
			$("#u8DlMaxMcsError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8DlMaxMcsError").text("");
		}
		if(!(isNum.test($("#u8DlMinMcs").val()) && $("#u8DlMinMcs").val()<=28  && $("#u8DlMinMcs").val()>=0)){
			$("#u8DlMinMcsError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8DlMinMcsError").text("");
		}
		if(!(isNum.test($("#u8UlMaxRbNum").val()) && $("#u8UlMaxRbNum").val()<=100  && $("#u8UlMaxRbNum").val()>=0)){
			$("#u8UlMaxRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else if(!(     parseInt($("#u8UlMaxRbNum").val())%3 == 0  ||  parseInt($("#u8UlMaxRbNum").val())%5 == 0   ||parseInt($("#u8UlMaxRbNum").val())%2 == 0    )){
			$("#u8UlMaxRbNumError").text("/* 需要可以被2、3、5整除 */");
			index++;
		}else{
			$("#u8UlMaxRbNumError").text("");
		}
		if(!(isNum.test($("#u8UlMinRbNum").val()) && $("#u8UlMinRbNum").val()<=100  && $("#u8UlMinRbNum").val()>=0)){
			$("#u8UlMinRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else if(!(     parseInt($("#u8UlMinRbNum").val())%3 == 0  ||  parseInt($("#u8UlMinRbNum").val())%5 == 0   ||parseInt($("#u8UlMinRbNum").val())%2 == 0    )){
			$("#u8UlMinRbNumError").text("/* 需要可以被2、3、5整除 */");
			index++;
		}else{
			$("#u8UlMinRbNumError").text("");
		}
		if(!(isNum.test($("#u8DlMaxRbNum").val()) && $("#u8DlMaxRbNum").val()<=100  && $("#u8DlMaxRbNum").val()>=0)){
			$("#u8DlMaxRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else{
			$("#u8DlMaxRbNumError").text("");
		}
		if(!(isNum.test($("#u8DlMinRbNum").val()) && $("#u8DlMinRbNum").val()<=100  && $("#u8DlMinRbNum").val()>=0)){
			$("#u8DlMinRbNumError").text("/* 请输入0~"+100+"之间的整数 */");
			index++;
		}else{
			$("#u8DlMinRbNumError").text("");
		}
		if(!(isNum.test($("#u16RbNiThresh").val()) && $("#u16RbNiThresh").val()<=420  && $("#u16RbNiThresh").val()>=-600)){
			$("#u16RbNiThreshError").text("/* 请输入-600~420之间的整数 */");
			index++;
		}else{
			$("#u16RbNiThreshError").text("");
		}
		var u16RbNiThresh = $("#u16RbNiThresh").val();
		var u16RbNiThresh1 = accAdd(u16RbNiThresh,600);
		$("#u16RbNiThresh1").val(u16RbNiThresh1);
		
		if(!(isNum.test($("#u32AlgReserved").val()) && $("#u32AlgReserved").val()<=4294967295  && $("#u32AlgReserved").val()>=0)){
			$("#u32AlgReservedError").text("/* 请输入0~4294967295之间的整数 */");
			index++;
		}else{
			$("#u32AlgReservedError").text("");
		}
		if(!checkInputInForm(isFloatPointTwo,"u8UlMumimoOrthThresh",1,0)){
			index++;
			$("#u8UlMumimoOrthThreshError").text(dynamicInfo(10002,generateArgments_i18n_num(1,0)));
		}else{
			$("#u8UlMumimoOrthThreshError").text("");
		}
		if(!checkInputInForm(isNum,"u8UlMumimoSinrThresh",20,0)){
			index++;
			$("#u8UlMumimoSinrThreshError").text(dynamicInfo(10000,generateArgments_i18n_num(20,0)));
		}else{
			$("#u8UlMumimoSinrThreshError").text("");
		}
		
		var au8DlCebBitmapBin = "";
		for(var i = 0;i<32;i++){
			if($("#dlBitMapId"+i).attr("checked") == "checked"){
				au8DlCebBitmapBin = au8DlCebBitmapBin + "1";
			}else{
				au8DlCebBitmapBin = au8DlCebBitmapBin + "0";
			}
		}
		var au8DlCebBitmapBinStr = au8DlCebBitmapBin.split("");
		var au8DlCebBitmapBinLength = au8DlCebBitmapBinStr.length;
		var au8DlCebBitmapHex = "";
		for(var i = 0;i<au8DlCebBitmapBinLength;i=i+8){
			var value = "";
			for(var j = 0;j<8;j++){
				value = value + au8DlCebBitmapBinStr[i+j];
			}
			var hexValue = parseInt(value,2).toString(16);
			if(hexValue.length <2){
				hexValue = "0" + hexValue;
			}
			au8DlCebBitmapHex = au8DlCebBitmapHex + hexValue;
		}
		$("#au8DlCebBitmap").val(au8DlCebBitmapHex);
		
		var au8UlCebBitmapBin = "";
		for(var i = 0;i<104;i++){
			if($("#ulBitMapId"+i).attr("checked") == "checked"){
				au8UlCebBitmapBin = au8UlCebBitmapBin + "1";
			}else{
				au8UlCebBitmapBin = au8UlCebBitmapBin + "0";
			}
		}
		var au8UlCebBitmapBinStr = au8UlCebBitmapBin.split("");
		var au8UlCebBitmapBinLength = au8UlCebBitmapBinStr.length;
		var au8UlCebBitmapHex = "";
		for(var i = 0;i<au8UlCebBitmapBinLength;i=i+8){
			var value = "";
			for(var j = 0;j<8;j++){
				value = value + au8UlCebBitmapBinStr[i+j];
			}
			var hexValue = parseInt(value,2).toString(16);
			if(hexValue.length <2){
				hexValue = "0" + hexValue;
			}
			au8UlCebBitmapHex = au8UlCebBitmapHex + hexValue;
		}
		$("#au8UlCebBitmap").val(au8UlCebBitmapHex);
		
		
				
		var ab8UlSubfrmFlag1 = "0"+$("input[name='ab8UlSubfrmFlag1']:checked").val();
		var ab8UlSubfrmFlag2 = "0"+$("input[name='ab8UlSubfrmFlag2']:checked").val();
		var ab8UlSubfrmFlag3 = "0"+$("input[name='ab8UlSubfrmFlag3']:checked").val();
		var ab8UlSubfrmFlag4 = "0"+$("input[name='ab8UlSubfrmFlag4']:checked").val();
		var ab8UlSubfrmFlag5 = "0"+$("input[name='ab8UlSubfrmFlag5']:checked").val();
		var ab8UlSubfrmFlag6 = "0"+$("input[name='ab8UlSubfrmFlag6']:checked").val();
		var ab8UlSubfrmFlag7 = "0"+$("input[name='ab8UlSubfrmFlag7']:checked").val();
		var ab8UlSubfrmFlag8 = "0"+$("input[name='ab8UlSubfrmFlag8']:checked").val();
		var ab8UlSubfrmFlag9 = "0"+$("input[name='ab8UlSubfrmFlag9']:checked").val();
		var ab8UlSubfrmFlag10 = "0"+$("input[name='ab8UlSubfrmFlag10']:checked").val();
		var ab8UlSubfrmFlag = ab8UlSubfrmFlag1 +  ab8UlSubfrmFlag2 +  ab8UlSubfrmFlag3 +  ab8UlSubfrmFlag4 
						+  ab8UlSubfrmFlag5 +  ab8UlSubfrmFlag6 +  ab8UlSubfrmFlag7 +  ab8UlSubfrmFlag8 +  ab8UlSubfrmFlag9 +  ab8UlSubfrmFlag10;
		$("#ab8UlSubfrmFlag").val(ab8UlSubfrmFlag);
		
		var ab8DlSubfrmFlag1 = "0"+$("input[name='ab8DlSubfrmFlag1']:checked").val();
		var ab8DlSubfrmFlag2 = "0"+$("input[name='ab8DlSubfrmFlag2']:checked").val();
		var ab8DlSubfrmFlag3 = "0"+$("input[name='ab8DlSubfrmFlag3']:checked").val();
		var ab8DlSubfrmFlag4 = "0"+$("input[name='ab8DlSubfrmFlag4']:checked").val();
		var ab8DlSubfrmFlag5 = "0"+$("input[name='ab8DlSubfrmFlag5']:checked").val();
		var ab8DlSubfrmFlag6 = "0"+$("input[name='ab8DlSubfrmFlag6']:checked").val();
		var ab8DlSubfrmFlag7 = "0"+$("input[name='ab8DlSubfrmFlag7']:checked").val();
		var ab8DlSubfrmFlag8 = "0"+$("input[name='ab8DlSubfrmFlag8']:checked").val();
		var ab8DlSubfrmFlag9 = "0"+$("input[name='ab8DlSubfrmFlag9']:checked").val();
		var ab8DlSubfrmFlag10 = "0"+$("input[name='ab8DlSubfrmFlag10']:checked").val();
		var ab8DlSubfrmFlag = ab8DlSubfrmFlag1 +  ab8DlSubfrmFlag2 +  ab8DlSubfrmFlag3 +  ab8DlSubfrmFlag4 
						+  ab8DlSubfrmFlag5 +  ab8DlSubfrmFlag6 +  ab8DlSubfrmFlag7 +  ab8DlSubfrmFlag8 +  ab8DlSubfrmFlag9 +  ab8DlSubfrmFlag10;
		$("#ab8DlSubfrmFlag").val(ab8DlSubfrmFlag);
		
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_cel_alg tr").each(function(index){
		// 
		if($("#t_cel_alg tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(1)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(1)").text("开");
		}	
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(2)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(2)").text("开");
		}
		//
		var ab8UlSubfrmFlag = $("#t_cel_alg tr:eq("+index+") td:eq(4)").text().split("");
		var span1 = ab8UlSubfrmFlag[1];
		var span2 = ab8UlSubfrmFlag[3];
		var span3 = ab8UlSubfrmFlag[5];
		var span4 = ab8UlSubfrmFlag[7];
		var span5 = ab8UlSubfrmFlag[9];
		var span6 = ab8UlSubfrmFlag[11];
		var span7 = ab8UlSubfrmFlag[13];
		var span8 = ab8UlSubfrmFlag[15];
		var span9 = ab8UlSubfrmFlag[17];
		var span10 = ab8UlSubfrmFlag[19];
		var spanA1 = "";
		var spanA2 = "";
		var spanA3 = "";
		var spanA4 = "";
		var spanA5 = "";
		var spanA6 = "";
		var spanA7 = "";
		var spanA8 = "";
		var spanA9 = "";
		var spanA10 = "";
		if(span1 == 1){
			spanA1 = "开";	
		}else{
			spanA1 = "关";	
		}
		if(span2 == 1){
			spanA2 = "开";	
		}else{
			spanA2 = "关";	
		}
		if(span3 == 1){
			spanA3 = "开";	
		}else{
			spanA3 = "关";	
		}
		if(span4 == 1){
			spanA4 = "开";	
		}else{
			spanA4 = "关";	
		}
		if(span5 == 1){
			spanA5 = "开";	
		}else{
			spanA5 = "关";	
		}
		if(span6 == 1){
			spanA6 = "开";	
		}else{
			spanA6 = "关";	
		}
		if(span7 == 1){
			spanA7 = "开";	
		}else{
			spanA7 = "关";	
		}
		if(span8 == 1){
			spanA8 = "开";	
		}else{
			spanA8 = "关";	
		}
		if(span9 == 1){
			spanA9 = "开";	
		}else{
			spanA9 = "关";	
		}
		if(span10 == 1){
			spanA10 = "开";	
		}else{
			spanA10 = "关";	
		}
		
		$("#t_cel_alg tr:eq("+index+") td:eq(4)").text(spanA1+" , "+spanA2+" , "+spanA3+" , "+spanA4+" , "+spanA5+" , "+spanA6+" , "+spanA7+" , "+spanA8+" , "+spanA9+" , "+spanA10);
		
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(5)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(5)").text("开");
		}
		//
		var ab8DlSubfrmFlag = $("#t_cel_alg tr:eq("+index+") td:eq(7)").text().split("");
		var spanB1 = ab8DlSubfrmFlag[1];
		var spanB2 = ab8DlSubfrmFlag[3];
		var spanB3 = ab8DlSubfrmFlag[5];
		var spanB4 = ab8DlSubfrmFlag[7];
		var spanB5 = ab8DlSubfrmFlag[9];
		var spanB6 = ab8DlSubfrmFlag[11];
		var spanB7 = ab8DlSubfrmFlag[13];
		var spanB8 = ab8DlSubfrmFlag[15];
		var spanB9 = ab8DlSubfrmFlag[17];
		var spanB10 = ab8DlSubfrmFlag[19];
		var spanBA1 = "";
		var spanBA2 = "";
		var spanBA3 = "";
		var spanBA4 = "";
		var spanBA5 = "";
		var spanBA6 = "";
		var spanBA7 = "";
		var spanBA8 = "";
		var spanBA9 = "";
		var spanBA10 = "";
		if(spanB1 == 1){
			spanBA1 = "开";	
		}else{
			spanBA1 = "关";	
		}
		if(spanB2 == 1){
			spanBA2 = "开";	
		}else{
			spanBA2 = "关";	
		}
		if(spanB3 == 1){
			spanBA3 = "开";	
		}else{
			spanBA3 = "关";	
		}
		if(spanB4 == 1){
			spanBA4 = "开";	
		}else{
			spanBA4 = "关";	
		}
		if(spanB5 == 1){
			spanBA5 = "开";	
		}else{
			spanBA5 = "关";	
		}
		if(spanB6 == 1){
			spanBA6 = "开";	
		}else{
			spanBA6 = "关";	
		}
		if(spanB7 == 1){
			spanBA7 = "开";	
		}else{
			spanBA7 = "关";	
		}
		if(spanB8 == 1){
			spanBA8 = "开";	
		}else{
			spanBA8 = "关";	
		}
		if(spanB9 == 1){
			spanBA9 = "开";	
		}else{
			spanBA9 = "关";	
		}
		if(spanB10 == 1){
			spanBA10 = "开";	
		}else{
			spanBA10 = "关";	
		}
		
		$("#t_cel_alg tr:eq("+index+") td:eq(7)").text(spanBA1+" , "+spanBA2+" , "+spanBA3+" , "+spanBA4+" , "+spanBA5+" , "+spanBA6+" , "+spanBA7+" , "+spanBA8+" , "+spanBA9+" , "+spanBA10);
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(8)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(8)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(8)").text("开");
		}
		if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.05");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.15");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.2");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 4){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.25");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 5){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.3");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 6){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.35");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 7){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.4");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 8){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.45");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 9){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.5");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 10){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.55");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 11){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.6");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 12){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.65");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 13){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.7");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 14){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.75");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 15){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.8");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 16){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.85");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 17){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.9");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(11)").text() == 18){
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("0.95");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(11)").text("1");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(12)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(12)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(12)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(13)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(13)").text("单天线");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(13)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(13)").text("发分集");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(13)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(13)").text("CDD");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(13)").text("自适应");
		}
		if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.05");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.15");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.2");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 4){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.25");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 5){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.3");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 6){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.35");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 7){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.4");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 8){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.45");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 9){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.5");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 10){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.55");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 11){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.6");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 12){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.65");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 13){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.7");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 14){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.75");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 15){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.8");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 16){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.85");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 17){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.9");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(16)").text() == 18){
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("0.95");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(16)").text("1");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(17)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(17)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(17)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(20)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(20)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(20)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(23)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(23)").text("自适应");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(23)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(23)").text("1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(23)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(23)").text("2");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(23)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(23)").text("3");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(23)").text("4");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(24)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(24)").text("聚合度1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(24)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(24)").text("聚合度2");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(24)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(24)").text("聚合度4");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(24)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(24)").text("聚合度8");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(24)").text("自适应");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(25)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(25)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(25)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(26)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(26)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(26)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(27)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(27)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(27)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(28)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(28)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(28)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(29)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(29)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(29)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(30)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(30)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(30)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("1s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("2s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("3s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 4){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("4s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 5){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("5s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 6){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("6s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 7){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("7s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 8){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("8s");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(31)").text() == 9){
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("9s");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(31)").text("10s");
		}
		
		// var au8DlCebBitmap = $("#t_cel_alg tr:eq("+index+") td:eq(32)").text();
		// var au8DlCebBitmapStr = au8DlCebBitmap.split("");
		// var au8DlCebBitmap1 = "";
		// var au8DlCebBitmap2 = "";
		// var au8DlCebBitmap3 = "";
		// var au8DlCebBitmap4 = "";
		// for(var i = 0 ;i<au8DlCebBitmapStr.length;i++){
			// if(i<8){
				// au8DlCebBitmap1 = au8DlCebBitmap1 + au8DlCebBitmapStr[i];
			// }else if( i>=8 && i<16){
				// au8DlCebBitmap2 = au8DlCebBitmap2 + au8DlCebBitmapStr[i];
			// }else if( i>=16 && i<24){
				// au8DlCebBitmap3 = au8DlCebBitmap3 + au8DlCebBitmapStr[i];
			// }else{
				// au8DlCebBitmap4 = au8DlCebBitmap4 + au8DlCebBitmapStr[i];
			// }
		// }
		// var au8DlCebBitmapPrint = parseInt(au8DlCebBitmap1,2).toString(10) + "," + parseInt(au8DlCebBitmap2,2).toString(10) + "," + parseInt(au8DlCebBitmap3,2).toString(10) + "," +parseInt(au8DlCebBitmap4,2).toString(10);
		// $("#t_cel_alg tr:eq("+index+") td:eq(32)").text(au8DlCebBitmapPrint);
		
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("-6");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("-4.77");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("-3");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("-1.77");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 4){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("0");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 5){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(33)").text() == 6){
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("2");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(33)").text("3");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("-6");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("-4.77");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 2){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("-3");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 3){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("-1.77");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 4){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("0");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 5){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("1");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(34)").text() == 6){
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("2");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(34)").text("3");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(35)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(35)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(35)").text("开");
		}
		//
		var u16RbNiThresh = $("#t_cel_alg tr:eq("+index+") td:eq(37)").text();
		var u16RbNiThreshMy = accSub(u16RbNiThresh,600);
		$("#t_cel_alg tr:eq("+index+") td:eq(37)").text(u16RbNiThreshMy);
		//
		// var au8UlCebBitmap = $("#t_cel_alg tr:eq("+index+") td:eq(36)").text();
		// var au8UlCebBitmapStr = au8UlCebBitmap.split("");
		// var au8UlCebBitmapPrint = "";
		// for(var i = 0 ;i<au8UlCebBitmapStr.length ;i=i+8 ){
			// var str = "";
			// for(var j=i ;j<i+8;j++){
				// str = str + au8UlCebBitmapStr[j];
			// }
			// au8UlCebBitmapPrint ="," + au8UlCebBitmapPrint + parseInt(str,2).toString(10)
		// }
		// var au8UlCebBitmapText = au8UlCebBitmapPrint.replace(",","");
		// $("#t_cel_alg tr:eq("+index+") td:eq(36)").text(au8UlCebBitmapText);
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(39)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(39)").text("CC");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(39)").text("IR");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(40)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(40)").text("CC");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(40)").text("IR");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(41)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(41)").text("E_PRIO_MAXTB");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(41)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(41)").text("E_PRIO_RR");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(41)").text("E_PRIO_PF");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(42)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(42)").text("E_PRIO_MAXTB");
		}else if($("#t_cel_alg tr:eq("+index+") td:eq(42)").text() == 1){
			$("#t_cel_alg tr:eq("+index+") td:eq(42)").text("E_PRIO_RR");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(42)").text("E_PRIO_PF");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(43)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(43)").text("聚合度4");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(43)").text("聚合度8");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(44)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(44)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(44)").text("开");
		}
		//
		if($("#t_cel_alg tr:eq("+index+") td:eq(45)").text() == 0){
			$("#t_cel_alg tr:eq("+index+") td:eq(45)").text("关");
		}else{
			$("#t_cel_alg tr:eq("+index+") td:eq(45)").text("开");
		}
	});	
	$("#t_cel_alg td.u8UlMumimoOrthThresh").each(function(){
		var value = $.trim($(this).text());
		$(this).text(accDiv(value,100));
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_alg"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_alg tr").each(function(index){
		$("#t_cel_alg tr:eq("+index+") td:eq(49)").click(function(){
			var u8CId = $("#t_cel_alg tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_alg&u8CId="+u8CId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_cel_alg input[type=checkbox]").each(function(index){
			if($("#t_cel_alg input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_cel_alg tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_alg&u8CId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_alg"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_alg"
	});
	function accAdd(arg1,arg2){
		var r1,r2,m;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		return (arg1*m + arg2*m)/m;
	}
	function accSub(arg1,arg2){
		var r1,r2,m,n;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		n = (r1>=r2)?r1:r2;
		return ((arg1*m - arg2*m)/m).toFixed(n);
	}
	function accMul(arg1,arg2){
		var m = 0;
		var s1 = arg1.toString();
		var s2 = arg2.toString();
		try{
			m += s1.split(".")[1].length	
		}catch(e){}
		try{
			m += s2.split(".")[1].length	
		}catch(e){}
		return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
	}
	function accDiv(arg1,arg2){
		var t1 = 0;
		var t2 = 0;
		var r1,r2;
		try{
			t1 = arg1.toString().split(".")[1].length;
		}catch(e){}
		try{
			t2 = arg2.toString().split(".")[1].length;	
		}catch(e){}
		with(Math){
			r1 = Number(arg1.toString().replace(".",""));
			r2 = Number(arg2.toString().replace(".",""));
			return (r1/r2)*pow(10,t2-t1);
		}
	}	
});