$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	$("#submit_add").click(function(){
		var au8AcBarListSig1 = "0" + $("#au8AcBarListSig1").val();	
		var au8AcBarListSig2 = "0" + $("#au8AcBarListSig2").val();	
		var au8AcBarListSig3 = "0" + $("#au8AcBarListSig3").val();	
		var au8AcBarListSig4 = "0" + $("#au8AcBarListSig4").val();	
		var au8AcBarListSig5 = "0" + $("#au8AcBarListSig5").val();	
		$("#au8AcBarListSig").val(au8AcBarListSig1+au8AcBarListSig2+au8AcBarListSig3+au8AcBarListSig4+au8AcBarListSig5);
		
		var au8AcBarListOrig1 = "0" + $("#au8AcBarListOrig1").val();	
		var au8AcBarListOrig2 = "0" + $("#au8AcBarListOrig2").val();	
		var au8AcBarListOrig3 = "0" + $("#au8AcBarListOrig3").val();	
		var au8AcBarListOrig4 = "0" + $("#au8AcBarListOrig4").val();	
		var au8AcBarListOrig5 = "0" + $("#au8AcBarListOrig5").val();	
		$("#au8AcBarListOrig").val(au8AcBarListOrig1+au8AcBarListOrig2+au8AcBarListOrig3+au8AcBarListOrig4+au8AcBarListOrig5);
		
		var index = 0;
		if(!(isNum.test($("#u8CId").val()) && $("#u8CId").val()<=254  && $("#u8CId").val()>=0)){
			$("#u8CIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CIdError").text("");
		}
		if(!(isNum.test($("#u8SelQrxLevMin").val()) && $("#u8SelQrxLevMin").val()<=-44 && $("#u8SelQrxLevMin").val()>=-140)){
			$("#u8SelQrxLevMinError").text("/* 请输入-140~-44之间的整数 */");
			index++;
		}else if($("#u8SelQrxLevMin").val()%2 !=0){
			$("#u8SelQrxLevMinError").text("/* 请注意步长为2 */");
			index++;
		}else{
			$("#u8SelQrxLevMinError").text("");
		}
		if(!(isNum.test($("#u8SNintraSrch").val()) && $("#u8SNintraSrch").val()<=62 && $("#u8SNintraSrch").val()>=0)){
			$("#u8SNintraSrchError").text("/* 请输入0~62之间的整数 */");
			index++;
		}else if($("#u8SNintraSrch").val()%2 !=0){
			$("#u8SNintraSrchError").text("/* 请注意步长为2 */");
			index++;
		}else{
			$("#u8SNintraSrchError").text("");
		}
		if(!(isNum.test($("#u8ThreshSvrLow").val()) && $("#u8ThreshSvrLow").val()<=62 && $("#u8ThreshSvrLow").val()>=0)){
			$("#u8ThreshSvrLowError").text("/* 请输入0~62之间的整数 */");
			index++;
		}else if($("#u8ThreshSvrLow").val()%2 !=0){
			$("#u8ThreshSvrLowError").text("/* 请注意步长为2 */");
			index++;
		}else{
			$("#u8ThreshSvrLowError").text("");
		}
		if(!(isNum.test($("#u8IntraPmax").val()) && $("#u8IntraPmax").val()<=33  && $("#u8IntraPmax").val()>=-30)){
			$("#u8IntraPmaxError").text("/* 请输入-30~33之间的整数 */");
			index++;
		}else{
			$("#u8IntraPmaxError").text("");
		}
		if(!(isNum.test($("#u8IntraQrxLevMin").val()) && $("#u8IntraQrxLevMin").val()<=-44 && $("#u8IntraQrxLevMin").val()>=-140)){
			$("#u8IntraQrxLevMinError").text("/* 请输入-140~-44之间的整数 */");
			index++;
		}else if($("#u8IntraQrxLevMin").val()%2 !=0){
			$("#u8IntraQrxLevMinError").text("/* 请注意步长为2 */");
			index++;
		}else{
			$("#u8IntraQrxLevMinError").text("");
		}
		if(!(isNum.test($("#u8SIntraSrch").val()) && $("#u8SIntraSrch").val()<=62 && $("#u8SIntraSrch").val()>=0)){
			$("#u8SIntraSrchError").text("/* 请输入0~62之间的整数 */");
			index++;
		}else if($("#u8SIntraSrch").val()%2 !=0){
			$("#u8SIntraSrchError").text("/* 请注意步长为2 */");
			index++;
		}else{
			$("#u8SIntraSrchError").text("");
		}
		if(!(isNum.test($("#u8CellSelQqualMin").val()) && $("#u8CellSelQqualMin").val()<=-3  && $("#u8CellSelQqualMin").val()>=-34)){
			$("#u8CellSelQqualMinError").text("/* 请输入-34~-3之间的整数 */");
			index++;
		}else{
			$("#u8CellSelQqualMinError").text("");
		}
		if(!(isNum.test($("#u8SIntraSrchQ").val()) && $("#u8SIntraSrchQ").val()<=31  && $("#u8SIntraSrchQ").val()>=0)){
			$("#u8SIntraSrchQError").text("/* 请输入0~31之间的整数 */");
			index++;
		}else{
			$("#u8SIntraSrchQError").text("");
		}
		if(!(isNum.test($("#u8SNintraSrchQ").val()) && $("#u8SNintraSrchQ").val()<=31  && $("#u8SNintraSrchQ").val()>=0)){
			$("#u8SNintraSrchQError").text("/* 请输入0~31之间的整数 */");
			index++;
		}else{
			$("#u8SNintraSrchQError").text("");
		}
		if(!(isNum.test($("#u8IntraFreqQqualMin").val()) && $("#u8IntraFreqQqualMin").val()<=-3  && $("#u8IntraFreqQqualMin").val()>=-34)){
			$("#u8IntraFreqQqualMinError").text("/* 请输入-34~-3之间的整数 */");
			index++;
		}else{
			$("#u8IntraFreqQqualMinError").text("");
		}
		if(!(isNum.test($("#u8ThreshSrvLowQ").val()) && $("#u8ThreshSrvLowQ").val()<=31  && $("#u8ThreshSrvLowQ").val()>=0)){
			$("#u8ThreshSrvLowQError").text("/* 请输入0~31之间的整数 */");
			index++;
		}else{
			$("#u8ThreshSrvLowQError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_cel_resel1 tr").each(function(index){
		//				   
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(1)").text("禁止");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(1)").text("允许");
		}	
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(2)").text("是");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(2)").text("否");
		}	
		//
		var u8SelQrxLevMin = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(3)").text());
		var tom = u8SelQrxLevMin*2 - 140;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(3)").text(tom);
		//
		var u8QrxLevMinOfst = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(4)").text());
		var jack = u8QrxLevMinOfst*2;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(4)").text(jack);
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(5)").text("否");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(5)").text("是");
		}
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 1){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.05");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 2){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.1");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 3){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.15");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 4){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.2");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 5){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.25");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 6){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.3");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 7){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.4");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 8){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.5");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 9){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.6");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 10){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.7");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 11){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.75");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 12){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.8");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 13){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.85");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text() == 14){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.9");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(6)").text("0.95");
		}
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("4");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 1){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("8");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 2){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("16");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 3){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("32");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 4){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("64");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 5){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("128");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text() == 6){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("256");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(7)").text("512");
		}
		//
		var au8AcBarListSig = $("#t_cel_resel1 tr:eq("+index+") td:eq(8)").text().split("");
		var au8AcBarListSig1 = "";
		if(parseInt(au8AcBarListSig[1]) == 0){
			au8AcBarListSig1 = "否";
		}else{
			au8AcBarListSig1 = "是";	
		}
		var au8AcBarListSig2 = "";
		if(parseInt(au8AcBarListSig[3]) == 0){
			au8AcBarListSig2 = "否";
		}else{
			au8AcBarListSig2 = "是";	
		}
		var au8AcBarListSig3 = "";
		if(parseInt(au8AcBarListSig[5]) == 0){
			au8AcBarListSig3 = "否";
		}else{
			au8AcBarListSig3 = "是";	
		}
		var au8AcBarListSig4 = "";
		if(parseInt(au8AcBarListSig[7]) == 0){
			au8AcBarListSig4 = "否";
		}else{
			au8AcBarListSig4 = "是";	
		}
		var au8AcBarListSig5 = "";
		if(parseInt(au8AcBarListSig[9]) == 0){
			au8AcBarListSig5 = "否";
		}else{
			au8AcBarListSig5 = "是";	
		}
		$("#t_cel_resel1 tr:eq("+index+") td:eq(8)").text(au8AcBarListSig1 + " , " + au8AcBarListSig2 + " , " + au8AcBarListSig3 + " , "  +au8AcBarListSig4 + " , " + au8AcBarListSig5);
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 1){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.05");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 2){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.1");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 3){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.15");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 4){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.2");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 5){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.25");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 6){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.3");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 7){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.4");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 8){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.5");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 9){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.6");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 10){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.7");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 11){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.75");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 12){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.8");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 13){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.85");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text() == 14){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.9");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(9)").text("0.95");
		}
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("4");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 1){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("8");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 2){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("16");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 3){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("32");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 4){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("64");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 5){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("128");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text() == 6){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("256");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(10)").text("512");
		}
		//
		//
		var au8AcBarListOrig = $("#t_cel_resel1 tr:eq("+index+") td:eq(11)").text().split("");
		var au8AcBarListOrig1 = "";
		if(parseInt(au8AcBarListOrig[1]) == 0){
			au8AcBarListOrig1 = "否";
		}else{
			au8AcBarListOrig1 = "是";	
		}
		var au8AcBarListOrig2 = "";
		if(parseInt(au8AcBarListOrig[3]) == 0){
			au8AcBarListOrig2 = "否";
		}else{
			au8AcBarListOrig2 = "是";	
		}
		var au8AcBarListOrig3 = "";
		if(parseInt(au8AcBarListOrig[5]) == 0){
			au8AcBarListOrig3 = "否";
		}else{
			au8AcBarListOrig3 = "是";	
		}
		var au8AcBarListOrig4 = "";
		if(parseInt(au8AcBarListOrig[7]) == 0){
			au8AcBarListOrig4 = "否";
		}else{
			au8AcBarListOrig4 = "是";	
		}
		var au8AcBarListOrig5 = "";
		if(parseInt(au8AcBarListOrig[9]) == 0){
			au8AcBarListOrig5 = "否";
		}else{
			au8AcBarListOrig5 = "是";	
		}
		$("#t_cel_resel1 tr:eq("+index+") td:eq(11)").text(au8AcBarListOrig1 + " , " + au8AcBarListOrig2 + " , " + au8AcBarListOrig3 + " , "  +au8AcBarListOrig4 + " , " + au8AcBarListOrig5);
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("0");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 1){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("1");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 2){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("2");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 3){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("3");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 4){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("4");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 5){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("5");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 6){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("6");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 7){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("8");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 8){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("10");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 9){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("12");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 10){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("14");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 11){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("16");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 12){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("18");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 13){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("20");
		}else if($("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text() == 14){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("22");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(12)").text("24");
		}
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(13)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(13)").text("否");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(13)").text("是");
		}
		//
		var u8SNintraSrch = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(14)").text());
		var helen = u8SNintraSrch*2;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(14)").text(helen);
		//
		var u8ThreshSvrLow = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(15)").text());
		var may = u8ThreshSvrLow*2;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(15)").text(may);
		//
		var u8IntraPmax = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(16)").text());
		var june = u8IntraPmax-30;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(16)").text(june);
		//
		var u8IntraQrxLevMin = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(18)").text());
		var apirl = u8IntraQrxLevMin*2 -140 ;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(18)").text(apirl);
		//
		if($("#t_cel_resel1 tr:eq("+index+") td:eq(19)").text() == 0){
			$("#t_cel_resel1 tr:eq("+index+") td:eq(19)").text("否");
		}else{
			$("#t_cel_resel1 tr:eq("+index+") td:eq(19)").text("是");
		}
		//
		var u8SIntraSrch = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(20)").text());
		var grep = u8SIntraSrch*2;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(20)").text(grep);
		//
		var u8CellSelQqualMin = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(22)").text());
		var black = u8CellSelQqualMin-34;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(22)").text(black);
		//
		var u8IntraFreqQqualMin = parseInt($("#t_cel_resel1 tr:eq("+index+") td:eq(26)").text());
		var white = u8IntraFreqQqualMin-34;
		$("#t_cel_resel1 tr:eq("+index+") td:eq(26)").text(white);
		
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_resel"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_resel1 tr").each(function(index){
		$("#t_cel_resel1 tr:eq("+index+") td:eq(29)").click(function(){
			var u8CId = $("#t_cel_resel1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_resel&u8CId="+u8CId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_cel_resel1 input[type=checkbox]").each(function(index){
			if($("#t_cel_resel1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_cel_resel1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_resel&u8CId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_resel"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_resel"
	});
});