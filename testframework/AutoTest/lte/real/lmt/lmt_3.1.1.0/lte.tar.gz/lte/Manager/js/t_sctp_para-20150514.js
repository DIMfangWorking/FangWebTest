$(function(){
	//表单校验
	//整数正则
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8Id",255,1)){
			index++;
			$("#u8IdError").text(dynamicInfo(10000,generateArgments_i18n_num(255,1)));
		}
		if(!checkInputInForm(isNum,"u32Hb_interval",86400000,1)){
			index++;
			$("#u32Hb_intervalError").text(dynamicInfo(10000,generateArgments_i18n_num(86400000,1)));
		}
		if(!checkInputInForm(isNum,"u32Assoc_maxretrans",128,1)){
			index++;
			$("#u32Assoc_maxretransError").text(dynamicInfo(10000,generateArgments_i18n_num(128,1)));
		}
		if(!checkInputInForm(isNum,"u32Path_maxretrans",128,1)){
			index++;
			$("#u32Path_maxretransError").text(dynamicInfo(10000,generateArgments_i18n_num(128,1)));
		}
		if(!checkInputInForm(isNum,"u32Rto_initial",60000000,1000)){
			index++;
			$("#u32Rto_initialError").text(dynamicInfo(10000,generateArgments_i18n_num(60000000,1000)));
		}
		if(!checkInputInForm(isNum,"u32Rto_max",60000000,1000)){
			index++;
			$("#u32Rto_maxError").text(dynamicInfo(10000,generateArgments_i18n_num(60000000,1000)));
		}
		if(!checkInputInForm(isNum,"u32Rto_min",60000,500)){
			index++;
			$("#u32Rto_minError").text(dynamicInfo(10000,generateArgments_i18n_num(60000,500)));
		}
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_sctp_para"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_sctp_para"
	});
	$("#t_sctp_para td.u32Assoc_closetype").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("强制关闭");
			break;
		case "1":
			$(this).text("优雅关闭");
			break;
		}	
	});
});

