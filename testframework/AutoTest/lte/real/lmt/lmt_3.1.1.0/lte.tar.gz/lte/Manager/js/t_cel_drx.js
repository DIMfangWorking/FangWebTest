$(function(){
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8CellId").val()) && $("#u8CellId").val()<=254  && $("#u8CellId").val()>=0)){
			$("#u8CellIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CellIdError").text("");
		}
		if(!(isNum.test($("#u8ShortDrxCycleTimer").val()) && $("#u8ShortDrxCycleTimer").val()<=16  && $("#u8ShortDrxCycleTimer").val()>=1)){
			$("#u8ShortDrxCycleTimerError").text("/* 请输入1~16之间的整数 */");
			index++;
		}else{
			$("#u8ShortDrxCycleTimerError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_cel_drx tr").each(function(index){
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(1)").text("关");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(1)").text("开");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf1");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 1){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf2");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 2){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf3");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 3){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf4");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 4){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf5");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 5){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf6");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 6){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf8");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 7){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf10");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 8){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf20");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 9){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf30");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 10){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf40");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 11){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf50");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 12){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf60");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 13){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf80");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(2)").text() == 14){
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf100");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(2)").text("psf200");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf1");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 1){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf2");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 2){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf3");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 3){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf4");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 4){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf5");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 5){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf6");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 6){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf8");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 7){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf10");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 8){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf20");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 9){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf30");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 10){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf40");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 11){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf50");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 12){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf60");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 13){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf80");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 14){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf100");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 15){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf200");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 16){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf300");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 17){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf500");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 18){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf750");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 19){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf1280");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(3)").text() == 20){
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf1920");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(3)").text("psf2560");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf1");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 1){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf2");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 2){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf4");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 3){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf6");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 4){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf8");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 5){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf16");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(4)").text() == 6){
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf24");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(4)").text("psf33");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf10");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 1){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf20");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 2){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf32");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 3){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf40");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 4){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf64");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 5){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf80");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 6){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf128");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 7){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf160");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 8){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf256");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 9){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf320");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 10){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf512");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 11){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf640");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 12){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf1024");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 13){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf1280");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(5)").text() == 14){
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf2048");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(5)").text("sf2560");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(6)").text("关");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(6)").text("开");
		}
		//
		if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf2");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 1){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf5");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 2){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf8");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 3){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf10");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 4){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf16");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 5){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf20");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 6){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf32");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 7){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf40");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 8){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf64");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 9){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf80");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 10){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf128");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 11){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf160");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 12){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf256");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 13){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf320");
		}else if($("#t_cel_drx tr:eq("+index+") td:eq(7)").text() == 14){
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf512");
		}else{
			$("#t_cel_drx tr:eq("+index+") td:eq(7)").text("sf640");
		}
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_drx"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_drx tr").each(function(index){
		$("#t_cel_drx tr:eq("+index+") td:eq(10)").click(function(){
			var u8CellId = $("#t_cel_drx tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_drx&u8CellId="+u8CellId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_cel_drx input[type=checkbox]").each(function(index){
			if($("#t_cel_drx input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_cel_drx tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_drx&u8CellId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_drx"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_drx"
	});
});