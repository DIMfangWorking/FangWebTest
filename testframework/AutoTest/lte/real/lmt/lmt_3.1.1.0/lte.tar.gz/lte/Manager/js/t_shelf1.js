$(function(){
	//联动控制
	
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8ShelfNO").val()) && $("#u8ShelfNO").val()<=255  && $("#u8ShelfNO").val()>=0)){
			$("#u8ShelfNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8ShelfNOError").text("");
		}
		if(!(isNum.test($("#u8ShelfType").val()) && $("#u8ShelfType").val()<=255  && $("#u8ShelfType").val()>=0)){
			$("#u8ShelfTypeError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8ShelfTypeError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_shelf"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_shelf tr").each(function(index){
		$("#t_shelf tr:eq("+index+") td:eq(4)").click(function(){
			var u8RackNO = $("#t_shelf tr:eq("+index+") td:eq(0)").text();
			var u8ShelfNO = $("#t_shelf tr:eq("+index+") td:eq(1)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_shelf&u8RackNO="+u8RackNO+"&u8ShelfNO="+u8ShelfNO+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str1=[];
		var str2=[];
		$("#t_shelf input[type=checkbox]").each(function(index){
			if($("#t_shelf input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp1 = $("#t_shelf tr:eq("+index+") td:eq(0)").text();
				str1.push(temp1);
				var temp2 = $("#t_shelf tr:eq("+index+") td:eq(1)").text();
				str2.push(temp2);
			}
		});	
		for(var i=0;i<str1.length;i++){
			if(str1[i]== "" || str1[i]== null){
				str1.splice(i,1);
			}
		}
		for(var i=0;i<str2.length;i++){
			if(str2[i]== "" || str2[i]== null){
				str2.splice(i,1);
			}
		}
		if(str1.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=multi&tableName=t_shelf&u8RackNO="+str1+"&u8ShelfNO="+str2+"";
			}
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_shelf"
	}); 
	
});