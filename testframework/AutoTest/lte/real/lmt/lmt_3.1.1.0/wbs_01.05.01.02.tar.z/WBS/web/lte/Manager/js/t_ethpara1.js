$(function(){
		var va = $("#au8Mac").val().split("");
		var va1 = va[0] + va[1] + "" ;
		var va2 = va[2] + va[3] + "";
		var va3 = va[4] + va[5] + "";
		var va4 = va[6] + va[7] + "";
		var va5 = va[8] + va[9] + "";
		var va6 = va[10] + va[11] + "";
		$("#au8Mac1").val(va1);
		$("#au8Mac2").val(va2);
		$("#au8Mac3").val(va3);
		$("#au8Mac4").val(va4);
		$("#au8Mac5").val(va5);
		$("#au8Mac6").val(va6);
});