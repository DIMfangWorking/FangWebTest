$(function(){
	var isLit = /^(-)?\d+(\.[0-9]{1,2}){0,1}$/;	   
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		
		var u8PttSpsThrRbNum = $("#u8PttSpsThrRbNum").val();
		var u8PttSpsThrRbNumBig = accMul(u8PttSpsThrRbNum,100);
		$("#u8PttSpsThrRbNumCoco").val(u8PttSpsThrRbNumBig);
		
		
		var index = 0;
		if(!(isNum.test($("#u8CId").val()) && $("#u8CId").val()<=254  && $("#u8CId").val()>=0)){
			$("#u8CIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CIdError").text("");
		}
		if(!(isNum.test($("#u8PttBPagingFN").val()) && $("#u8PttBPagingFN").val()<=127  && $("#u8PttBPagingFN").val()>=0)){
			$("#u8PttBPagingFNError").text("/* 请输入0~127之间的整数 */");
			index++;
		}else{
			$("#u8PttBPagingFNError").text("");
		}
		if(!(isNum.test($("#u8PttBPagingSubFN").val()) && $("#u8PttBPagingSubFN").val()<=9  && $("#u8PttBPagingSubFN").val()>=0)){
			$("#u8PttBPagingSubFNError").text("/* 请输入0~9之间的整数 */");
			index++;
		}else{
			$("#u8PttBPagingSubFNError").text("");
		}
		if(!(isNum.test($("#u8PttSignalMCS").val()) && $("#u8PttSignalMCS").val()<=28  && $("#u8PttSignalMCS").val()>=0)){
			$("#u8PttSignalMCSError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8PttSignalMCSError").text("");
		}
		if(!(isNum.test($("#u8PttDataMCS").val()) && $("#u8PttDataMCS").val()<=28  && $("#u8PttDataMCS").val()>=0)){
			$("#u8PttDataMCSError").text("/* 请输入0~28之间的整数 */");
			index++;
		}else{
			$("#u8PttDataMCSError").text("");
		}
		if(!(isNum.test($("#u16PttCfgSendCycle").val()) && $("#u16PttCfgSendCycle").val()<=2560  && $("#u16PttCfgSendCycle").val()>=128)){
			$("#u16PttCfgSendCycleError").text("/* 请输入128~2560之间的整数 */");
			index++;
		}else{
			$("#u16PttCfgSendCycleError").text("");
		}
		if(!(isNum.test($("#u16PttNbrCfgSendCycle").val()) && $("#u16PttNbrCfgSendCycle").val()<=2560  && $("#u16PttNbrCfgSendCycle").val()>=128)){
			$("#u16PttNbrCfgSendCycleError").text("/* 请输入128~2560之间的整数 */");
			index++;
		}else{
			$("#u16PttNbrCfgSendCycleError").text("");
		}
		if(!(isNum.test($("#u8PttPeriodPagingCycle").val()) && $("#u8PttPeriodPagingCycle").val()<=255  && $("#u8PttPeriodPagingCycle").val()>=1)){
			$("#u8PttPeriodPagingCycleError").text("/* 请输入1~255之间的整数 */");
			index++;
		}else{
			$("#u8PttPeriodPagingCycleError").text("");
		}
		if(!(isLit.test($("#u8PttSpsThrRbNum").val()) && $("#u8PttSpsThrRbNum").val()<=1  && $("#u8PttSpsThrRbNum").val()>=0)){
			$("#u8PttSpsThrRbNumError").text("/* 请输入符合要求的数字 */");
			index++;
		}else{
			$("#u8PttSpsThrRbNumError").text("");
		}
		if(!(isNum.test($("#u8PttDlMaxRbNum").val()) && $("#u8PttDlMaxRbNum").val()<=100  && $("#u8PttDlMaxRbNum").val()>=0)){
			$("#u8PttDlMaxRbNumError").text("/* 请输入0~100之间的整数 */");
			index++;
		}else{
			$("#u8PttDlMaxRbNumError").text("");
		}
		if(!(isNum.test($("#u16PttSpsPackSizeMin").val()) && $("#u16PttSpsPackSizeMin").val()<=500  && $("#u16PttSpsPackSizeMin").val()>=0)){
			$("#u16PttSpsPackSizeMinError").text("/* 请输入0~500之间的整数 */");
			index++;
		}else{
			$("#u16PttSpsPackSizeMinError").text("");
		}
		if(!(isNum.test($("#u16PttSpsPackSizeMax").val()) && $("#u16PttSpsPackSizeMax").val()<=500  && $("#u16PttSpsPackSizeMax").val()>=0)){
			$("#u16PttSpsPackSizeMaxError").text("/* 请输入0~500之间的整数 */");
			index++;
		}else{
			$("#u16PttSpsPackSizeMaxError").text("");
		}
		if(!(isNum.test($("#u8SpsJitter").val()) && $("#u8SpsJitter").val()<=60  && $("#u8SpsJitter").val()>=0)){
			$("#u8SpsJitterError").text("/* 请输入0~60之间的整数 */");
			index++;
		}else{
			$("#u8SpsJitterError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_cel_ptt1 tr").each(function(index){
		//
		if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf2");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 1){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf4");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 2){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf8");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 3){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf16");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 4){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf32");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text() == 5){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf64");
		}else{
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(1)").text("rf128");	
		}	
		//
		if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB-6");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 1){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB-4dot77");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 2){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB-3");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 3){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB-1dot77");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 4){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB0");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 5){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB1");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text() == 6){
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB2");
		}else{
			$("#t_cel_ptt1 tr:eq("+index+") td:eq(4)").text("dB3");	
		}	
		//
		if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsSwitch").text() == 0){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsSwitch").text("关");
		}else{
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsSwitch").text("开");	
		}
		//
		if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 0){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("10");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 1){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("20");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 2){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("30");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 3){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("40");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 4){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("60");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 5){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("80");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 6){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("120");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 7){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("160");
		}else if($("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text() == 8){
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("320");
		}else{
			$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsInterval").text("640");	
		}
		//
		var u8PttSpsThrRbNum = $("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsThrRbNum").text();
		var u8PttSpsThrRbNumLit = accDiv(u8PttSpsThrRbNum,100);
		$("#t_cel_ptt1 tr:eq("+index+") td.u8PttSpsThrRbNum").text(u8PttSpsThrRbNumLit);
		//
		if($("#t_cel_ptt1 tr:eq("+index+") td.b8PttDlRbEnable").text() == 0){
			$("#t_cel_ptt1 tr:eq("+index+") td.b8PttDlRbEnable").text("关");
		}else{
			$("#t_cel_ptt1 tr:eq("+index+") td.b8PttDlRbEnable").text("开");	
		}
	});	
	$("#t_cel_ptt1 td.u8TcchTransType").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("周期");
			break;
		case "1":
			$(this).text("绑定寻呼");
			break;
		}	
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_ptt"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_ptt1 tr").each(function(index){
		$("#t_cel_ptt1 tr:eq("+index+") td:eq(20)").click(function(){
			var u8CId = $("#t_cel_ptt1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_ptt&u8CId="+u8CId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_cel_ptt1 input[type=checkbox]").each(function(index){
			if($("#t_cel_ptt1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_cel_ptt1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_ptt&u8CId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_ptt"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_ptt"
	});
	//
		function accAdd(arg1,arg2){
			var r1,r2,m;
			try{
				r1 = arg1.toString().split(".")[1].length;	
			}catch(e){
				r1 = 0;	
			}
			try{
				r2 = arg2.toString().split(".")[1].length;	
			}catch(e){
				r2 = 0;	
			}
			m = Math.pow(10,Math.max(r1,r2));
			return (arg1*m + arg2*m)/m;
		}
		function accSub(arg1,arg2){
			var r1,r2,m,n;
			try{
				r1 = arg1.toString().split(".")[1].length;	
			}catch(e){
				r1 = 0;	
			}
			try{
				r2 = arg2.toString().split(".")[1].length;	
			}catch(e){
				r2 = 0;	
			}
			m = Math.pow(10,Math.max(r1,r2));
			n = (r1>=r2)?r1:r2;
			return ((arg1*m - arg2*m)/m).toFixed(n);
		}
		function accMul(arg1,arg2){
			var m = 0;
			var s1 = arg1.toString();
			var s2 = arg2.toString();
			try{
				m += s1.split(".")[1].length	
			}catch(e){}
			try{
				m += s2.split(".")[1].length	
			}catch(e){}
			return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
		}
		function accDiv(arg1,arg2){
			var t1 = 0;
			var t2 = 0;
			var r1,r2;
			try{
				t1 = arg1.toString().split(".")[1].length;
			}catch(e){}
			try{
				t2 = arg2.toString().split(".")[1].length;	
			}catch(e){}
			with(Math){
				r1 = Number(arg1.toString().replace(".",""));
				r2 = Number(arg2.toString().replace(".",""));
				return (r1/r2)*pow(10,t2-t1);
			}
		}
});