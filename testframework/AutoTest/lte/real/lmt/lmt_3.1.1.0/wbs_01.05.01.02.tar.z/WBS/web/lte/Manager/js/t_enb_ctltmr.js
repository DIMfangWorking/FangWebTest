$(function(){
	//表单校验
	var isNum=/^(-)?\d+[0]{1}$/;
	var numRegex = /^(-)?\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u16RrcSetupTimer").val()) && $("#u16RrcSetupTimer").val()<=16000  && $("#u16RrcSetupTimer").val()>=10)){
			$("#u16RrcSetupTimerError").text("/* 请输入10~16000的整数,步长10 */");
			index++;
		}else{
			$("#u16RrcSetupTimerError").text("");
		}
		if(!(isNum.test($("#u16RrcReCfgTimer").val()) && $("#u16RrcReCfgTimer").val()<=16000  && $("#u16RrcReCfgTimer").val()>=10)){
			$("#u16RrcReCfgTimerError").text("/* 请输入10~16000的整数,步长10 */");
			index++;
		}else{
			$("#u16RrcReCfgTimerError").text("");
		}
		if(!(isNum.test($("#u16RrcReEstTimer").val()) && $("#u16RrcReEstTimer").val()<=6000  && $("#u16RrcReEstTimer").val()>=10)){
			$("#u16RrcReEstTimerError").text("/* 请输入10~6000的整数,步长10 */");
			index++;
		}else{
			$("#u16RrcReEstTimerError").text("");
		}
		if(!(isNum.test($("#u16RrcCnntRlsTimer").val()) && $("#u16RrcCnntRlsTimer").val()<=3000  && $("#u16RrcCnntRlsTimer").val()>=10)){
			$("#u16RrcCnntRlsTimerError").text("/* 请输入10~3000的整数,步长10 */");
			index++;
		}else{
			$("#u16RrcCnntRlsTimerError").text("");
		}
		if(!(isNum.test($("#u16UeCapTimer").val()) && $("#u16UeCapTimer").val()<=2000  && $("#u16UeCapTimer").val()>=10)){
			$("#u16UeCapTimerError").text("/* 请输入10~2000的整数,步长10 */");
			index++;
		}else{
			$("#u16UeCapTimerError").text("");
		}
		if(!(isNum.test($("#u16HoDataGuardTimer").val()) && $("#u16HoDataGuardTimer").val()<=2000  && $("#u16HoDataGuardTimer").val()>=10)){
			$("#u16HoDataGuardTimerError").text("/* 请输入10~2000的整数,步长10 */");
			index++;
		}else{
			$("#u16HoDataGuardTimerError").text("");
		}
		if(!(isNum.test($("#u16InitialUETimer").val()) && $("#u16InitialUETimer").val()<=16000  && $("#u16InitialUETimer").val()>=10)){
			$("#u16InitialUETimerError").text("/* 请输入10~16000的整数,步长10 */");
			index++;
		}else{
			$("#u16InitialUETimerError").text("");
		}
		if(!(isNum.test($("#u32S1SetupRspTimer").val()) && $("#u32S1SetupRspTimer").val()<=20000  && $("#u32S1SetupRspTimer").val()>=10)){
			$("#u32S1SetupRspTimerError").text("/* 请输入10~20000的整数,步长10 */");
			index++;
		}else{
			$("#u32S1SetupRspTimerError").text("");
		}
		if(!(isNum.test($("#u16UeSetupFailTimer").val()) && $("#u16UeSetupFailTimer").val()<=1200  && $("#u16UeSetupFailTimer").val()>=10)){
			$("#u16UeSetupFailTimerError").text("/* 请输入10~1200的整数,步长10 */");
			index++;
		}else{
			$("#u16UeSetupFailTimerError").text("");
		}
		if(!(isNum.test($("#u16UeCtxRelReqTimer").val()) && $("#u16UeCtxRelReqTimer").val()<=10000  && $("#u16UeCtxRelReqTimer").val()>=10)){
			$("#u16UeCtxRelReqTimerError").text("/* 请输入10~10000的整数,步长10 */");
			index++;
		}else{
			$("#u16UeCtxRelReqTimerError").text("");
		}
		if(!(isNum.test($("#u16S1HoPrepareTimer").val()) && $("#u16S1HoPrepareTimer").val()<=20000  && $("#u16S1HoPrepareTimer").val()>=10)){
			$("#u16S1HoPrepareTimerError").text("/* 请输入10~20000的整数,步长10 */");
			index++;
		}else{
			$("#u16S1HoPrepareTimerError").text("");
		}
		if(!(isNum.test($("#u16S1HoCompleteTimer").val()) && $("#u16S1HoCompleteTimer").val()<=30000  && $("#u16S1HoCompleteTimer").val()>=10)){
			$("#u16S1HoCompleteTimerError").text("/* 请输入10~30000的整数,步长10 */");
			index++;
		}else{
			$("#u16S1HoCompleteTimerError").text("");
		}
		if(!(isNum.test($("#u32CmmCellCfgTimer").val()) && $("#u32CmmCellCfgTimer").val()<=10000  && $("#u32CmmCellCfgTimer").val()>=1000)){
			$("#u32CmmCellCfgTimerError").text("/* 请输入1000~10000的整数,步长10 */");
			index++;
		}else{
			$("#u32CmmCellCfgTimerError").text("");
		}
		if(!(isNum.test($("#u32S1ResetAckTimer").val()) && $("#u32S1ResetAckTimer").val()<=20000  && $("#u32S1ResetAckTimer").val()>=10)){
			$("#u32S1ResetAckTimerError").text("/* 请输入10~20000的整数,步长10 */");
			index++;
		}else{
			$("#u32S1ResetAckTimerError").text("");
		}
		if(!(isNum.test($("#u32S1UptAckTimer").val()) && $("#u32S1UptAckTimer").val()<=20000  && $("#u32S1UptAckTimer").val()>=10)){
			$("#u32S1UptAckTimerError").text("/* 请输入10~20000的整数,步长10 */");
			index++;
		}else{
			$("#u32S1UptAckTimerError").text("");
		}
		if(!(isNum.test($("#u16PingpongHoTimer").val()) && $("#u16PingpongHoTimer").val()<=20000  && $("#u16PingpongHoTimer").val()>=10)){
			$("#u16PingpongHoTimerError").text("/* 10~20000之间的整数,步长10 */");
			index++;
		}else{
			$("#u16PingpongHoTimerError").text("");
		}
		if(!(numRegex.test($("#u16A3RelInactTimer").val()) && $("#u16A3RelInactTimer").val()<=65535  && $("#u16A3RelInactTimer").val()>=0)){
			$("#u16A3RelInactTimerError").text("/* 0~65535之间的整数 */");
			index++;
		}else{
			$("#u16A3RelInactTimerError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_ctltmr"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_ctltmr1 tr").each(function(index){
		$("#t_enb_ctltmr1 tr:eq("+index+") td:eq(19)").click(function(){
			var u8CfgIdx = $("#t_enb_ctltmr1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_ctltmr&u8CfgIdx="+u8CfgIdx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_ctltmr1 input[type=checkbox]").each(function(index){
			if($("#t_enb_ctltmr1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_enb_ctltmr1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_ctltmr&u8CfgIdx="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_ctltmr"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_ctltmr"
	});
});