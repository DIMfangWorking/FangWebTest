$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8CfgIdx").val()) && $("#u8CfgIdx").val()<=255  && $("#u8CfgIdx").val()>=0)){
			$("#u8CfgIdxError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8CfgIdxError").text("");
		}	
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_enb_srvpc1 tr").each(function(index){
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("10");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("20");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("50");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("100");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("200");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("500");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("1000");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(1)").text("无穷大");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("0");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("10");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("20");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("50");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("100");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("200");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("500");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(2)").text("1000");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text("1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text("3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text("6");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(3)").text("无穷大");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(4)").text("0");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(4)").text("1.25");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(5)").text("Current Absolute");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(5)").text("Accumulation");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-8");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-7");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-6");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 7){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("-1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 8){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("0");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 9){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 10){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 11){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 12){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 13){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text() == 14){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("6");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(6)").text("7");
		}
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-8");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-7");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-6");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 7){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("-1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 8){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("0");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 9){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 10){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 11){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 12){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 13){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text() == 14){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("6");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(7)").text("7");
		}
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-8");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-7");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-6");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 7){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("-1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 8){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("0");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 9){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 10){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("2");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 11){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 12){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("4");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 13){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("5");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text() == 14){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("6");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(8)").text("7");
		}
		//
		if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 0){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("-6");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 1){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("-4.77");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 2){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("-3");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 3){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("-1.77");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 4){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("0");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 5){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("1");
		}else if($("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text() == 6){
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("2");
		}else{
			$("#t_enb_srvpc1 tr:eq("+index+") td:eq(9)").text("3");
		}					  
	});	
	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvpc"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_srvpc1 tr").each(function(index){
		$("#t_enb_srvpc1 tr:eq("+index+") td:eq(11)").click(function(){
			var u8CfgIdx = $("#t_enb_srvpc1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_srvpc&u8CfgIdx="+u8CfgIdx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_srvpc1 input[type=checkbox]").each(function(index){
			if($("#t_enb_srvpc1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_enb_srvpc1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_srvpc&u8CfgIdx="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_srvpc"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_srvpc"
	});
});