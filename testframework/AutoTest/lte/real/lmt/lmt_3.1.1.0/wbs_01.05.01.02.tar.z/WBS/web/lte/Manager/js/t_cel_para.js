$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	var isMa = /^[0-9]{3}$|^[0-9]{3}$|^[0-9]{3}$|^[0-9]{3}$|^[0-9]{3}$|^[0-9]{3}$|^[0-9]{3}$/;
	var isMap=/^[0-3]{4}$/;
	var isStep=/^-?\d+(\.\d{1}){0,1}$/;
	var isOne=/^-?\d+(\.\d{1,3}){0,1}$/;
	var isCoco=/^[A-Za-z0-9\u4e00-\u9fa5_]+$/;
	$("#submit_add").click(function(){
		//
		var u8FreqBandInd = $("#u8FreqBandInd").val();
		var low = 0;
		var offset = 0;
		if(u8FreqBandInd == 33){
			low = 1900;
			offset = 36000;
		}else if(u8FreqBandInd == 34){
			low = 2010;
			offset = 36200;
		}else if(u8FreqBandInd == 35){
			low = 1850;
			offset = 36350;
		}else if(u8FreqBandInd == 36){
			low = 1930;
			offset = 36950;
		}else if(u8FreqBandInd == 37){
			low = 1910;
			offset = 37550;
		}else if(u8FreqBandInd == 38){
			low = 2570;
			offset = 37750;
		}else if(u8FreqBandInd == 39){
			low = 1880;
			offset = 38250;
		}else if(u8FreqBandInd == 40){
			low = 2300;
			offset = 38650;
		}else if(u8FreqBandInd == 53){
			low = 778;
			offset = 64000;
		}else if(u8FreqBandInd == 58){
			low = 380;
			offset = 58200;
		}else if(u8FreqBandInd == 61){
			low = 1447;
			offset = 65000;
		}else if(u8FreqBandInd == 62){
			low = 1785;
			offset = 65200;
		}else{
			low = 606;
			offset = 59060;
		}
		var u32CenterFreq = parseFloat($("#u32CenterFreq").val());
		var u32CenterFreq1 = accAdd(accMul(accSub(u32CenterFreq,low),10),offset);
		$("#u32CenterFreq1").val(u32CenterFreq1);	
		//
		var au8MCC1 = $("#au8MCC1").val()+"";
		if(au8MCC1.length<2){
			au8MCC1 = "0" + au8MCC1;	
		}
		var au8MCC2 = $("#au8MCC2").val()+"";
		if(au8MCC2.length<2){
			au8MCC2 = "0" + au8MCC2;	
		}
		var au8MCC3 = $("#au8MCC3").val()+""
		if(au8MCC3.length<2){
			au8MCC3 = "0" + au8MCC3;	
		}
		$("#au8MCC").val(au8MCC1+au8MCC2+au8MCC3);
		//							
		var au8MNC1 = $("#au8MNC1").val()+"";
		if(au8MNC1.length<2){
			au8MNC1 = "0" + au8MNC1;	
		}
		var au8MNC2 = $("#au8MNC2").val()+"";
		if(au8MNC2.length<2){
			au8MNC2 = "0" + au8MNC2;	
		}
		var au8MNC3 = $("#au8MNC3").val()+"";
		if(au8MNC3.length<2){
			au8MNC3 = "0" + au8MNC3;	
		}
		$("#au8MNC").val(au8MNC1+au8MNC2+au8MNC3);							
		//
		var au8UlAntUsdIdx1 = "0"+$("#au8UlAntUsdIdx1").val();
		var au8UlAntUsdIdx2 = "0"+$("#au8UlAntUsdIdx2").val();
		var au8UlAntUsdIdx3 = "0"+$("#au8UlAntUsdIdx3").val();
		var au8UlAntUsdIdx4 = "0"+$("#au8UlAntUsdIdx4").val();
		var au8UlAntUsdIdx5 = "0"+$("#au8UlAntUsdIdx5").val();
		var au8UlAntUsdIdx6 = "0"+$("#au8UlAntUsdIdx6").val();
		var au8UlAntUsdIdx7 = "0"+$("#au8UlAntUsdIdx7").val();
		var au8UlAntUsdIdx8 = "0"+$("#au8UlAntUsdIdx8").val();
		$("#au8UlAntUsdIdx").val(au8UlAntUsdIdx1+au8UlAntUsdIdx2+au8UlAntUsdIdx3+au8UlAntUsdIdx4+au8UlAntUsdIdx5+au8UlAntUsdIdx6+au8UlAntUsdIdx7+au8UlAntUsdIdx8);
		//
		var au8DlAntUsdIdx1 = "0"+$("#au8DlAntUsdIdx1").val();
		var au8DlAntUsdIdx2 = "0"+$("#au8DlAntUsdIdx2").val();
		var au8DlAntUsdIdx3 = "0"+$("#au8DlAntUsdIdx3").val();
		var au8DlAntUsdIdx4 = "0"+$("#au8DlAntUsdIdx4").val();
		var au8DlAntUsdIdx5 = "0"+$("#au8DlAntUsdIdx5").val();
		var au8DlAntUsdIdx6 = "0"+$("#au8DlAntUsdIdx6").val();
		var au8DlAntUsdIdx7 = "0"+$("#au8DlAntUsdIdx7").val();
		var au8DlAntUsdIdx8 = "0"+$("#au8DlAntUsdIdx8").val();
		$("#au8DlAntUsdIdx").val(au8DlAntUsdIdx1+au8DlAntUsdIdx2+au8DlAntUsdIdx3+au8DlAntUsdIdx4+au8DlAntUsdIdx5+au8DlAntUsdIdx6+au8DlAntUsdIdx7+au8DlAntUsdIdx8);	
		
		//
		var au8DlAntPortMap1 = $("#au8DlAntPortMap1").val()+"";
		var au8DlAntPortMap2 = $("#au8DlAntPortMap2").val()+"";
		var au8DlAntPortMap3 = $("#au8DlAntPortMap3").val()+"";
		var au8DlAntPortMap4 = $("#au8DlAntPortMap4").val()+"";
		var spe1 = parseInt(au8DlAntPortMap1,10).toString(16);
		if(spe1.length<2){
			spe1 = "0" + spe1;	
		}
		var spe2 = parseInt(au8DlAntPortMap2,10).toString(16);
		if(spe2.length<2){
			spe2 = "0" + spe2;	
		}
		var spe3 = parseInt(au8DlAntPortMap3,10).toString(16);
		if(spe3.length<2){
			spe3 = "0" + spe3;	
		}
		var spe4 = parseInt(au8DlAntPortMap4,10).toString(16);
		if(spe4.length<2){
			spe4 = "0" + spe4;	
		}
		$("#au8DlAntPortMap").val(spe1+spe2+spe3+spe4);
		
		//
		var au16AntCchWgtAmpltd1 = accMul($("#au16AntCchWgtAmpltd1").val(),1000);
		var es1 = parseInt(au16AntCchWgtAmpltd1,10).toString(16);
		var lengthEs1 = es1.length;
		if(lengthEs1<4){
			for(var i=0;i<4-lengthEs1;i++){
				es1 = "0" + es1;	
			}	
		}
		var au16AntCchWgtAmpltd2 = accMul($("#au16AntCchWgtAmpltd2").val(),1000);
		var es2 = parseInt(au16AntCchWgtAmpltd2,10).toString(16);
		var lengthEs2 = es2.length;
		if(lengthEs2<4){
			for(var i=0;i<4-lengthEs2;i++){
				es2 = "0" + es2;	
			}	
		}
		var au16AntCchWgtAmpltd3 = accMul($("#au16AntCchWgtAmpltd3").val(),1000);
		var es3 = parseInt(au16AntCchWgtAmpltd3,10).toString(16);
		var lengthEs3 = es3.length;
		if(lengthEs3<4){
			for(var i=0;i<4-lengthEs3;i++){
				es3 = "0" + es3;	
			}	
		}
		var au16AntCchWgtAmpltd4 = accMul($("#au16AntCchWgtAmpltd4").val(),1000);
		var es4 = parseInt(au16AntCchWgtAmpltd4,10).toString(16);
		var lengthEs4 = es4.length;
		if(lengthEs4<4){
			for(var i=0;i<4-lengthEs4;i++){
				es4 = "0" + es4;	
			}	
		}
		var au16AntCchWgtAmpltd5 = accMul($("#au16AntCchWgtAmpltd5").val(),1000);
		var es5 = parseInt(au16AntCchWgtAmpltd5,10).toString(16);
		var lengthEs5 = es5.length;
		if(lengthEs5<4){
			for(var i=0;i<4-lengthEs5;i++){
				es5 = "0" + es5;	
			}	
		}
		var au16AntCchWgtAmpltd6 = accMul($("#au16AntCchWgtAmpltd6").val(),1000);
		var es6 = parseInt(au16AntCchWgtAmpltd6,10).toString(16);
		var lengthEs6 = es6.length;
		if(lengthEs6<4){
			for(var i=0;i<4-lengthEs6;i++){
				es6 = "0" + es6;	
			}	
		}
		var au16AntCchWgtAmpltd7 = accMul($("#au16AntCchWgtAmpltd7").val(),1000);
		var es7 = parseInt(au16AntCchWgtAmpltd7,10).toString(16);
		var lengthEs7 = es7.length;
		if(lengthEs7<4){
			for(var i=0;i<4-lengthEs7;i++){
				es7 = "0" + es7;	
			}	
		}
		var au16AntCchWgtAmpltd8 = accMul($("#au16AntCchWgtAmpltd8").val(),1000);
		var es8 = parseInt(au16AntCchWgtAmpltd8,10).toString(16);
		var lengthEs8 = es8.length;
		if(lengthEs8<4){
			for(var i=0;i<4-lengthEs8;i++){
				es8 = "0" + es8;	
			}	
		}
		$("#au16AntCchWgtAmpltd").val(es1+es2+es3+es4+es5+es6+es7+es8);
		//
		var au16AntSynWgtAmpltd1 = accMul($("#au16AntSynWgtAmpltd1").val(),1000);
		var esOne1 = parseInt(au16AntSynWgtAmpltd1,10).toString(16);
		var lengthEsOne1 = esOne1.length;
		if(lengthEsOne1<4){
			for(var i=0;i<4-lengthEsOne1;i++){
				esOne1 = "0" + esOne1;	
			}	
		}
		var au16AntSynWgtAmpltd2 = accMul($("#au16AntSynWgtAmpltd2").val(),1000);
		var esOne2 = parseInt(au16AntSynWgtAmpltd2,10).toString(16);
		var lengthEsOne2 = esOne2.length;
		if(lengthEsOne2<4){
			for(var i=0;i<4-lengthEsOne2;i++){
				esOne2 = "0" + esOne2;	
			}	
		}
		var au16AntSynWgtAmpltd3 = accMul($("#au16AntSynWgtAmpltd3").val(),1000);
		var esOne3 = parseInt(au16AntSynWgtAmpltd3,10).toString(16);
		var lengthEsOne3 = esOne3.length;
		if(lengthEsOne3<4){
			for(var i=0;i<4-lengthEsOne3;i++){
				esOne3 = "0" + esOne3;	
			}	
		}
		var au16AntSynWgtAmpltd4 = accMul($("#au16AntSynWgtAmpltd4").val(),1000);
		var esOne4 = parseInt(au16AntSynWgtAmpltd4,10).toString(16);
		var lengthEsOne4 = esOne4.length;
		if(lengthEsOne4<4){
			for(var i=0;i<4-lengthEsOne4;i++){
				esOne4 = "0" + esOne4;	
			}	
		}
		var au16AntSynWgtAmpltd5 = accMul($("#au16AntSynWgtAmpltd5").val(),1000);
		var esOne5 = parseInt(au16AntSynWgtAmpltd5,10).toString(16);
		var lengthEsOne5 = esOne5.length;
		if(lengthEsOne5<4){
			for(var i=0;i<4-lengthEsOne5;i++){
				esOne5 = "0" + esOne5;	
			}	
		}
		var au16AntSynWgtAmpltd6 = accMul($("#au16AntSynWgtAmpltd6").val(),1000);
		var esOne6 = parseInt(au16AntSynWgtAmpltd6,10).toString(16);
		var lengthEsOne6 = esOne6.length;
		if(lengthEsOne6<4){
			for(var i=0;i<4-lengthEsOne6;i++){
				esOne6 = "0" + esOne6;	
			}	
		}
		var au16AntSynWgtAmpltd7 = accMul($("#au16AntSynWgtAmpltd7").val(),1000);
		var esOne7 = parseInt(au16AntSynWgtAmpltd7,10).toString(16);
		var lengthEsOne7 = esOne7.length;
		if(lengthEsOne7<4){
			for(var i=0;i<4-lengthEsOne7;i++){
				esOne7 = "0" + esOne7;	
			}	
		}
		var au16AntSynWgtAmpltd8 = accMul($("#au16AntSynWgtAmpltd8").val(),1000);
		var esOne8 = parseInt(au16AntSynWgtAmpltd8,10).toString(16);
		var lengthEsOne8 = esOne8.length;
		if(lengthEsOne8<4){
			for(var i=0;i<4-lengthEsOne8;i++){
				esOne8 = "0" + esOne8;	
			}	
		}
		$("#au16AntSynWgtAmpltd").val(esOne1+esOne2+esOne3+esOne4+esOne5+esOne6+esOne7+esOne8);
		
		//
		var au16AntCchWgtPhase1 = $("#au16AntCchWgtPhase1").val();
		var esTwo1 = parseInt(au16AntCchWgtPhase1,10).toString(16);
		var lengthEsTwo1 = esTwo1.length;
		if(lengthEsTwo1<4){
			for(var i=0;i<4-lengthEsTwo1;i++){
				esTwo1 = "0" + esTwo1;	
			}	
		}
		var au16AntCchWgtPhase2 = $("#au16AntCchWgtPhase2").val();
		var esTwo2 = parseInt(au16AntCchWgtPhase2,10).toString(16);
		var lengthEsTwo2 = esTwo2.length;
		if(lengthEsTwo2<4){
			for(var i=0;i<4-lengthEsTwo2;i++){
				esTwo2 = "0" + esTwo2;	
			}	
		}
		var au16AntCchWgtPhase3 = $("#au16AntCchWgtPhase3").val();
		var esTwo3 = parseInt(au16AntCchWgtPhase3,10).toString(16);
		var lengthEsTwo3 = esTwo3.length;
		if(lengthEsTwo3<4){
			for(var i=0;i<4-lengthEsTwo3;i++){
				esTwo3 = "0" + esTwo3;	
			}	
		}
		var au16AntCchWgtPhase4 = $("#au16AntCchWgtPhase4").val();
		var esTwo4 = parseInt(au16AntCchWgtPhase4,10).toString(16);
		var lengthEsTwo4 = esTwo4.length;
		if(lengthEsTwo4<4){
			for(var i=0;i<4-lengthEsTwo4;i++){
				esTwo4 = "0" + esTwo4;	
			}	
		}
		var au16AntCchWgtPhase5 = $("#au16AntCchWgtPhase5").val();
		var esTwo5 = parseInt(au16AntCchWgtPhase5,10).toString(16);
		var lengthEsTwo5 = esTwo5.length;
		if(lengthEsTwo5<4){
			for(var i=0;i<4-lengthEsTwo5;i++){
				esTwo5 = "0" + esTwo5;	
			}	
		}
		var au16AntCchWgtPhase6 = $("#au16AntCchWgtPhase6").val();
		var esTwo6 = parseInt(au16AntCchWgtPhase6,10).toString(16);
		var lengthEsTwo6 = esTwo6.length;
		if(lengthEsTwo6<4){
			for(var i=0;i<4-lengthEsTwo6;i++){
				esTwo6 = "0" + esTwo6;	
			}	
		}
		var au16AntCchWgtPhase7 = $("#au16AntCchWgtPhase7").val();
		var esTwo7 = parseInt(au16AntCchWgtPhase7,10).toString(16);
		var lengthEsTwo7 = esTwo7.length;
		if(lengthEsTwo7<4){
			for(var i=0;i<4-lengthEsTwo7;i++){
				esTwo7 = "0" + esTwo7;	
			}	
		}
		var au16AntCchWgtPhase8 = $("#au16AntCchWgtPhase8").val();
		var esTwo8 = parseInt(au16AntCchWgtPhase8,10).toString(16);
		var lengthEsTwo8 = esTwo8.length;
		if(lengthEsTwo8<4){
			for(var i=0;i<4-lengthEsTwo8;i++){
				esTwo8 = "0" + esTwo8;	
			}	
		}
		$("#au16AntCchWgtPhase").val(esTwo1+esTwo2+esTwo3+esTwo4+esTwo5+esTwo6+esTwo7+esTwo8);
		
		//
		var au16AntSynWgtPhase1 = $("#au16AntSynWgtPhase1").val();
		var esThree1 = parseInt(au16AntSynWgtPhase1,10).toString(16);
		var lengthEsThree1 = esThree1.length;
		if(lengthEsThree1<4){
			for(var i=0;i<4-lengthEsThree1;i++){
				esThree1 = "0" + esThree1;	
			}	
		}
		var au16AntSynWgtPhase2 = $("#au16AntSynWgtPhase2").val();
		var esThree2 = parseInt(au16AntSynWgtPhase2,10).toString(16);
		var lengthEsThree2 = esThree2.length;
		if(lengthEsThree2<4){
			for(var i=0;i<4-lengthEsThree2;i++){
				esThree2 = "0" + esThree2;	
			}	
		}
		var au16AntSynWgtPhase3 = $("#au16AntSynWgtPhase3").val();
		var esThree3 = parseInt(au16AntSynWgtPhase3,10).toString(16);
		var lengthEsThree3 = esThree3.length;
		if(lengthEsThree3<4){
			for(var i=0;i<4-lengthEsThree3;i++){
				esThree3 = "0" + esThree3;	
			}	
		}
		var au16AntSynWgtPhase4 = $("#au16AntSynWgtPhase4").val();
		var esThree4 = parseInt(au16AntSynWgtPhase4,10).toString(16);
		var lengthEsThree4 = esThree4.length;
		if(lengthEsThree4<4){
			for(var i=0;i<4-lengthEsThree4;i++){
				esThree4 = "0" + esThree4;	
			}	
		}
		var au16AntSynWgtPhase5 = $("#au16AntSynWgtPhase5").val();
		var esThree5 = parseInt(au16AntSynWgtPhase5,10).toString(16);
		var lengthEsThree5 = esThree5.length;
		if(lengthEsThree5<4){
			for(var i=0;i<4-lengthEsThree5;i++){
				esThree5 = "0" + esThree5;	
			}	
		}
		var au16AntSynWgtPhase6 = $("#au16AntSynWgtPhase6").val();
		var esThree6 = parseInt(au16AntSynWgtPhase6,10).toString(16);
		var lengthEsThree6 = esThree6.length;
		if(lengthEsThree6<4){
			for(var i=0;i<4-lengthEsThree6;i++){
				esThree6 = "0" + esThree6;	
			}	
		}
		var au16AntSynWgtPhase7 = $("#au16AntSynWgtPhase7").val();
		var esThree7 = parseInt(au16AntSynWgtPhase7,10).toString(16);
		var lengthEsThree7 = esThree7.length;
		if(lengthEsThree7<4){
			for(var i=0;i<4-lengthEsThree7;i++){
				esThree7 = "0" + esThree7;	
			}	
		}
		var au16AntSynWgtPhase8 = $("#au16AntSynWgtPhase8").val();
		var esThree8 = parseInt(au16AntSynWgtPhase8,10).toString(16);
		var lengthEsThree8 = esThree8.length;
		if(lengthEsThree8<4){
			for(var i=0;i<4-lengthEsThree8;i++){
				esThree8 = "0" + esThree8;	
			}	
		}
		$("#au16AntSynWgtPhase").val(esThree1+esThree2+esThree3+esThree4+esThree5+esThree6+esThree7+esThree8);

		var index = 0;
		if(!((isNum.test($("#au8DlAntPortMap1").val()) && $("#au8DlAntPortMap1").val()<=255  && $("#au8DlAntPortMap1").val()>=0) && (isNum.test($("#au8DlAntPortMap2").val()) && $("#au8DlAntPortMap2").val()<=255  && $("#au8DlAntPortMap2").val()>=0) && (isNum.test($("#au8DlAntPortMap3").val()) && $("#au8DlAntPortMap3").val()<=255  && $("#au8DlAntPortMap3").val()>=0) && (isNum.test($("#au8DlAntPortMap4").val()) && $("#au8DlAntPortMap4").val()<=255  && $("#au8DlAntPortMap4").val()>=0))){
			$("#au8DlAntPortMapError").text("/* 每空值为0~255的整数 */");
			index++;
		}else{
			$("#au8DlAntPortMapError").text("");
		}
		if(!(isNum.test($("#u8CId").val()) && $("#u8CId").val()<=254  && $("#u8CId").val()>=0)){
			$("#u8CIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CIdError").text("");
		}
		if(!(isNum.test($("#u16TAC").val()) && $("#u16TAC").val()<=65535 && $("#u16TAC").val()>=0)){
			$("#u16TACError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u16TACError").text("");
		}
		var big = parseInt($("#centerFreq2").text());
		var small = parseInt($("#centerFreq1").text());
		if(!(isStep.test($("#u32CenterFreq").val()) && $("#u32CenterFreq").val()<=big  && $("#u32CenterFreq").val()>=small)){
			$("#u32CenterFreqError").text("/* 请输入符合要求的数字 */");
			index++;
		}else{
			$("#u32CenterFreqError").text("");
		}	
		if(!(isNum.test($("#u16PhyCellId").val()) && $("#u16PhyCellId").val()<=503  && $("#u16PhyCellId").val()>=0)){
			$("#u16PhyCellIdError").text("/* 请输入0~503之间的整数 */");
			index++;
		}else{
			$("#u16PhyCellIdError").text("");
		}
		if(parseInt($("#u8UlAntUsdNum").val()) > parseInt($("#u8UlAntNum").val())){
			$("#u8UlAntUsdNumError").text("/* 使能天线数不可大于实际天线数 */");
			index++;
		}else{
			$("#u8UlAntUsdNumError").text("");
		}
		if(parseInt($("#u8DlAntUsdNum").val()) > parseInt($("#u8DlAntNum").val())){
			$("#u8DlAntUsdNumError").text("/* 使能天线数不可大于实际天线数 */");
			index++;
		}else{
			$("#u8DlAntUsdNumError").text("");
		}
		var au8CellLable = $("#au8CellLable").val() + "";
		var length = au8CellLable.length;
		if(length <1){
			$("#au8CellLableError").text("/* 请输入名称 */");
			index++;
		}else if(length >128){
			$("#au8CellLableError").text("/* 名称过长 */");
			index++;
		}else if(!isCoco.test(au8CellLable)){
			$("#au8CellLableError").text("/* 只可输入数字和字母 */");
			index++;
		}else {
			$("#au8CellLableError").text("");	
		}
		if(!(isNum.test($("#u8IntraFreqHOMeasCfg").val()) && $("#u8IntraFreqHOMeasCfg").val()<=128  && $("#u8IntraFreqHOMeasCfg").val()>=1)){
			$("#u8IntraFreqHOMeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8IntraFreqHOMeasCfgError").text("");
		}
		if(!(isNum.test($("#u8A2ForInterFreqMeasCfg").val()) && $("#u8A2ForInterFreqMeasCfg").val()<=128  && $("#u8A2ForInterFreqMeasCfg").val()>=1)){
			$("#u8A2ForInterFreqMeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8A2ForInterFreqMeasCfgError").text("");
		}
		if(!(isNum.test($("#u8A1ForInterFreqMeasCfg").val()) && $("#u8A1ForInterFreqMeasCfg").val()<=128  && $("#u8A1ForInterFreqMeasCfg").val()>=1)){
			$("#u8A1ForInterFreqMeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8A1ForInterFreqMeasCfgError").text("");
		}
		if(!(isNum.test($("#u8A2ForRedirectMeasCfg").val()) && $("#u8A2ForRedirectMeasCfg").val()<=128  && $("#u8A2ForRedirectMeasCfg").val()>=1)){
			$("#u8A2ForRedirectMeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8A2ForRedirectMeasCfgError").text("");
		}
		if(!(isNum.test($("#u8sMeasure").val()) && $("#u8sMeasure").val()<=-44  && $("#u8sMeasure").val()>=-141)){
			$("#u8sMeasureError").text("/* 请输入-141~-44之间的整数 */");
			index++;
		}else{
			$("#u8sMeasureError").text("");
		}
		if(!(isNum.test($("#u8IntraFreqPrdMeasCfg").val()) && $("#u8IntraFreqPrdMeasCfg").val()<=128  && $("#u8IntraFreqPrdMeasCfg").val()>=1)){
			$("#u8IntraFreqPrdMeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8IntraFreqPrdMeasCfgError").text("");
		}
		if(!(isNum.test($("#u8IcicA3MeasCfg").val()) && $("#u8IcicA3MeasCfg").val()<=128  && $("#u8IcicA3MeasCfg").val()>=1)){
			$("#u8IcicA3MeasCfgError").text("/* 请输入1~128之间的整数 */");
			index++;
		}else{
			$("#u8IcicA3MeasCfgError").text("");
		}
		if(!(isNum.test($("#u8TopoNO").val()) && $("#u8TopoNO").val()<=255  && $("#u8TopoNO").val()>=0)){
			$("#u8TopoNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8TopoNOError").text("");
		}
		if(!(isNum.test($("#u8RedSrvCellRsrp").val()) && $("#u8RedSrvCellRsrp").val()<=-44  && $("#u8RedSrvCellRsrp").val()>=-141)){
			$("#u8RedSrvCellRsrpError").text("/* 请输入-141~-44之间的整数 */");
			index++;
		}else{
			$("#u8RedSrvCellRsrpError").text("");
		}
		if(!($("input[name=u8NbrCellAntennaPort1]:checked").val() == 0 || $("input[name=u8NbrCellAntennaPort1]:checked").val() == 1)){
			$("#u8NbrCellAntennaPort1Error").text("/* 请进行选择 */");
			index++;
		}else{
			$("#u8NbrCellAntennaPort1Error").text("");
		}
		if(!((isOne.test($("#au16AntCchWgtAmpltd1").val()) && $("#au16AntCchWgtAmpltd1").val()>=0 && $("#au16AntCchWgtAmpltd1").val()<=1 )
&&(isOne.test($("#au16AntCchWgtAmpltd2").val()) && $("#au16AntCchWgtAmpltd2").val()>=0 && $("#au16AntCchWgtAmpltd2").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd3").val()) && $("#au16AntCchWgtAmpltd3").val()>=0 && $("#au16AntCchWgtAmpltd3").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd4").val()) && $("#au16AntCchWgtAmpltd4").val()>=0 && $("#au16AntCchWgtAmpltd4").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd5").val()) && $("#au16AntCchWgtAmpltd5").val()>=0 && $("#au16AntCchWgtAmpltd5").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd6").val()) && $("#au16AntCchWgtAmpltd6").val()>=0 && $("#au16AntCchWgtAmpltd6").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd7").val()) && $("#au16AntCchWgtAmpltd7").val()>=0 && $("#au16AntCchWgtAmpltd7").val()<=1 )&&
(isOne.test($("#au16AntCchWgtAmpltd8").val()) && $("#au16AntCchWgtAmpltd8").val()>=0 && $("#au16AntCchWgtAmpltd8").val()<=1 ))){
			$("#au16AntCchWgtAmpltdError").text("/* 每空0~1,步长0.001 */");
			index++;
		}else{
			$("#au16AntCchWgtAmpltdError").text("");
		}
		if(!((isNum.test($("#au16AntCchWgtPhase1").val()) && $("#au16AntCchWgtPhase1").val()>=0 && $("#au16AntCchWgtPhase1").val()<=359 )
&&(isNum.test($("#au16AntCchWgtPhase2").val()) && $("#au16AntCchWgtPhase2").val()>=0 && $("#au16AntCchWgtPhase2").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase3").val()) && $("#au16AntCchWgtPhase3").val()>=0 && $("#au16AntCchWgtPhase3").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase4").val()) && $("#au16AntCchWgtPhase4").val()>=0 && $("#au16AntCchWgtPhase4").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase5").val()) && $("#au16AntCchWgtPhase5").val()>=0 && $("#au16AntCchWgtPhase5").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase6").val()) && $("#au16AntCchWgtPhase6").val()>=0 && $("#au16AntCchWgtPhase6").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase7").val()) && $("#au16AntCchWgtPhase7").val()>=0 && $("#au16AntCchWgtPhase7").val()<=359 )&&
(isNum.test($("#au16AntCchWgtPhase8").val()) && $("#au16AntCchWgtPhase8").val()>=0 && $("#au16AntCchWgtPhase8").val()<=359 ))){
			$("#au16AntCchWgtPhaseError").text("/* 每空为0~359之间的整数 */");
			index++;
		}else{
			$("#au16AntCchWgtPhaseError").text("");
		}
		if(!((isOne.test($("#au16AntSynWgtAmpltd1").val()) && $("#au16AntSynWgtAmpltd1").val()>=0 && $("#au16AntSynWgtAmpltd1").val()<=1 )
&&(isOne.test($("#au16AntSynWgtAmpltd2").val()) && $("#au16AntSynWgtAmpltd2").val()>=0 && $("#au16AntSynWgtAmpltd2").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd3").val()) && $("#au16AntSynWgtAmpltd3").val()>=0 && $("#au16AntSynWgtAmpltd3").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd4").val()) && $("#au16AntSynWgtAmpltd4").val()>=0 && $("#au16AntSynWgtAmpltd4").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd5").val()) && $("#au16AntSynWgtAmpltd5").val()>=0 && $("#au16AntSynWgtAmpltd5").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd6").val()) && $("#au16AntSynWgtAmpltd6").val()>=0 && $("#au16AntSynWgtAmpltd6").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd7").val()) && $("#au16AntSynWgtAmpltd7").val()>=0 && $("#au16AntSynWgtAmpltd7").val()<=1 )&&
(isOne.test($("#au16AntSynWgtAmpltd8").val()) && $("#au16AntSynWgtAmpltd8").val()>=0 && $("#au16AntSynWgtAmpltd8").val()<=1 ))){
			$("#au16AntSynWgtAmpltdError").text("/* 每空0~1,步长0.001 */");
			index++;
		}else{
			$("#au16AntSynWgtAmpltdError").text("");
		}
		if(!((isNum.test($("#au16AntSynWgtPhase1").val()) && $("#au16AntSynWgtPhase1").val()>=0 && $("#au16AntSynWgtPhase1").val()<=359 )
&&(isNum.test($("#au16AntSynWgtPhase2").val()) && $("#au16AntSynWgtPhase2").val()>=0 && $("#au16AntSynWgtPhase2").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase3").val()) && $("#au16AntSynWgtPhase3").val()>=0 && $("#au16AntSynWgtPhase3").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase4").val()) && $("#au16AntSynWgtPhase4").val()>=0 && $("#au16AntSynWgtPhase4").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase5").val()) && $("#au16AntSynWgtPhase5").val()>=0 && $("#au16AntSynWgtPhase5").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase6").val()) && $("#au16AntSynWgtPhase6").val()>=0 && $("#au16AntSynWgtPhase6").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase7").val()) && $("#au16AntSynWgtPhase7").val()>=0 && $("#au16AntSynWgtPhase7").val()<=359 )&&
(isNum.test($("#au16AntSynWgtPhase8").val()) && $("#au16AntSynWgtPhase8").val()>=0 && $("#au16AntSynWgtPhase8").val()<=359 ))){
			$("#au16AntSynWgtPhaseError").text("/* 每空位0~359之间的整数 */");
			index++;
		}else{
			$("#au16AntSynWgtPhaseError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
	});
	//内存值转为显示值
	$("#t_cel_para1 tr").each(function(index){
		//
		
		var au8MCC = $("#t_cel_para1 tr:eq("+index+") td:eq(2)").text().split("");
		var s1 = au8MCC[0] + au8MCC[1];
		if(parseInt(parseInt(s1,16).toString(10)) != 255){
			s1 = au8MCC[1];	
		}
		var s2 = au8MCC[2] + au8MCC[3];
		if(parseInt(parseInt(s2,16).toString(10)) != 255){
			s2 = au8MCC[3];	
		}
		var s3 = au8MCC[4] + au8MCC[5];
		
		if(parseInt(parseInt(s3,16).toString(10)) != 255){
			s3 = au8MCC[5];	
		}
		$("#t_cel_para1 tr:eq("+index+") td:eq(2)").text(s1+s2+s3+"");
		
		//
		var au8MNC = $("#t_cel_para1 tr:eq("+index+") td:eq(3)").text().split("");
		var sq1 = au8MNC[0] + au8MNC[1];
		if(parseInt(parseInt(sq1,16).toString(10)) != 255){
			sq1 = au8MNC[1];	
		}
		var sq2 = au8MNC[2] + au8MNC[3];
		if(parseInt(parseInt(sq2,16).toString(10)) != 255){
			sq2 = au8MNC[3];	
		}
		var sq3 = au8MNC[4] + au8MNC[5];
		if(parseInt(parseInt(sq3,16).toString(10)) != 255){
			sq3 = au8MNC[5];	
		}
		$("#t_cel_para1 tr:eq("+index+") td:eq(3)").text(sq1+sq2+sq3+"");
		
		
		//
		var u8FreqBandInd = parseInt($("#t_cel_para1 tr:eq("+index+") td:eq(5)").text());
		var low = 0;
		var offset = 0;
		if(u8FreqBandInd == 33){
			low = 1900;
			offset = 36000;
		}else if(u8FreqBandInd == 34){
			low = 2010;
			offset = 36200;
		}else if(u8FreqBandInd == 35){
			low = 1850;
			offset = 36350;
		}else if(u8FreqBandInd == 36){
			low = 1930;
			offset = 36950;
		}else if(u8FreqBandInd == 37){
			low = 1910;
			offset = 37550;
		}else if(u8FreqBandInd == 38){
			low = 2570;
			offset = 37750;
		}else if(u8FreqBandInd == 39){
			low = 1880;
			offset = 38250;
		}else if(u8FreqBandInd == 40){
			low = 2300;
			offset = 38650;
		}else if(u8FreqBandInd == 53){
			low = 778;
			offset = 64000;
		}else if(u8FreqBandInd == 58){
			low = 380;
			offset = 58200;
		}else if(u8FreqBandInd == 61){
			low = 1447;
			offset = 65000;
		}else if(u8FreqBandInd == 62){
			low = 1785;
			offset = 65200;
		}else{
			low = 606;
			offset = 59060;
		}
		var u32CenterFreq = parseInt($("#t_cel_para1 tr:eq("+index+") td:eq(6)").text());
		var u32CenterFreq1 = accAdd(accDiv(accSub(u32CenterFreq,offset),10),low);
		$("#t_cel_para1 tr:eq("+index+") td:eq(6)").text(u32CenterFreq1);	
		
		//u8SysBandWidth
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("1.4M(6RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("3M(15RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("5M(25RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("10M(50RB)");
		}	
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("15M(75RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(7)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("20M(100RB)");
		}
		//u8nB
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("4T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("2T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(7)").text("1/2T");
		}	
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("1/4T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("1/8T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 6){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("1/16T");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(11)").text() == 7){
			$("#t_cel_para1 tr:eq("+index+") td:eq(11)").text("1/32T");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(12)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(12)").text("an1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(12)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(12)").text("an2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(12)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(12)").text("an4");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(12)").text("an8");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(13)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(13)").text("an1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(13)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(13)").text("an2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(13)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(13)").text("an4");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(13)").text("an8");
		}
		//
		var au8UlAntUsdIdx = $("#t_cel_para1 tr:eq("+index+") td:eq(14)").text().split("");
		var span1 = au8UlAntUsdIdx[1];
		var span2 = au8UlAntUsdIdx[3];
		var span3 = au8UlAntUsdIdx[5];
		var span4 = au8UlAntUsdIdx[7];
		var span5 = au8UlAntUsdIdx[9];
		var span6 = au8UlAntUsdIdx[11];
		var span7 = au8UlAntUsdIdx[13];
		var span8 = au8UlAntUsdIdx[15];
		var spanA1 = "";
		var spanA2 = "";
		var spanA3 = "";
		var spanA4 = "";
		var spanA5 = "";
		var spanA6 = "";
		var spanA7 = "";
		var spanA8 = "";
		if(span1 == 1){
			spanA1 = "an1";	
		}else if(span1 == 2){
			spanA1 = "an2";	
		}else if(span1 == 3){
			spanA1 = "an3";	
		}else if(span1 == 4){
			spanA1 = "an4";	
		}else if(span1 == 5){
			spanA1 = "an5";	
		}else if(span1 == 6){
			spanA1 = "an6";	
		}else if(span1 == 7){
			spanA1 = "an7";	
		}else if(span1 == 8){
			spanA1 = "an8";	
		}else{
			spanA1 = "0"	
		}
		if(span2 == 1){
			spanA2 = "an1";	
		}else if(span2 == 2){
			spanA2 = "an2";	
		}else if(span2 == 3){
			spanA2 = "an3";	
		}else if(span2 == 4){
			spanA2 = "an4";	
		}else if(span2 == 5){
			spanA2 = "an5";	
		}else if(span2 == 6){
			spanA2 = "an6";	
		}else if(span2 == 7){
			spanA2 = "an7";	
		}else if(span2 == 8){
			spanA2 = "an8";	
		}else{
			spanA2 = "0"	
		}
		if(span3 == 1){
			spanA3 = "an1";	
		}else if(span3 == 2){
			spanA3 = "an2";	
		}else if(span3 == 3){
			spanA3 = "an3";	
		}else if(span3 == 4){
			spanA3 = "an4";	
		}else if(span3 == 5){
			spanA3 = "an5";	
		}else if(span3 == 6){
			spanA3 = "an6";	
		}else if(span3 == 7){
			spanA3 = "an7";	
		}else if(span3 == 8){
			spanA3 = "an8";	
		}else{
			spanA3 = "0"	
		}
		if(span4 == 1){
			spanA4 = "an1";	
		}else if(span4 == 2){
			spanA4 = "an2";	
		}else if(span4 == 3){
			spanA4 = "an3";	
		}else if(span4 == 4){
			spanA4 = "an4";	
		}else if(span4 == 5){
			spanA4 = "an5";	
		}else if(span4 == 6){
			spanA4 = "an6";	
		}else if(span4 == 7){
			spanA4 = "an7";	
		}else if(span4 == 8){
			spanA4 = "an8";	
		}else{
			spanA4 = "0"	
		}
		if(span5 == 1){
			spanA5 = "an1";	
		}else if(span5 == 2){
			spanA5 = "an2";	
		}else if(span5 == 3){
			spanA5 = "an3";	
		}else if(span5 == 4){
			spanA5 = "an4";	
		}else if(span5 == 5){
			spanA5 = "an5";	
		}else if(span5 == 6){
			spanA5 = "an6";	
		}else if(span5 == 7){
			spanA5 = "an7";	
		}else if(span5 == 8){
			spanA5 = "an8";	
		}else{
			spanA5 = "0"	
		}
		if(span6 == 1){
			spanA6 = "an1";	
		}else if(span6 == 2){
			spanA6 = "an2";	
		}else if(span6 == 3){
			spanA6 = "an3";	
		}else if(span6 == 4){
			spanA6 = "an4";	
		}else if(span6 == 5){
			spanA6 = "an5";	
		}else if(span6 == 6){
			spanA6 = "an6";	
		}else if(span6 == 7){
			spanA6 = "an7";	
		}else if(span6 == 8){
			spanA6 = "an8";	
		}else{
			spanA6 = "0"	
		}
		if(span7 == 1){
			spanA7 = "an1";	
		}else if(span7 == 2){
			spanA7 = "an2";	
		}else if(span7 == 3){
			spanA7 = "an3";	
		}else if(span7 == 4){
			spanA7 = "an4";	
		}else if(span7 == 5){
			spanA7 = "an5";	
		}else if(span7 == 6){
			spanA7 = "an6";	
		}else if(span7 == 7){
			spanA7 = "an7";	
		}else if(span7 == 8){
			spanA7 = "an8";	
		}else{
			spanA7 = "0"	
		}
		if(span8 == 1){
			spanA8 = "an1";	
		}else if(span8 == 2){
			spanA8 = "an2";	
		}else if(span8 == 3){
			spanA8 = "an3";	
		}else if(span8 == 4){
			spanA8 = "an4";	
		}else if(span8 == 5){
			spanA8 = "an5";	
		}else if(span8 == 6){
			spanA8 = "an6";	
		}else if(span8 == 7){
			spanA8 = "an7";	
		}else if(span8 == 8){
			spanA8 = "an8";	
		}else{
			spanA8 = "0"	
		}
		$("#t_cel_para1 tr:eq("+index+") td:eq(14)").text(spanA1+" - "+spanA2+" - "+spanA3+" - "+spanA4+" - "+spanA5+" - "+spanA6+" - "+spanA7+" - "+spanA8);


		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(15)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(15)").text("an1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(15)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(15)").text("an2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(15)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(15)").text("an4");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(15)").text("an8");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(16)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(16)").text("an1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(16)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(16)").text("an2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(16)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(16)").text("an4");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(16)").text("an8");
		}
		//
	
		var au8DlAntUsdIdx = $("#t_cel_para1 tr:eq("+index+") td:eq(17)").text().split("");
		var spanB1 = au8DlAntUsdIdx[1];
		var spanB2 = au8DlAntUsdIdx[3];
		var spanB3 = au8DlAntUsdIdx[5];
		var spanB4 = au8DlAntUsdIdx[7];
		var spanB5 = au8DlAntUsdIdx[9];
		var spanB6 = au8DlAntUsdIdx[11];
		var spanB7 = au8DlAntUsdIdx[13];
		var spanB8 = au8DlAntUsdIdx[15];
		var spanBA1 = "";
		var spanBA2 = "";
		var spanBA3 = "";
		var spanBA4 = "";
		var spanBA5 = "";
		var spanBA6 = "";
		var spanBA7 = "";
		var spanBA8 = "";
		if(spanB1 == 1){
			spanBA1 = "an1";	
		}else if(spanB1 == 2){
			spanBA1 = "an2";	
		}else if(spanB1 == 3){
			spanBA1 = "an3";	
		}else if(spanB1 == 4){
			spanBA1 = "an4";	
		}else if(spanB1 == 5){
			spanBA1 = "an5";	
		}else if(spanB1 == 6){
			spanBA1 = "an6";	
		}else if(spanB1 == 7){
			spanBA1 = "an7";	
		}else if(spanB1 == 8){
			spanBA1 = "an8";	
		}else{
			spanBA1 = "0"	
		}
		if(spanB2 == 1){
			spanBA2 = "an1";	
		}else if(spanB2 == 2){
			spanBA2 = "an2";	
		}else if(spanB2 == 3){
			spanBA2 = "an3";	
		}else if(spanB2 == 4){
			spanBA2 = "an4";	
		}else if(spanB2 == 5){
			spanBA2 = "an5";	
		}else if(spanB2 == 6){
			spanBA2 = "an6";	
		}else if(spanB2 == 7){
			spanBA2 = "an7";	
		}else if(spanB2 == 8){
			spanBA2 = "an8";	
		}else{
			spanBA2 = "0"	
		}
		if(spanB3 == 1){
			spanBA3 = "an1";	
		}else if(spanB3 == 2){
			spanBA3 = "an2";	
		}else if(spanB3 == 3){
			spanBA3 = "an3";	
		}else if(spanB3 == 4){
			spanBA3 = "an4";	
		}else if(spanB3 == 5){
			spanBA3 = "an5";	
		}else if(spanB3 == 6){
			spanBA3 = "an6";	
		}else if(spanB3 == 7){
			spanBA3 = "an7";	
		}else if(spanB3 == 8){
			spanBA3 = "an8";	
		}else{
			spanBA3 = "0"	
		}
		if(spanB4 == 1){
			spanBA4 = "an1";	
		}else if(spanB4 == 2){
			spanBA4 = "an2";	
		}else if(spanB4 == 3){
			spanBA4 = "an3";	
		}else if(spanB4 == 4){
			spanBA4 = "an4";	
		}else if(spanB4 == 5){
			spanBA4 = "an5";	
		}else if(spanB4 == 6){
			spanBA4 = "an6";	
		}else if(spanB4 == 7){
			spanBA4 = "an7";	
		}else if(spanB4 == 8){
			spanBA4 = "an8";	
		}else{
			spanBA4 = "0"	
		}
		if(spanB5 == 1){
			spanBA5 = "an1";	
		}else if(spanB5 == 2){
			spanBA5 = "an2";	
		}else if(spanB5 == 3){
			spanBA5 = "an3";	
		}else if(spanB5 == 4){
			spanBA5 = "an4";	
		}else if(spanB5 == 5){
			spanBA5 = "an5";	
		}else if(spanB5 == 6){
			spanBA5 = "an6";	
		}else if(spanB5 == 7){
			spanBA5 = "an7";	
		}else if(spanB5 == 8){
			spanBA5 = "an8";	
		}else{
			spanBA5 = "0"	
		}
		if(spanB6 == 1){
			spanBA6 = "an1";	
		}else if(spanB6 == 2){
			spanBA6 = "an2";	
		}else if(spanB6 == 3){
			spanBA6 = "an3";	
		}else if(spanB6 == 4){
			spanBA6 = "an4";	
		}else if(spanB6 == 5){
			spanBA6 = "an5";	
		}else if(spanB6 == 6){
			spanBA6 = "an6";	
		}else if(spanB6 == 7){
			spanBA6 = "an7";	
		}else if(spanB6 == 8){
			spanBA6 = "an8";	
		}else{
			spanBA6 = "0"	
		}
		if(spanB7 == 1){
			spanBA7 = "an1";	
		}else if(spanB7 == 2){
			spanBA7 = "an2";	
		}else if(spanB7 == 3){
			spanBA7 = "an3";	
		}else if(spanB7 == 4){
			spanBA7 = "an4";	
		}else if(spanB7 == 5){
			spanBA7 = "an5";	
		}else if(spanB7 == 6){
			spanBA7 = "an6";	
		}else if(spanB7 == 7){
			spanBA7 = "an7";	
		}else if(spanB7 == 8){
			spanBA7 = "an8";	
		}else{
			spanBA7 = "0"	
		}
		if(spanB8 == 1){
			spanBA8 = "an1";	
		}else if(spanB8 == 2){
			spanBA8 = "an2";	
		}else if(spanB8 == 3){
			spanBA8 = "an3";	
		}else if(spanB8 == 4){
			spanBA8 = "an4";	
		}else if(spanB8 == 5){
			spanBA8 = "an5";	
		}else if(spanB8 == 6){
			spanBA8 = "an6";	
		}else if(spanB8 == 7){
			spanBA8 = "an7";	
		}else if(spanB8 == 8){
			spanBA8 = "an8";	
		}else{
			spanBA8 = "0"	
		}
		$("#t_cel_para1 tr:eq("+index+") td:eq(17)").text(spanBA1+" - "+spanBA2+" - "+spanBA3+" - "+spanBA4+" - "+spanBA5+" - "+spanBA6+" - "+spanBA7+" - "+spanBA8);
	
	
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(18)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(18)").text("port1");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(18)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(18)").text("port2");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(18)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(18)").text("port4");
		}
		
		var au8DlAntPortMap = $("#t_cel_para1 tr:eq("+index+") td:eq(19)").text().split("");
		var str1 = au8DlAntPortMap[0] + au8DlAntPortMap[1] ;
		var str2 = au8DlAntPortMap[2] + au8DlAntPortMap[3] ;
		var str3 = au8DlAntPortMap[4] + au8DlAntPortMap[5] ;
		var str4 = au8DlAntPortMap[6] + au8DlAntPortMap[7] ;
		var no1 = parseInt(str1,16).toString(10);
		var no2 = parseInt(str2,16).toString(10);
		var no3 = parseInt(str3,16).toString(10);
		var no4 = parseInt(str4,16).toString(10);
		var result1 = no1 + " , " + no2 + " , " + no3 + " , " + no4;		
		$("#t_cel_para1 tr:eq("+index+") td:eq(19)").text(result1);
		//
		var au16AntCchWgtAmpltd = $("#t_cel_para1 tr:eq("+index+") td:eq(20)").text().split("");
		var coco1 = au16AntCchWgtAmpltd[0]+au16AntCchWgtAmpltd[1]+au16AntCchWgtAmpltd[2]+au16AntCchWgtAmpltd[3];
		var coco2 = au16AntCchWgtAmpltd[4]+au16AntCchWgtAmpltd[5]+au16AntCchWgtAmpltd[6]+au16AntCchWgtAmpltd[7];
		var coco3 = au16AntCchWgtAmpltd[8]+au16AntCchWgtAmpltd[9]+au16AntCchWgtAmpltd[10]+au16AntCchWgtAmpltd[11];
		var coco4 = au16AntCchWgtAmpltd[12]+au16AntCchWgtAmpltd[13]+au16AntCchWgtAmpltd[14]+au16AntCchWgtAmpltd[15];
		var coco5 = au16AntCchWgtAmpltd[16]+au16AntCchWgtAmpltd[17]+au16AntCchWgtAmpltd[18]+au16AntCchWgtAmpltd[19];
		var coco6 = au16AntCchWgtAmpltd[20]+au16AntCchWgtAmpltd[21]+au16AntCchWgtAmpltd[22]+au16AntCchWgtAmpltd[23];
		var coco7 = au16AntCchWgtAmpltd[24]+au16AntCchWgtAmpltd[25]+au16AntCchWgtAmpltd[26]+au16AntCchWgtAmpltd[27];
		var coco8 = au16AntCchWgtAmpltd[28]+au16AntCchWgtAmpltd[29]+au16AntCchWgtAmpltd[30]+au16AntCchWgtAmpltd[31];
		var bh1 = accDiv(parseInt(parseInt(coco1,16).toString(10)),1000);
		var bh2 = accDiv(parseInt(parseInt(coco2,16).toString(10)),1000);
		var bh3 = accDiv(parseInt(parseInt(coco3,16).toString(10)),1000);
		var bh4 = accDiv(parseInt(parseInt(coco4,16).toString(10)),1000);
		var bh5 = accDiv(parseInt(parseInt(coco5,16).toString(10)),1000);
		var bh6 = accDiv(parseInt(parseInt(coco6,16).toString(10)),1000);
		var bh7 = accDiv(parseInt(parseInt(coco7,16).toString(10)),1000);
		var bh8 = accDiv(parseInt(parseInt(coco8,16).toString(10)),1000);
		$("#t_cel_para1 tr:eq("+index+") td:eq(20)").text(bh1+" , "+bh2+" , "+bh3+" , "+bh4+" , "+bh5+" , "+bh6+" , "+bh7+" , "+bh8);
		//
		var au16AntCchWgtPhase = $("#t_cel_para1 tr:eq("+index+") td:eq(21)").text().split("");
		var cocoA1 = au16AntCchWgtPhase[0]+au16AntCchWgtPhase[1]+au16AntCchWgtPhase[2]+au16AntCchWgtPhase[3];
		var cocoA2 = au16AntCchWgtPhase[4]+au16AntCchWgtPhase[5]+au16AntCchWgtPhase[6]+au16AntCchWgtPhase[7];
		var cocoA3 = au16AntCchWgtPhase[8]+au16AntCchWgtPhase[9]+au16AntCchWgtPhase[10]+au16AntCchWgtPhase[11];
		var cocoA4 = au16AntCchWgtPhase[12]+au16AntCchWgtPhase[13]+au16AntCchWgtPhase[14]+au16AntCchWgtPhase[15];
		var cocoA5 = au16AntCchWgtPhase[16]+au16AntCchWgtPhase[17]+au16AntCchWgtPhase[18]+au16AntCchWgtPhase[19];
		var cocoA6 = au16AntCchWgtPhase[20]+au16AntCchWgtPhase[21]+au16AntCchWgtPhase[22]+au16AntCchWgtPhase[23];
		var cocoA7 = au16AntCchWgtPhase[24]+au16AntCchWgtPhase[25]+au16AntCchWgtPhase[26]+au16AntCchWgtPhase[27];
		var cocoA8 = au16AntCchWgtPhase[28]+au16AntCchWgtPhase[29]+au16AntCchWgtPhase[30]+au16AntCchWgtPhase[31];
		var bhA1 = parseInt(cocoA1,16).toString(10);
		var bhA2 = parseInt(cocoA2,16).toString(10);
		var bhA3 = parseInt(cocoA3,16).toString(10);
		var bhA4 = parseInt(cocoA4,16).toString(10);
		var bhA5 = parseInt(cocoA5,16).toString(10);
		var bhA6 = parseInt(cocoA6,16).toString(10);
		var bhA7 = parseInt(cocoA7,16).toString(10);
		var bhA8 = parseInt(cocoA8,16).toString(10);
		$("#t_cel_para1 tr:eq("+index+") td:eq(21)").text(bhA1+" , "+bhA2+" , "+bhA3+" , "+bhA4+" , "+bhA5+" , "+bhA6+" , "+bhA7+" , "+bhA8);
		//
		var au16AntSynWgtAmpltd = $("#t_cel_para1 tr:eq("+index+") td:eq(22)").text().split("");
		var cocoB1 = au16AntSynWgtAmpltd[0]+au16AntSynWgtAmpltd[1]+au16AntSynWgtAmpltd[2]+au16AntSynWgtAmpltd[3];
		var cocoB2 = au16AntSynWgtAmpltd[4]+au16AntSynWgtAmpltd[5]+au16AntSynWgtAmpltd[6]+au16AntSynWgtAmpltd[7];
		var cocoB3 = au16AntSynWgtAmpltd[8]+au16AntSynWgtAmpltd[9]+au16AntSynWgtAmpltd[10]+au16AntSynWgtAmpltd[11];
		var cocoB4 = au16AntSynWgtAmpltd[12]+au16AntSynWgtAmpltd[13]+au16AntSynWgtAmpltd[14]+au16AntSynWgtAmpltd[15];
		var cocoB5 = au16AntSynWgtAmpltd[16]+au16AntSynWgtAmpltd[17]+au16AntSynWgtAmpltd[18]+au16AntSynWgtAmpltd[19];
		var cocoB6 = au16AntSynWgtAmpltd[20]+au16AntSynWgtAmpltd[21]+au16AntSynWgtAmpltd[22]+au16AntSynWgtAmpltd[23];
		var cocoB7 = au16AntSynWgtAmpltd[24]+au16AntSynWgtAmpltd[25]+au16AntSynWgtAmpltd[26]+au16AntSynWgtAmpltd[27];
		var cocoB8 = au16AntSynWgtAmpltd[28]+au16AntSynWgtAmpltd[29]+au16AntSynWgtAmpltd[30]+au16AntSynWgtAmpltd[31];
		var bhB1 = accDiv(parseInt(parseInt(cocoB1,16).toString(10)),1000);
		var bhB2 = accDiv(parseInt(parseInt(cocoB2,16).toString(10)),1000);
		var bhB3 = accDiv(parseInt(parseInt(cocoB3,16).toString(10)),1000);
		var bhB4 = accDiv(parseInt(parseInt(cocoB4,16).toString(10)),1000);
		var bhB5 = accDiv(parseInt(parseInt(cocoB5,16).toString(10)),1000);
		var bhB6 = accDiv(parseInt(parseInt(cocoB6,16).toString(10)),1000);
		var bhB7 = accDiv(parseInt(parseInt(cocoB7,16).toString(10)),1000);
		var bhB8 = accDiv(parseInt(parseInt(cocoB8,16).toString(10)),1000);
		$("#t_cel_para1 tr:eq("+index+") td:eq(22)").text(bhB1+" , "+bhB2+" , "+bhB3+" , "+bhB4+" , "+bhB5+" , "+bhB6+" , "+bhB7+" , "+bhB8);
		//
		var au16AntSynWgtPhase = $("#t_cel_para1 tr:eq("+index+") td:eq(23)").text().split("");
		var cocoC1 = au16AntSynWgtPhase[0]+au16AntSynWgtPhase[1]+au16AntSynWgtPhase[2]+au16AntSynWgtPhase[3];
		var cocoC2 = au16AntSynWgtPhase[4]+au16AntSynWgtPhase[5]+au16AntSynWgtPhase[6]+au16AntSynWgtPhase[7];
		var cocoC3 = au16AntSynWgtPhase[8]+au16AntSynWgtPhase[9]+au16AntSynWgtPhase[10]+au16AntSynWgtPhase[11];
		var cocoC4 = au16AntSynWgtPhase[12]+au16AntSynWgtPhase[13]+au16AntSynWgtPhase[14]+au16AntSynWgtPhase[15];
		var cocoC5 = au16AntSynWgtPhase[16]+au16AntSynWgtPhase[17]+au16AntSynWgtPhase[18]+au16AntSynWgtPhase[19];
		var cocoC6 = au16AntSynWgtPhase[20]+au16AntSynWgtPhase[21]+au16AntSynWgtPhase[22]+au16AntSynWgtPhase[23];
		var cocoC7 = au16AntSynWgtPhase[24]+au16AntSynWgtPhase[25]+au16AntSynWgtPhase[26]+au16AntSynWgtPhase[27];
		var cocoC8 = au16AntSynWgtPhase[28]+au16AntSynWgtPhase[29]+au16AntSynWgtPhase[30]+au16AntSynWgtPhase[31];
		var bhC1 = parseInt(cocoC1,16).toString(10);
		var bhC2 = parseInt(cocoC2,16).toString(10);
		var bhC3 = parseInt(cocoC3,16).toString(10);
		var bhC4 = parseInt(cocoC4,16).toString(10);
		var bhC5 = parseInt(cocoC5,16).toString(10);
		var bhC6 = parseInt(cocoC6,16).toString(10);
		var bhC7 = parseInt(cocoC7,16).toString(10);
		var bhC8 = parseInt(cocoC8,16).toString(10);
		$("#t_cel_para1 tr:eq("+index+") td:eq(23)").text(bhC1+" , "+bhC2+" , "+bhC3+" , "+bhC4+" , "+bhC5+" , "+bhC6+" , "+bhC7+" , "+bhC8);
			
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(24)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(24)").text("2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(24)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(24)").text("4");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(24)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(24)").text("8");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(24)").text("16");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("5");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("10");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("15");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(25)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("20");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(25)").text("40");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(26)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(26)").text("tm1");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(26)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(26)").text("tm2");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(26)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(26)").text("tm3");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-24");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-22");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-20");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-18");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-16");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-14");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 6){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-12");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 7){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-10");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 8){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-8");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 9){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-6");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 10){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-5");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 11){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-4");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 12){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-3");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 13){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 14){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("-1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 15){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("0");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 16){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 17){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 18){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("3");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 19){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("4");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 20){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("5");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 21){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("6");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 22){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("8");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 23){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("10");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 24){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("12");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 25){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("14");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 26){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("16");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 27){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("18");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 28){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("20");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(27)").text() == 29){
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("22");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(27)").text("24");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("500");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("750");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("1280");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("1920");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("2560");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("5120");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 6){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("10240");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(28)").text() == 7){
			$("#t_cel_para1 tr:eq("+index+") td:eq(28)").text("正无穷");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("1.4M(6RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("3M(15RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("5M(25RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("10M(50RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("15M(75RB)");
		}
		if($("#t_cel_para1 tr:eq("+index+") td:eq(33)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(33)").text("20M(100RB)");
		}
		
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("0");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("3");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("4");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("5");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 6){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("6");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 7){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("7");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 8){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("8");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 9){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("9");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 10){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("11");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 11){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("13");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 12){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("15");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(34)").text() == 13){
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("17");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(34)").text("19");
		}
		//
		if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("0");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 1){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("1");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 2){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("2");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 3){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("3");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 4){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("4");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 5){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("5");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 6){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("6");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 7){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("7");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 8){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("8");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 9){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("9");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 10){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("11");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 11){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("13");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 12){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("15");
		}else if($("#t_cel_para1 tr:eq("+index+") td:eq(35)").text() == 13){
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("17");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td:eq(35)").text("19");
		}
		
		
		var u8sMeasure = parseInt($("#t_cel_para1 tr:eq("+index+") td.u8sMeasure").text());
		var u8sMeasure1 = u8sMeasure - 141 ;
		$("#t_cel_para1 tr:eq("+index+") td.u8sMeasure").text(u8sMeasure1);
		//
		if($("#t_cel_para1 tr:eq("+index+") td.u8NbrCellAntennaPort1").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td.u8NbrCellAntennaPort1").text("否");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td.u8NbrCellAntennaPort1").text("是");
		}
		var u8RedSrvCellRsrp = parseInt($("#t_cel_para1 tr:eq("+index+") td.u8RedSrvCellRsrp").text());
		var u8RedSrvCellRsrp1 = u8RedSrvCellRsrp - 141 ;
		$("#t_cel_para1 tr:eq("+index+") td.u8RedSrvCellRsrp").text(u8RedSrvCellRsrp1);
		//
		if($("#t_cel_para1 tr:eq("+index+") td.u8ManualOP").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td.u8ManualOP").text("解闭塞");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td.u8ManualOP").text("闭塞");
		}	
		//
		if($("#t_cel_para1 tr:eq("+index+") td.u32Status").text() == 0){
			$("#t_cel_para1 tr:eq("+index+") td.u32Status").text("正常");
		}else{
			$("#t_cel_para1 tr:eq("+index+") td.u32Status").text("不正常");
		}								  
	});	
	//联动控制
	if($("#u8FreqBandInd").val() == 33){
		$("#centerFreq1").html("1900");	
		$("#centerFreq2").html("1920");	
	}else if($("#u8FreqBandInd").val() == 34){
		$("#centerFreq1").html("2010");
		$("#centerFreq2").html("2025");
	}else if($("#u8FreqBandInd").val() == 35){
		$("#centerFreq1").html("1850");	
		$("#centerFreq2").html("1910");	
	}else if($("#u8FreqBandInd").val() == 36){
		$("#centerFreq1").html("1930");	
		$("#centerFreq2").html("1990");	
	}else if($("#u8FreqBandInd").val() == 37){
		$("#centerFreq1").html("1910");	
		$("#centerFreq2").html("1930");	
	}else if($("#u8FreqBandInd").val() == 38){
		$("#centerFreq1").html("2570");	
		$("#centerFreq2").html("2620");	
	}else if($("#u8FreqBandInd").val() == 39){
		$("#centerFreq1").html("1880");	
		$("#centerFreq2").html("1920");	
	}else if($("#u8FreqBandInd").val() == 40){
		$("#centerFreq1").html("2300");	
		$("#centerFreq2").html("2400");	
	}else if($("#u8FreqBandInd").val() == 53){
		$("#centerFreq1").html("778");	
		$("#centerFreq2").html("798");	
	}else if($("#u8FreqBandInd").val() == 58){
		$("#centerFreq1").html("380");	
		$("#centerFreq2").html("430");	
	}else if($("#u8FreqBandInd").val() == 61){
		$("#centerFreq1").html("1447");	
		$("#centerFreq2").html("1467");	
	}else if($("#u8FreqBandInd").val() == 62){
		$("#centerFreq1").html("1785");	
		$("#centerFreq2").html("1805");	
	}else{
		$("#centerFreq1").html("606");	
		$("#centerFreq2").html("678");	
	}
	$("#u8FreqBandInd").change(function(){
		if($("#u8FreqBandInd").val() == 33){
			$("#centerFreq1").html("1900");	
			$("#centerFreq2").html("1920");	
		}else if($("#u8FreqBandInd").val() == 34){
			$("#centerFreq1").html("2010");
			$("#centerFreq2").html("2025");
		}else if($("#u8FreqBandInd").val() == 35){
			$("#centerFreq1").html("1850");	
			$("#centerFreq2").html("1910");	
		}else if($("#u8FreqBandInd").val() == 36){
			$("#centerFreq1").html("1930");	
			$("#centerFreq2").html("1990");	
		}else if($("#u8FreqBandInd").val() == 37){
			$("#centerFreq1").html("1910");	
			$("#centerFreq2").html("1930");	
		}else if($("#u8FreqBandInd").val() == 38){
			$("#centerFreq1").html("2570");	
			$("#centerFreq2").html("2620");	
		}else if($("#u8FreqBandInd").val() == 39){
			$("#centerFreq1").html("1880");	
			$("#centerFreq2").html("1920");	
		}else if($("#u8FreqBandInd").val() == 40){
			$("#centerFreq1").html("2300");	
			$("#centerFreq2").html("2400");	
		}else if($("#u8FreqBandInd").val() == 53){
			$("#centerFreq1").html("778");	
			$("#centerFreq2").html("798");	
		}else if($("#u8FreqBandInd").val() == 58){
			$("#centerFreq1").html("380");	
			$("#centerFreq2").html("430");	
		}else if($("#u8FreqBandInd").val() == 61){
			$("#centerFreq1").html("1447");	
			$("#centerFreq2").html("1467");	
		}else if($("#u8FreqBandInd").val() == 62){
			$("#centerFreq1").html("1785");	
			$("#centerFreq2").html("1805");	
		}else{
			$("#centerFreq1").html("606");	
			$("#centerFreq2").html("678");	
		}
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_para"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_para1 tr").each(function(index){
		$("#t_cel_para1 tr:eq("+index+") td:eq(46)").click(function(){
			var u8CId = $("#t_cel_para1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_para&u8CId="+u8CId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_cel_para1 input[type=checkbox]").each(function(index){
			if($("#t_cel_para1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_cel_para1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_para&u8CId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_para"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_para"
	});
	function accAdd(arg1,arg2){
		var r1,r2,m;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		return (arg1*m + arg2*m)/m;
	}
	function accSub(arg1,arg2){
		var r1,r2,m,n;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		n = (r1>=r2)?r1:r2;
		return ((arg1*m - arg2*m)/m).toFixed(n);
	}
	function accMul(arg1,arg2){
		var m = 0;
		var s1 = arg1.toString();
		var s2 = arg2.toString();
		try{
			m += s1.split(".")[1].length	
		}catch(e){}
		try{
			m += s2.split(".")[1].length	
		}catch(e){}
		return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
	}
	function accDiv(arg1,arg2){
		var t1 = 0;
		var t2 = 0;
		var r1,r2;
		try{
			t1 = arg1.toString().split(".")[1].length;
		}catch(e){}
		try{
			t2 = arg2.toString().split(".")[1].length;	
		}catch(e){}
		with(Math){
			r1 = Number(arg1.toString().replace(".",""));
			r2 = Number(arg2.toString().replace(".",""));
			return (r1/r2)*pow(10,t2-t1);
		}
	}	
});