$(function(){
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8CId").val()) && $("#u8CId").val()<=254  && $("#u8CId").val()>=0)){
			$("#u8CIdError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8CIdError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	$("#t_cel_sisch tr").each(function(index){

		//					   
		if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("8");
		}else if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 1){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("16");
		}else if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 2){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("32");
		}else if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 3){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("64");
		}else if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 4){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("128");
		}else if($("#t_cel_sisch tr:eq("+index+") td:eq(2)").text() == 5){
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("256");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(2)").text("512");
		}	
		//					   
		if($("#t_cel_sisch tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(3)").text("否");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(3)").text("是");
		}	
		//					   
		if($("#t_cel_sisch tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(4)").text("否");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(4)").text("是");
		}
		//
		if($("#t_cel_sisch tr:eq("+index+") td:eq(5)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(5)").text("否");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(5)").text("是");
		}
		//
		if($("#t_cel_sisch tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(6)").text("否");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(6)").text("是");
		}
		//
		if($("#t_cel_sisch tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_cel_sisch tr:eq("+index+") td:eq(7)").text("否");
		}else{
			$("#t_cel_sisch tr:eq("+index+") td:eq(7)").text("是");
		}
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_sisch"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_sisch tr").each(function(index){
		$("#t_cel_sisch tr:eq("+index+") td:eq(9)").click(function(){
			var u8CId = $("#t_cel_sisch tr:eq("+index+") td:eq(0)").text();
			var u8SIId = $("#t_cel_sisch tr:eq("+index+") td:eq(1)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_sisch&u8CId="+u8CId+"&u8SIId="+u8SIId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str1=[];var str2=[];
		$("#t_cel_sisch input[type=checkbox]").each(function(index){
			if($("#t_cel_sisch input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp1 = $("#t_cel_sisch tr:eq("+index+") td:eq(0)").text();
				var temp2 = $("#t_cel_sisch tr:eq("+index+") td:eq(1)").text();
				str1.push(temp1);
				str2.push(temp2);
			}
		});	
		for(var i=0;i<str1.length;i++){
			if(str1[i]== "" || str1[i]== null){
				str1.splice(i,1);
			}
		}
		for(var i=0;i<str2.length;i++){
			if(str2[i]== "" || str2[i]== null){
				str2.splice(i,1);
			}
		}
		if(str1.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_sisch&u8CId="+str1+"&u8SIId="+str2+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_sisch"
	});	
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_sisch"
	});	
});