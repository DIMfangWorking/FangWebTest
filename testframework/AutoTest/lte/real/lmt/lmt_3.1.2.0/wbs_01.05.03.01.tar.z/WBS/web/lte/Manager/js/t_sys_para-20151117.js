$(function(){ 	
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8Indx").val()) && $("#u8Indx").val()<=255  && $("#u8Indx").val()>=0)){
			$("#u8IndxError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8IndxError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_sys_para"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});	
	//删除
	$("#t_sys_para tr").each(function(index){
		$("#t_sys_para tr:eq("+index+") td:eq(4)").click(function(){
			var u8Indx = $("#t_sys_para tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href="lteBts?operationType=delete&target=single&tableName=t_sys_para&u8Indx="+u8Indx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_sys_para input[type=checkbox]").each(function(index){
			if($("#t_sys_para input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_sys_para tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_sys_para&u8Indx="+str+"";
			}
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_sys_para"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_sys_para"
	});
	//转换显示值
	$("#t_sys_para td.u8ServeMod").each(function(){
		var value = $(this).text();
		if(parseInt(value) == 0){
			$(this).text("正常运营");
		}else if(parseInt(value) == 1){
			$(this).text("调测状态"); 
		}
	});
	$("#t_sys_para td.u8GuardPowerOn").each(function(){
		var value = $(this).text();
		if(parseInt(value) == 0){
			$(this).text("关闭");
		}else{
			$(this).text("打开"); 
		}
	});
});