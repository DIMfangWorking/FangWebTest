$(function(){
	//联动控制
	
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8SlotNO").val()) && $("#u8SlotNO").val()<=255  && $("#u8SlotNO").val()>=0)){
			$("#u8SlotNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8SlotNOError").text("");
		}
		if(!($("input[name=u8BDType]:checked").val() == 1 || $("input[name=u8BDType]:checked").val() == 2)){
			$("#u8BDTypeError").text("/* 请选择一个单板类型 */");
			index++;
		}else{
			$("#u8BDTypeError").text("");
		}
		if($("input[name=u8BDType]:checked").val() == 1){
			$("input[name='u16BDTypeNO']").val(65535);
		}else if($("input[name=u8BDType]:checked").val() == 2){
			$("input[name='u16BDTypeNO']").val($("#u16BDTypeNO").val());
		}
		if($("#u8RackNO option").length<1){
			$("#u8RackNOError").text("/* 没有可用的机架号选项 */");
			index++;
		}else{
			$("#u8RackNOError").text("");
		}
		if($("#u8ShelfNO option").length<1){
			$("#u8ShelfNOError").text("/* 没有可用的机框号选项 */");
			index++;
		}else{
			$("#u8ShelfNOError").text("");
		}
		
		if(index==0){
			$("#form_add").submit();	
		}
		
	});

	//内存值转为显示值
	$("#t_board tr").each(function(index){
		//u8BDType
		if($("#t_board tr:eq("+index+") td:eq(3)").text() == 1){
			$("#t_board tr:eq("+index+") td:eq(3)").text("BBU");
		}else{
			$("#t_board tr:eq("+index+") td:eq(3)").text("RRU");
		}	
		//u8RadioMode
		if($("#t_board tr:eq("+index+") td:eq(5)").text() == 1){
			$("#t_board tr:eq("+index+") td:eq(5)").text("TD-LTE");
		}else{
			$("#t_board tr:eq("+index+") td:eq(5)").text("McWiLL");
		}
		//u8ManualOP
		if($("#t_board tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_board tr:eq("+index+") td:eq(6)").text("解闭塞");
		}else{
			$("#t_board tr:eq("+index+") td:eq(6)").text("闭塞");
		}	
		//u32Status
		if($("#t_board tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_board tr:eq("+index+") td:eq(7)").text("正常");
		}else{
			$("#t_board tr:eq("+index+") td:eq(7)").text("不正常");
		}
	});	
	$("#t_board td.u16BDTypeNO").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "1":
			$(this).text("RRU8B10");
			break;
		case "3":
			$(this).text("RRU8D10");
			break;
		case "4":
			$(this).text("RRU8E10a");
			break;
		case "8":
			$(this).text("RRU8I10");
			break;
		case "10":
			$(this).text("RRU8K10");
			break;
		case "11":
			$(this).text("RRU4B10_FF");
			break;
		case "12":
			$(this).text("RRU4B30_CF");
			break;
		case "13":
			$(this).text("RRU4D30_CF");
			break;
		case "14":
			$(this).text("RRU4E10_FF");
			break;
		case "15":
			$(this).text("RRU4E30_CF");
			break;
		case "16":
			$(this).text("RRU2J30_CC");
			break;
		case "17":
			$(this).text("RRU4K30_CF");
			break;
		case "18":
			$(this).text("RRU4J30_CF");
			break;
		case "19":
			$(this).text("RRU4L30_CF");
			break;
		case "20":
			$(this).text("RRU8E10");
			break;
		case "21":
			$(this).text("RRU8E10b");
			break;
		case "65535":
			$(this).text("");
			break;
			
		}	
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_board"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_board tr").each(function(index){
		$("#t_board tr:eq("+index+") td:eq(9)").click(function(){
			var u8RackNO = $("#t_board tr:eq("+index+") td:eq(0)").text();
			var u8ShelfNO = $("#t_board tr:eq("+index+") td:eq(1)").text();
			var u8SlotNO = $("#t_board tr:eq("+index+") td:eq(2)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_board&u8RackNO="+u8RackNO+"&u8ShelfNO="+u8ShelfNO+"&u8SlotNO="+u8SlotNO+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str1=[];
		var str2=[];
		var str3=[];
		$("#t_board input[type=checkbox]").each(function(index){
			if($("#t_board input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp1 = $("#t_board tr:eq("+index+") td:eq(0)").text();
				var temp2 = $("#t_board tr:eq("+index+") td:eq(1)").text();
				var temp3 = $("#t_board tr:eq("+index+") td:eq(2)").text();
				str1.push(temp1);
				str2.push(temp2);
				str3.push(temp3);
			}
		});	
		for(var i=0;i<str1.length;i++){
			if(str1[i]== "" || str1[i]== null){
				str1.splice(i,1);
			}
		}
		for(var i=0;i<str2.length;i++){
			if(str2[i]== "" || str2[i]== null){
				str2.splice(i,1);
			}
		}
		for(var i=0;i<str3.length;i++){
			if(str3[i]== "" || str3[i]== null){
				str3.splice(i,1);
			}
		}
		if(str1.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_board&u8RackNO="+str1+"&u8ShelfNO="+str2+"&u8SlotNO="+str3+"";
			}
		}
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_board"
	});
});