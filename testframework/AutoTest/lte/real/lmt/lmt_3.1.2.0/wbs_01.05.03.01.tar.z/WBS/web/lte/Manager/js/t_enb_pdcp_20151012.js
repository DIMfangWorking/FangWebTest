$(function(){
	//表单校验
	var isNum=/^\d+$/;
	var isIp=/^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!(isNum.test($("#u8CfgIdx").val()) && $("#u8CfgIdx").val()<=255  && $("#u8CfgIdx").val()>=0)){
			$("#u8CfgIdxError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8CfgIdxError").text("");
		}
		if(!checkInputInForm(isNum,"u8PrioritySchRadio",90,10)){
			index++;
			$("#u8PrioritySchRadioError").text(dynamicInfo(10000,generateArgments_i18n_num(90,10)));
		}
		if($("#u8Protocol").val() != 0){
			if(!checkInputInForm(isNum,"u16PortStart",65535,0)){
				index++;
				$("#u16PortStartError").text(dynamicInfo(10000,generateArgments_i18n_num(65535,0)));
			}
			if(isNum.test($("#u16PortEnd").val()) && $("#u16PortEnd").val() >=0 && $("#u16PortEnd").val() <=65535){
				if(isNum.test($("#u16PortStart").val()) && $("#u16PortEnd").val() < $("#u16PortStart").val()){
					index++;
					$("#u16PortEndError").text("不可小于起始IP包协议端口号");
				}	
			}else{
				index++;
				$("#u16PortEndError").text("请输入0~65535之间的整数");
			}
			
			if(!(isIp.test($("#au8IPAddr_show").val()))){
				$("#au8IPAddr_showError").text("/* 请输入正确的IP地址 */");	
				index++;
			}else{
				//
				var au8IPAddr1 = $("#au8IPAddr_show").val();
				var s = au8IPAddr1.split(".");
				var s1 = parseInt(s[0]).toString(16);
				if(s1.length<2){
					s1 = "0" + s1;	
				}
				var s2 = parseInt(s[1]).toString(16);
				if(s2.length<2){
					s2 = "0" + s2;	
				}
				var s3 = parseInt(s[2]).toString(16);
				if(s3.length<2){
					s3 = "0" + s3;	
				}
				var s4 = parseInt(s[3]).toString(16);
				if(s4.length<2){
					s4 = "0" + s4;	
				}		
				var sr = s1+s2+s3+s4;
				$("#au8IPAddr").val(sr);
				//
				$("#au8IPAddr_showError").text("");	
			}
		}		
		if(index==0){
			$("#form_add").submit();	
		}		
	});
	//内存值转为显示值
	$("#t_enb_pdcp tr").each(function(index){
		//
		if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("50");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 1){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("100");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 2){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("150");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 3){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("300");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 4){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("500");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 5){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("750");
		}else if($("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text() == 6){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("1500");
		}else{
			$("#t_enb_pdcp tr:eq("+index+") td:eq(1)").text("无穷大");
		}	
		//
		if($("#t_enb_pdcp tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(2)").text("否");
		}else{
			$("#t_enb_pdcp tr:eq("+index+") td:eq(2)").text("是");
		}
		//
		if($("#t_enb_pdcp tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_enb_pdcp tr:eq("+index+") td:eq(3)").text("7");
		}else{
			$("#t_enb_pdcp tr:eq("+index+") td:eq(3)").text("12");
		}	
	});	
	$("#t_enb_pdcp td.u8PriorityEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_enb_pdcp td.au8IPAddr").each(function(){
		var va = $.trim($(this).text()).split("");
		var va1 = va[0] + va[1] ;
		var va2 = va[2] + va[3] ;
		var va3 = va[4] + va[5] ;
		var va4 = va[6] + va[7] ;
		var num1 = parseInt(va1,16).toString(10);
		var num2 = parseInt(va2,16).toString(10);
		var num3 = parseInt(va3,16).toString(10);
		var num4 = parseInt(va4,16).toString(10);
		var res = num1 + "." + num2 + "." + num3 + "." + num4;
		$(this).text(res);
	});
	$("#t_enb_pdcp td.u8Protocol").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("ICMP");
			$(this).siblings(".au8IPAddr").text("");
			$(this).siblings(".u16PortStart").text("");
			$(this).siblings(".u16PortEnd").text("");
			break;
		case "1":
			$(this).text("TCP");
			break;
		case "2":
			$(this).text("UDP");
			break;
		case "3":
			$(this).text("NA");
			break;
		}	
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_pdcp"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_pdcp tr").each(function(index){
		$("#t_enb_pdcp tr:eq("+index+") td:eq(11)").click(function(){
			var u8CfgIdx = $("#t_enb_pdcp tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_pdcp&u8CfgIdx="+u8CfgIdx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_pdcp input[type=checkbox]").each(function(index){
			if($("#t_enb_pdcp input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_enb_pdcp tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_pdcp&u8CfgIdx="+str+"";
			}
		}
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_pdcp"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_pdcp"
	});
});