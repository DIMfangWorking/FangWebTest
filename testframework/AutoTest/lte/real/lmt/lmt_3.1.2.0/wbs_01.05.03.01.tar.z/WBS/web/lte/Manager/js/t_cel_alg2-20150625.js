$(function(){
	//表单校验
	//整数正则
	var isNum=/^(-)?\d+$/;
	//精确至0.1的正则
	var isFloatPointOne = /^-?\d+(\.\d{1}){0,1}$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8CId",254,0)){
			index++;
			$("#u8CIdError").text(dynamicInfo(10000,generateArgments_i18n_num(254,0)));
		}
		if(!checkInputInForm(isNum,"u16PdcchPowerOffset",40,-76)){
			index++;
			$("#u16PdcchPowerOffsetError").text(dynamicInfo(10000,generateArgments_i18n_num(40,-76)));
		}
		$("#u16PdcchPowerOffset_dValue").val(accMul(accAdd($("#u16PdcchPowerOffset").val(),76),10));
		//
		if(!checkInputInForm(isNum,"u8UlMuMimoPwrThresh",-90,-120)){
			index++;
			$("#u8UlMuMimoPwrThreshError").text(dynamicInfo(10000,generateArgments_i18n_num(-90,-120)));
		}
		$("#u8UlMuMimoPwrThresh_dValue").val(accAdd($("#u8UlMuMimoPwrThresh").val(),120));
		//
		if(!checkInputInForm(isFloatPointOne,"u8UlMuMimoRbRatio",1,0)){
			index++;
			$("#u8UlMuMimoRbRatioError").text(dynamicInfo(10001,generateArgments_i18n_num(1,0)));
		}
		$("#u8UlMuMimoRbRatio_dValue").val(accMul($("#u8UlMuMimoRbRatio").val(),10));
		//
		if(!checkInputInForm(isFloatPointOne,"u8UlMuMimoTbsizeGama",5,0)){
			index++;
			$("#u8UlMuMimoTbsizeGamaError").text(dynamicInfo(10001,generateArgments_i18n_num(5,0)));
		}
		$("#u8UlMuMimoTbsizeGama_dValue").val(accMul($("#u8UlMuMimoTbsizeGama").val(),10));
		if(!checkInputInForm(isNum,"u8McsForHoRrcCfg",28,0)){
			index++;
			$("#u8McsForHoRrcCfgError").text(dynamicInfo(10000,generateArgments_i18n_num(28,0)));
		}
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_cel_alg2 td.u8MatrixType").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("MRC");
			break;
		case "1":
			$(this).text("IRC");
			break;
		}	
	});
	$("#t_cel_alg2 td.u8CceAdapMode").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("CceAdapOff");
			break;
		case "1":
			$(this).text("AdapLevel");
			break;
		case "2":
			$(this).text("AdapLevelAndPower");
			break;
		}	
	});
	$("#t_cel_alg2 td.u8GapPatternId").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("0");
			break;
		case "1":
			$(this).text("1");
			break;
		case "2":
			$(this).text("Adaption");
			break;
		}	
	});
	$("#t_cel_alg2 td.u8Pkmode").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("Close Pk Mode");
			break;
		case "1":
			$(this).text("Single Ue Pk Mode");
			break;
		case "2":
			$(this).text("Ping Pk Mode");
			break;
		case "3":
			$(this).text("Ra Pk Mode");
			break;
		case "4":
			$(this).text("Ho Pk Mode");
			break;
		case "5":
			$(this).text("MU_MIMO Pk Mode");
			break;
		}	
	});
	$("#t_cel_alg2 td.u16PdcchPowerOffset").each(function(){
		var value = $.trim($(this).text());
		$(this).text(accSub(accDiv(value,10),76));
	});
	$("#t_cel_alg2 td.u8UlMuMimoPwrThresh").each(function(){
		var value = $.trim($(this).text());
		$(this).text(accSub(value,120));
	});
	$("#t_cel_alg2 td.u8UlMuMimoRbRatio").each(function(){
		var value = $.trim($(this).text());
		$(this).text(accDiv(value,10));
	});
	$("#t_cel_alg2 td.u8UlMuMimoTbsizeGama").each(function(){
		var value = $.trim($(this).text());
		$(this).text(accDiv(value,10));
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_alg2"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_alg2"
	});
});

