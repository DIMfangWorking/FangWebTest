$(function(){	
		   
	$("#u8FilterCoeffRsrq").html(returnU8FilterCoeffRsrqOption());
	$("#u8FilterCoeffRsrp").html(returnU8FilterCoeffRsrqOption());
	for(var i=1;i<=3;i++){
		$("#au8MCC"+i).html(returnMccOption());
	}
	for(var i=1;i<=3;i++){
		$("#au8MNC"+i).html(returnMccOption());
	}
	for(var i=1;i<=8;i++){
		$("#au8DlAntUsdIdx"+i).html(returnAntOption());
	}
	for(var i=1;i<=8;i++){
		$("#au8UlAntUsdIdx"+i).html(returnAntOption());
	}	
	
	//
	var u8RedSrvCellRsrp = parseInt($("#u8RedSrvCellRsrpAAA").val());
	var u8RedSrvCellRsrp1 = u8RedSrvCellRsrp - 141;
	$("#u8RedSrvCellRsrp").val(u8RedSrvCellRsrp1);
	//
	var u8sMeasure = parseInt($("#u8sMeasureAAA").val());
	var u8sMeasure1 = u8sMeasure - 141;
	$("#u8sMeasure").val(u8sMeasure1);
	
	//
	var u8FreqBandInd = parseInt($("#u8FreqBandIndAAA").val());
	var low = 0;
	var offset = 0;
	if(u8FreqBandInd == 33){
		low = 1900;
		offset = 36000;
		$("#centerFreq1").html("1900");	
		$("#centerFreq2").html("1920");	
	}else if(u8FreqBandInd == 34){
		low = 2010;
		offset = 36200;
		$("#centerFreq1").html("2010");
		$("#centerFreq2").html("2025");
	}else if(u8FreqBandInd == 35){
		low = 1850;
		offset = 36350;
		$("#centerFreq1").html("1850");	
		$("#centerFreq2").html("1910");	
	}else if(u8FreqBandInd == 36){
		low = 1930;
		offset = 36950;
		$("#centerFreq1").html("1930");	
		$("#centerFreq2").html("1990");	
	}else if(u8FreqBandInd == 37){
		low = 1910;
		offset = 37550;
		$("#centerFreq1").html("1910");	
		$("#centerFreq2").html("1930");	
	}else if(u8FreqBandInd == 38){
		low = 2570;
		offset = 37750;
		$("#centerFreq1").html("2570");	
		$("#centerFreq2").html("2620");	
	}else if(u8FreqBandInd == 39){
		$("#centerFreq1").html("1880");	
		$("#centerFreq2").html("1920");	
		low = 1880;
		offset = 38250;
	}else if(u8FreqBandInd == 40){
		$("#centerFreq1").html("2300");	
		$("#centerFreq2").html("2400");	
		low = 2300;
		offset = 38650;
	}else if(u8FreqBandInd == 53){
		$("#centerFreq1").html("778");	
		$("#centerFreq2").html("798");	
		low = 778;
		offset = 64000;
	}else if(u8FreqBandInd == 58){
		$("#centerFreq1").html("380");	
		$("#centerFreq2").html("430");	
		low = 380;
		offset = 58200;
	}else if(u8FreqBandInd == 61){
		$("#centerFreq1").html("1447");	
		$("#centerFreq2").html("1467");	
		low = 1447;
		offset = 65000;
	}else if(u8FreqBandInd == 62){
		$("#centerFreq1").html("1785");	
		$("#centerFreq2").html("1805");	
		low = 1785;
		offset = 65200;
	}else{
		$("#centerFreq1").html("606");	
		$("#centerFreq2").html("678");	
		low = 606;
		offset = 59060;
	}
	var u32CenterFreq = parseInt($("#u32CenterFreqAAA").val());
	var u32CenterFreq2 =accAdd(accDiv(accSub(u32CenterFreq,offset),10),low);
	$("#u32CenterFreq").val(u32CenterFreq2);
	
		   
		   
		   
		   
	var au8MCC = $("#au8MCC").val().split("");
	var au8MCC1 = au8MCC[0] + au8MCC[1];
	var au8MCC2 = au8MCC[2] + au8MCC[3];
	var au8MCC3 = au8MCC[4] + au8MCC[5];
	var helen1 = parseInt(au8MCC1,16).toString(10);
	if(parseInt(helen1)>10){
		helen1 = "FF";
	}
	var helen2 = parseInt(au8MCC2,16).toString(10);
	if(parseInt(helen2)>10){
		helen2 = "FF";
	}
	var helen3 = parseInt(au8MCC3,16).toString(10);
	if(parseInt(helen3)>10){
		helen3 = "FF";
	}
	//au8MCC1
	$("#au8MCC1 option").each(function(index){
		if($("#au8MCC1 option:eq("+index+")").val() == helen1){
			$("#au8MCC1 option:eq("+index+")").attr("selected",true);
		}
	});
	//au8MCC2
	$("#au8MCC2 option").each(function(index){
		if($("#au8MCC2 option:eq("+index+")").val() == helen2){
			$("#au8MCC2 option:eq("+index+")").attr("selected",true);
		}
	});
	//au8MCC3
	$("#au8MCC3 option").each(function(index){
		if($("#au8MCC3 option:eq("+index+")").val() == helen3){
			$("#au8MCC3 option:eq("+index+")").attr("selected",true);
		}
	});
	var au8MNC = $("#au8MNC").val().split("");
	var au8MNC1 = au8MNC[0] + au8MNC[1];
	var au8MNC2 = au8MNC[2] + au8MNC[3];
	var au8MNC3 = au8MNC[4] + au8MNC[5];
	var jack1 = parseInt(au8MNC1,16).toString(10);
	if(parseInt(jack1)>10){
		jack1 = "FF";
	}
	var jack2 = parseInt(au8MNC2,16).toString(10);
	if(parseInt(jack2)>10){
		jack2 = "FF";
	}
	var jack3 = parseInt(au8MNC3,16).toString(10);
	if(parseInt(jack3)>10){
		jack3 = "FF";
	}
	//au8MNC1
	$("#au8MNC1 option").each(function(index){
		if($("#au8MNC1 option:eq("+index+")").val() == jack1){
			$("#au8MNC1 option:eq("+index+")").attr("selected",true);
		}
	});
	//au8MNC2
	$("#au8MNC2 option").each(function(index){
		if($("#au8MNC2 option:eq("+index+")").val() == jack2){
			$("#au8MNC2 option:eq("+index+")").attr("selected",true);
		}
	});
	//au8MNC3
	$("#au8MNC3 option").each(function(index){
		if($("#au8MNC3 option:eq("+index+")").val() == jack3){
			$("#au8MNC3 option:eq("+index+")").attr("selected",true);
		}
	});  
	//
	var au8UlAntUsdIdx = $("#au8UlAntUsdIdx").val().split("");
	var au8UlAntUsdIdx1 = parseInt(au8UlAntUsdIdx[1]);
	var au8UlAntUsdIdx2 = parseInt(au8UlAntUsdIdx[3]);
	var au8UlAntUsdIdx3 = parseInt(au8UlAntUsdIdx[5]);
	var au8UlAntUsdIdx4 = parseInt(au8UlAntUsdIdx[7]);
	var au8UlAntUsdIdx5 = parseInt(au8UlAntUsdIdx[9]);
	var au8UlAntUsdIdx6 = parseInt(au8UlAntUsdIdx[11]);
	var au8UlAntUsdIdx7 = parseInt(au8UlAntUsdIdx[13]);
	var au8UlAntUsdIdx8 = parseInt(au8UlAntUsdIdx[15]);
	//au8UlAntUsdIdx
	$("#au8UlAntUsdIdx1 option").each(function(index){
		if($("#au8UlAntUsdIdx1 option:eq("+index+")").val() == au8UlAntUsdIdx1){
			$("#au8UlAntUsdIdx1 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx2 option").each(function(index){
		if($("#au8UlAntUsdIdx2 option:eq("+index+")").val() == au8UlAntUsdIdx2){
			$("#au8UlAntUsdIdx2 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx3 option").each(function(index){
		if($("#au8UlAntUsdIdx3 option:eq("+index+")").val() == au8UlAntUsdIdx3){
			$("#au8UlAntUsdIdx3 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx4 option").each(function(index){
		if($("#au8UlAntUsdIdx4 option:eq("+index+")").val() == au8UlAntUsdIdx4){
			$("#au8UlAntUsdIdx4 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx5 option").each(function(index){
		if($("#au8UlAntUsdIdx5 option:eq("+index+")").val() == au8UlAntUsdIdx5){
			$("#au8UlAntUsdIdx5 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx6 option").each(function(index){
		if($("#au8UlAntUsdIdx6 option:eq("+index+")").val() == au8UlAntUsdIdx6){
			$("#au8UlAntUsdIdx6 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx7 option").each(function(index){
		if($("#au8UlAntUsdIdx7 option:eq("+index+")").val() == au8UlAntUsdIdx7){
			$("#au8UlAntUsdIdx7 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8UlAntUsdIdx8 option").each(function(index){
		if($("#au8UlAntUsdIdx8 option:eq("+index+")").val() == au8UlAntUsdIdx8){
			$("#au8UlAntUsdIdx8 option:eq("+index+")").attr("selected",true);
		}
	});	 
	//
	var au8DlAntUsdIdx = $("#au8DlAntUsdIdx").val().split("");
	var au8DlAntUsdIdx1 = parseInt(au8DlAntUsdIdx[1]);
	var au8DlAntUsdIdx2 = parseInt(au8DlAntUsdIdx[3]);
	var au8DlAntUsdIdx3 = parseInt(au8DlAntUsdIdx[5]);
	var au8DlAntUsdIdx4 = parseInt(au8DlAntUsdIdx[7]);
	var au8DlAntUsdIdx5 = parseInt(au8DlAntUsdIdx[9]);
	var au8DlAntUsdIdx6 = parseInt(au8DlAntUsdIdx[11]);
	var au8DlAntUsdIdx7 = parseInt(au8DlAntUsdIdx[13]);
	var au8DlAntUsdIdx8 = parseInt(au8DlAntUsdIdx[15]);
	//au8DlAntUsdIdx
	$("#au8DlAntUsdIdx1 option").each(function(index){
		if($("#au8DlAntUsdIdx1 option:eq("+index+")").val() == au8DlAntUsdIdx1){
			$("#au8DlAntUsdIdx1 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx2 option").each(function(index){
		if($("#au8DlAntUsdIdx2 option:eq("+index+")").val() == au8DlAntUsdIdx2){
			$("#au8DlAntUsdIdx2 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx3 option").each(function(index){
		if($("#au8DlAntUsdIdx3 option:eq("+index+")").val() == au8DlAntUsdIdx3){
			$("#au8DlAntUsdIdx3 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx4 option").each(function(index){
		if($("#au8DlAntUsdIdx4 option:eq("+index+")").val() == au8DlAntUsdIdx4){
			$("#au8DlAntUsdIdx4 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx5 option").each(function(index){
		if($("#au8DlAntUsdIdx5 option:eq("+index+")").val() == au8DlAntUsdIdx5){
			$("#au8DlAntUsdIdx5 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx6 option").each(function(index){
		if($("#au8DlAntUsdIdx6 option:eq("+index+")").val() == au8DlAntUsdIdx6){
			$("#au8DlAntUsdIdx6 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx7 option").each(function(index){
		if($("#au8DlAntUsdIdx7 option:eq("+index+")").val() == au8DlAntUsdIdx7){
			$("#au8DlAntUsdIdx7 option:eq("+index+")").attr("selected",true);
		}
	});
	$("#au8DlAntUsdIdx8 option").each(function(index){
		if($("#au8DlAntUsdIdx8 option:eq("+index+")").val() == au8DlAntUsdIdx8){
			$("#au8DlAntUsdIdx8 option:eq("+index+")").attr("selected",true);
		}
	});
	//au8DlAntPortMap
	var au8DlAntPortMap = $("#au8DlAntPortMap").val().split("");
	var au8DlAntPortMap1 = au8DlAntPortMap[0]+au8DlAntPortMap[1];
	var au8DlAntPortMap2 = au8DlAntPortMap[2]+au8DlAntPortMap[3];
	var au8DlAntPortMap3 = au8DlAntPortMap[4]+au8DlAntPortMap[5];
	var au8DlAntPortMap4 = au8DlAntPortMap[6]+au8DlAntPortMap[7];
	$("#au8DlAntPortMap1").val(parseInt(parseInt(au8DlAntPortMap1,16).toString(10)));
	$("#au8DlAntPortMap2").val(parseInt(parseInt(au8DlAntPortMap2,16).toString(10)));
	$("#au8DlAntPortMap3").val(parseInt(parseInt(au8DlAntPortMap3,16).toString(10)));
	$("#au8DlAntPortMap4").val(parseInt(parseInt(au8DlAntPortMap4,16).toString(10)));
	//au16AntCchWgtAmpltd
	var au16AntCchWgtAmpltd = $("#au16AntCchWgtAmpltd").val().split("");
	var au16AntCchWgtAmpltd1 = au16AntCchWgtAmpltd[0]+au16AntCchWgtAmpltd[1]+au16AntCchWgtAmpltd[2]+au16AntCchWgtAmpltd[3];
	var au16AntCchWgtAmpltd2 = au16AntCchWgtAmpltd[4]+au16AntCchWgtAmpltd[5]+au16AntCchWgtAmpltd[6]+au16AntCchWgtAmpltd[7];
	var au16AntCchWgtAmpltd3 = au16AntCchWgtAmpltd[8]+au16AntCchWgtAmpltd[9]+au16AntCchWgtAmpltd[10]+au16AntCchWgtAmpltd[11];
	var au16AntCchWgtAmpltd4 = au16AntCchWgtAmpltd[12]+au16AntCchWgtAmpltd[13]+au16AntCchWgtAmpltd[14]+au16AntCchWgtAmpltd[15];
	var au16AntCchWgtAmpltd5 = au16AntCchWgtAmpltd[16]+au16AntCchWgtAmpltd[17]+au16AntCchWgtAmpltd[18]+au16AntCchWgtAmpltd[19];
	var au16AntCchWgtAmpltd6 = au16AntCchWgtAmpltd[20]+au16AntCchWgtAmpltd[21]+au16AntCchWgtAmpltd[22]+au16AntCchWgtAmpltd[23];
	var au16AntCchWgtAmpltd7 = au16AntCchWgtAmpltd[24]+au16AntCchWgtAmpltd[25]+au16AntCchWgtAmpltd[26]+au16AntCchWgtAmpltd[27];
	var au16AntCchWgtAmpltd8 = au16AntCchWgtAmpltd[28]+au16AntCchWgtAmpltd[29]+au16AntCchWgtAmpltd[30]+au16AntCchWgtAmpltd[31];
	$("#au16AntCchWgtAmpltd1").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd1,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd2").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd2,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd3").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd3,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd4").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd4,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd5").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd5,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd6").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd6,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd7").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd7,16).toString(10)),1000));
	$("#au16AntCchWgtAmpltd8").val(accDiv(parseInt(parseInt(au16AntCchWgtAmpltd8,16).toString(10)),1000));
	//au16AntSynWgtAmpltd
	var au16AntSynWgtAmpltd = $("#au16AntSynWgtAmpltd").val().split("");
	var au16AntSynWgtAmpltd1 = au16AntSynWgtAmpltd[0]+au16AntSynWgtAmpltd[1]+au16AntSynWgtAmpltd[2]+au16AntSynWgtAmpltd[3];
	var au16AntSynWgtAmpltd2 = au16AntSynWgtAmpltd[4]+au16AntSynWgtAmpltd[5]+au16AntSynWgtAmpltd[6]+au16AntSynWgtAmpltd[7];
	var au16AntSynWgtAmpltd3 = au16AntSynWgtAmpltd[8]+au16AntSynWgtAmpltd[9]+au16AntSynWgtAmpltd[10]+au16AntSynWgtAmpltd[11];
	var au16AntSynWgtAmpltd4 = au16AntSynWgtAmpltd[12]+au16AntSynWgtAmpltd[13]+au16AntSynWgtAmpltd[14]+au16AntSynWgtAmpltd[15];
	var au16AntSynWgtAmpltd5 = au16AntSynWgtAmpltd[16]+au16AntSynWgtAmpltd[17]+au16AntSynWgtAmpltd[18]+au16AntSynWgtAmpltd[19];
	var au16AntSynWgtAmpltd6 = au16AntSynWgtAmpltd[20]+au16AntSynWgtAmpltd[21]+au16AntSynWgtAmpltd[22]+au16AntSynWgtAmpltd[23];
	var au16AntSynWgtAmpltd7 = au16AntSynWgtAmpltd[24]+au16AntSynWgtAmpltd[25]+au16AntSynWgtAmpltd[26]+au16AntSynWgtAmpltd[27];
	var au16AntSynWgtAmpltd8 = au16AntSynWgtAmpltd[28]+au16AntSynWgtAmpltd[29]+au16AntSynWgtAmpltd[30]+au16AntSynWgtAmpltd[31];
	$("#au16AntSynWgtAmpltd1").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd1,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd2").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd2,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd3").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd3,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd4").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd4,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd5").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd5,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd6").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd6,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd7").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd7,16).toString(10)),1000));
	$("#au16AntSynWgtAmpltd8").val(accDiv(parseInt(parseInt(au16AntSynWgtAmpltd8,16).toString(10)),1000));
	//au16AntCchWgtPhase
	var au16AntCchWgtPhase = $("#au16AntCchWgtPhase").val().split("");
	var au16AntCchWgtPhase1 = au16AntCchWgtPhase[0]+au16AntCchWgtPhase[1]+au16AntCchWgtPhase[2]+au16AntCchWgtPhase[3];
	var au16AntCchWgtPhase2 = au16AntCchWgtPhase[4]+au16AntCchWgtPhase[5]+au16AntCchWgtPhase[6]+au16AntCchWgtPhase[7];
	var au16AntCchWgtPhase3 = au16AntCchWgtPhase[8]+au16AntCchWgtPhase[9]+au16AntCchWgtPhase[10]+au16AntCchWgtPhase[11];
	var au16AntCchWgtPhase4 = au16AntCchWgtPhase[12]+au16AntCchWgtPhase[13]+au16AntCchWgtPhase[14]+au16AntCchWgtPhase[15];
	var au16AntCchWgtPhase5 = au16AntCchWgtPhase[16]+au16AntCchWgtPhase[17]+au16AntCchWgtPhase[18]+au16AntCchWgtPhase[19];
	var au16AntCchWgtPhase6 = au16AntCchWgtPhase[20]+au16AntCchWgtPhase[21]+au16AntCchWgtPhase[22]+au16AntCchWgtPhase[23];
	var au16AntCchWgtPhase7 = au16AntCchWgtPhase[24]+au16AntCchWgtPhase[25]+au16AntCchWgtPhase[26]+au16AntCchWgtPhase[27];
	var au16AntCchWgtPhase8 = au16AntCchWgtPhase[28]+au16AntCchWgtPhase[29]+au16AntCchWgtPhase[30]+au16AntCchWgtPhase[31];
	$("#au16AntCchWgtPhase1").val(parseInt(parseInt(au16AntCchWgtPhase1,16).toString(10)));
	$("#au16AntCchWgtPhase2").val(parseInt(parseInt(au16AntCchWgtPhase2,16).toString(10)));
	$("#au16AntCchWgtPhase3").val(parseInt(parseInt(au16AntCchWgtPhase3,16).toString(10)));
	$("#au16AntCchWgtPhase4").val(parseInt(parseInt(au16AntCchWgtPhase4,16).toString(10)));
	$("#au16AntCchWgtPhase5").val(parseInt(parseInt(au16AntCchWgtPhase5,16).toString(10)));
	$("#au16AntCchWgtPhase6").val(parseInt(parseInt(au16AntCchWgtPhase6,16).toString(10)));
	$("#au16AntCchWgtPhase7").val(parseInt(parseInt(au16AntCchWgtPhase7,16).toString(10)));
	$("#au16AntCchWgtPhase8").val(parseInt(parseInt(au16AntCchWgtPhase8,16).toString(10)));
	//au16AntSynWgtPhase
	var au16AntSynWgtPhase = $("#au16AntSynWgtPhase").val().split("");
	var au16AntSynWgtPhase1 = au16AntSynWgtPhase[0]+au16AntSynWgtPhase[1]+au16AntSynWgtPhase[2]+au16AntSynWgtPhase[3];
	var au16AntSynWgtPhase2 = au16AntSynWgtPhase[4]+au16AntSynWgtPhase[5]+au16AntSynWgtPhase[6]+au16AntSynWgtPhase[7];
	var au16AntSynWgtPhase3 = au16AntSynWgtPhase[8]+au16AntSynWgtPhase[9]+au16AntSynWgtPhase[10]+au16AntSynWgtPhase[11];
	var au16AntSynWgtPhase4 = au16AntSynWgtPhase[12]+au16AntSynWgtPhase[13]+au16AntSynWgtPhase[14]+au16AntSynWgtPhase[15];
	var au16AntSynWgtPhase5 = au16AntSynWgtPhase[16]+au16AntSynWgtPhase[17]+au16AntSynWgtPhase[18]+au16AntSynWgtPhase[19];
	var au16AntSynWgtPhase6 = au16AntSynWgtPhase[20]+au16AntSynWgtPhase[21]+au16AntSynWgtPhase[22]+au16AntSynWgtPhase[23];
	var au16AntSynWgtPhase7 = au16AntSynWgtPhase[24]+au16AntSynWgtPhase[25]+au16AntSynWgtPhase[26]+au16AntSynWgtPhase[27];
	var au16AntSynWgtPhase8 = au16AntSynWgtPhase[28]+au16AntSynWgtPhase[29]+au16AntSynWgtPhase[30]+au16AntSynWgtPhase[31];
	$("#au16AntSynWgtPhase1").val(parseInt(parseInt(au16AntSynWgtPhase1,16).toString(10)));
	$("#au16AntSynWgtPhase2").val(parseInt(parseInt(au16AntSynWgtPhase2,16).toString(10)));
	$("#au16AntSynWgtPhase3").val(parseInt(parseInt(au16AntSynWgtPhase3,16).toString(10)));
	$("#au16AntSynWgtPhase4").val(parseInt(parseInt(au16AntSynWgtPhase4,16).toString(10)));
	$("#au16AntSynWgtPhase5").val(parseInt(parseInt(au16AntSynWgtPhase5,16).toString(10)));
	$("#au16AntSynWgtPhase6").val(parseInt(parseInt(au16AntSynWgtPhase6,16).toString(10)));
	$("#au16AntSynWgtPhase7").val(parseInt(parseInt(au16AntSynWgtPhase7,16).toString(10)));
	$("#au16AntSynWgtPhase8").val(parseInt(parseInt(au16AntSynWgtPhase8,16).toString(10)));
	//
	//u8NbrCellAntennaPort1
	for(var i=1;i<3;i++){
		if($("#radioFour"+i).val() == $("#u8NbrCellAntennaPort1AAA").val()){
			$("#radioFour"+i).attr("checked","checked");
		}
	}
	//u8ManualOPAAA
	for(var i=1;i<3;i++){
		if($("#radioMP"+i).val() == $("#u8ManualOPAAA").val()){
			$("#radioMP"+i).attr("checked","checked");
		}
	}
	//u8UlAntUsdNum
	$("#u8UlAntUsdNum option").each(function(index){
		if($("#u8UlAntUsdNum option:eq("+index+")").val() == $("#u8UlAntUsdNumAAA").val()){
			$("#u8UlAntUsdNum option:eq("+index+")").attr("selected",true);
		}
	});
	//u8DlAntNum
	$("#u8DlAntNum option").each(function(index){
		if($("#u8DlAntNum option:eq("+index+")").val() == $("#u8DlAntNumAAA").val()){
			$("#u8DlAntNum option:eq("+index+")").attr("selected",true);
		}
	});
	//u8DlAntUsdNum
	$("#u8DlAntUsdNum option").each(function(index){
		if($("#u8DlAntUsdNum option:eq("+index+")").val() == $("#u8DlAntUsdNumAAA").val()){
			$("#u8DlAntUsdNum option:eq("+index+")").attr("selected",true);
		}
	});
	
	//u8IntraFreqMeasBW
	$("#u8IntraFreqMeasBW option").each(function(index){
		if($("#u8IntraFreqMeasBW option:eq("+index+")").val() == $("#u8IntraFreqMeasBWAAA").val()){
			$("#u8IntraFreqMeasBW option:eq("+index+")").attr("selected",true);
		}
	});
	//u8FilterCoeffRsrp
	$("#u8FilterCoeffRsrp option").each(function(index){
		if($("#u8FilterCoeffRsrp option:eq("+index+")").val() == $("#u8FilterCoeffRsrpAAA").val()){
			$("#u8FilterCoeffRsrp option:eq("+index+")").attr("selected",true);
		}
	});
	//u8FilterCoeffRsrq
	$("#u8FilterCoeffRsrq option").each(function(index){
		if($("#u8FilterCoeffRsrq option:eq("+index+")").val() == $("#u8FilterCoeffRsrqAAA").val()){
			$("#u8FilterCoeffRsrq option:eq("+index+")").attr("selected",true);
		}
	});
	
	//u8FreqBandInd
	$("#u8FreqBandInd option").each(function(index){
		if($("#u8FreqBandInd option:eq("+index+")").val() == $("#u8FreqBandIndAAA").val()){
			$("#u8FreqBandInd option:eq("+index+")").attr("selected",true);
		}
	});
	//u8DlAntPortNum
	$("#u8DlAntPortNum option").each(function(index){
		if($("#u8DlAntPortNum option:eq("+index+")").val() == $("#u8DlAntPortNumAAA").val()){
			$("#u8DlAntPortNum option:eq("+index+")").attr("selected",true);
		}
	});
	//u8NbrCellConfig
	$("#u8NbrCellConfig option").each(function(index){
		if($("#u8NbrCellConfig option:eq("+index+")").val() == $("#u8NbrCellConfigAAA").val()){
			$("#u8NbrCellConfig option:eq("+index+")").attr("selected",true);
		}
	});
	//u8SysBandWidth
	$("#u8SysBandWidth option").each(function(index){
		if($("#u8SysBandWidth option:eq("+index+")").val() == $("#u8SysBandWidthAAA").val()){
			$("#u8SysBandWidth option:eq("+index+")").attr("selected",true);
		}
	});
	//u8BcchModPrdPara
	$("#u8BcchModPrdPara option").each(function(index){
		if($("#u8BcchModPrdPara option:eq("+index+")").val() == $("#u8BcchModPrdParaAAA").val()){
			$("#u8BcchModPrdPara option:eq("+index+")").attr("selected",true);
		}
	});
	//u8UlDlSlotAlloc
	$("#u8UlDlSlotAlloc option").each(function(index){
		if($("#u8UlDlSlotAlloc option:eq("+index+")").val() == $("#u8UlDlSlotAllocAAA").val()){
			$("#u8UlDlSlotAlloc option:eq("+index+")").attr("selected",true);
		}
	});
	//u8SIWindowLength
	$("#u8SIWindowLength option").each(function(index){
		if($("#u8SIWindowLength option:eq("+index+")").val() == $("#u8SIWindowLengthAAA").val()){
			$("#u8SIWindowLength option:eq("+index+")").attr("selected",true);
		}
	});
	//u8SpecSubFramePat
	$("#u8SpecSubFramePat option").each(function(index){
		if($("#u8SpecSubFramePat option:eq("+index+")").val() == $("#u8SpecSubFramePatAAA").val()){
			$("#u8SpecSubFramePat option:eq("+index+")").attr("selected",true);
		}
	});
	//u8UeTransMode
	$("#u8UeTransMode option").each(function(index){
		if($("#u8UeTransMode option:eq("+index+")").val() == $("#u8UeTransModeAAA").val()){
			$("#u8UeTransMode option:eq("+index+")").attr("selected",true);
		}
	});
	//u8nB
	$("#u8nB option").each(function(index){
		if($("#u8nB option:eq("+index+")").val() == $("#u8nBAAA").val()){
			$("#u8nB option:eq("+index+")").attr("selected",true);
		}
	});
	//u8Ocs
	$("#u8Ocs option").each(function(index){
		if($("#u8Ocs option:eq("+index+")").val() == $("#u8OcsAAA").val()){
			$("#u8Ocs option:eq("+index+")").attr("selected",true);
		}
	});
	//u8TimeAlignTimer
	$("#u8TimeAlignTimer option").each(function(index){
		if($("#u8TimeAlignTimer option:eq("+index+")").val() == $("#u8TimeAlignTimerAAA").val()){
			$("#u8TimeAlignTimer option:eq("+index+")").attr("selected",true);
		}
	});
	//u8UlAntNum
	$("#u8UlAntNum option").each(function(index){
		if($("#u8UlAntNum option:eq("+index+")").val() == $("#u8UlAntNumAAA").val()){
			$("#u8UlAntNum option:eq("+index+")").attr("selected",true);
		}
	});	 
	//
	function accAdd(arg1,arg2){
		var r1,r2,m;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		return (arg1*m + arg2*m)/m;
	}
	function accSub(arg1,arg2){
		var r1,r2,m,n;
		try{
			r1 = arg1.toString().split(".")[1].length;	
		}catch(e){
			r1 = 0;	
		}
		try{
			r2 = arg2.toString().split(".")[1].length;	
		}catch(e){
			r2 = 0;	
		}
		m = Math.pow(10,Math.max(r1,r2));
		n = (r1>=r2)?r1:r2;
		return ((arg1*m - arg2*m)/m).toFixed(n);
	}
	function accMul(arg1,arg2){
		var m = 0;
		var s1 = arg1.toString();
		var s2 = arg2.toString();
		try{
			m += s1.split(".")[1].length	
		}catch(e){}
		try{
			m += s2.split(".")[1].length	
		}catch(e){}
		return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
	}
	function accDiv(arg1,arg2){
		var t1 = 0;
		var t2 = 0;
		var r1,r2;
		try{
			t1 = arg1.toString().split(".")[1].length;
		}catch(e){}
		try{
			t2 = arg2.toString().split(".")[1].length;	
		}catch(e){}
		with(Math){
			r1 = Number(arg1.toString().replace(".",""));
			r2 = Number(arg2.toString().replace(".",""));
			return (r1/r2)*pow(10,t2-t1);
		}
	}	
});