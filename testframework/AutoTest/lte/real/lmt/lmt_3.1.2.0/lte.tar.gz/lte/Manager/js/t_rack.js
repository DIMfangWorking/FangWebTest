$(function(){ 	
	//表单校验
	var isNum=/^\d+$/;
	var isCoco=/^[A-Za-z0-9\u4e00-\u9fa5_]+$/
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8RackNO").val()) && $("#u8RackNO").val()<=255  && $("#u8RackNO").val()>=0)){
			$("#u8RackNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8RackNOError").text("");
		}
		var s8RackName = $("#s8RackName").val() + "";
		var length = s8RackName.length;
		if(length <1){
			$("#s8RackNameError").text("/* 请输入名称 */");
			index++;
		}else if(length >80){
			$("#s8RackNameError").text("/* 名称过长 */");
			index++;
		}else if(!isCoco.test(s8RackName)){
			$("#s8RackNameError").text("/* 只可输入数字和字母 */");
			index++;
		}else {
			$("#s8RackNameError").text("");	
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_rack"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});	
	//删除
	$("#t_rack tr").each(function(index){
		$("#t_rack tr:eq("+index+") td:eq(4)").click(function(){
			var u8RackNO = $("#t_rack tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href="lteBts?operationType=delete&target=single&tableName=t_rack&u8RackNO="+u8RackNO+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_rack input[type=checkbox]").each(function(index){
			if($("#t_rack input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_rack tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_rack&u8RackNO="+str+"";
			}
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_rack"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_rack"
	});
});