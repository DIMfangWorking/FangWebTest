$(function(){
	if($("#u8EvtId").val() == 1){
		//
		$("#u8RsrpThreshold").removeAttr("disabled");
		$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
		
		//
		$("#u8RsrqThreshold").removeAttr("disabled");
		$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
		
		//
		$("#u8A3offset").removeAttr("name");
		$("#u8A3offset").removeAttr("value");
		$("#u8A3offset").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrp").removeAttr("name");
		$("#u8A5Thrd2Rsrp").removeAttr("value");
		$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrq").removeAttr("name");
		$("#u8A5Thrd2Rsrq").removeAttr("value");
		$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
		//
		$("#radio1").removeAttr("name");
		$("#radio1").removeAttr("checked");
		$("#radio1").attr("disabled","disabled");
		$("#radio2").removeAttr("name");
		$("#radio2").removeAttr("checked");
		$("#radio2").attr("disabled","disabled");
		//
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}
	}
	if($("#u8EvtId").val() == 2){
		//
		$("#u8RsrpThreshold").removeAttr("disabled");
		$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
		
		//
		$("#u8RsrqThreshold").removeAttr("disabled");
		$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
		
		//
		$("#u8A3offset").removeAttr("name");
		$("#u8A3offset").removeAttr("value");
		$("#u8A3offset").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrp").removeAttr("name");
		$("#u8A5Thrd2Rsrp").removeAttr("value");
		$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrq").removeAttr("name");
		$("#u8A5Thrd2Rsrq").removeAttr("value");
		$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
		//
		$("#radio1").removeAttr("name");
		$("#radio1").removeAttr("checked");
		$("#radio1").attr("disabled","disabled");
		$("#radio2").removeAttr("name");
		$("#radio2").removeAttr("checked");
		$("#radio2").attr("disabled","disabled");
		//
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}
	}
	if($("#u8EvtId").val() == 3){
		//
		$("#u8RsrpThreshold").removeAttr("name");
		$("#u8RsrpThreshold").removeAttr("value");
		$("#u8RsrpThreshold").attr("disabled","disabled");
		//
		$("#u8RsrqThreshold").removeAttr("name");
		$("#u8RsrqThreshold").removeAttr("value");
		$("#u8RsrqThreshold").attr("disabled","disabled");
		//
		$("#u8A3offset").removeAttr("disabled");
		$("#u8A3offset").attr("name","u8A3offset");
		$("#u8A3offset").attr("value","3");
		//
		$("#u8A5Thrd2Rsrp").removeAttr("name");
		$("#u8A5Thrd2Rsrp").removeAttr("value");
		$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrq").removeAttr("name");
		$("#u8A5Thrd2Rsrq").removeAttr("value");
		$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
		//
		$("#radio1").removeAttr("disabled");
		$("#radio1").attr("checked","checked");
		$("#radio1").attr("name","u8ReportOnLeave");
		$("#radio2").removeAttr("disabled");
		$("#radio2").attr("name","u8ReportOnLeave");
		//
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}
	}
	if($("#u8EvtId").val() == 4){
		//
		$("#u8RsrpThreshold").removeAttr("disabled");
		$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
		
		//
		$("#u8RsrqThreshold").removeAttr("disabled");
		$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
		
		//
		$("#u8A3offset").removeAttr("name");
		$("#u8A3offset").removeAttr("value");
		$("#u8A3offset").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrp").removeAttr("name");
		$("#u8A5Thrd2Rsrp").removeAttr("value");
		$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrq").removeAttr("name");
		$("#u8A5Thrd2Rsrq").removeAttr("value");
		$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
		//
		$("#radio1").removeAttr("name");
		$("#radio1").removeAttr("checked");
		$("#radio1").attr("disabled","disabled");
		$("#radio2").removeAttr("name");
		$("#radio2").removeAttr("checked");
		$("#radio2").attr("disabled","disabled");
		//
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}
	}
	if($("#u8EvtId").val() == 5){
		//
		$("#u8RsrpThreshold").removeAttr("disabled");
		$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
		
		//
		$("#u8RsrqThreshold").removeAttr("disabled");
		$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
		
		//
		$("#u8A3offset").removeAttr("name");
		$("#u8A3offset").removeAttr("value");
		$("#u8A3offset").attr("disabled","disabled");
		//
		$("#u8A5Thrd2Rsrp").removeAttr("disabled");
		$("#u8A5Thrd2Rsrp").attr("name","u8A5Thrd2Rsrp");
		$("#u8A5Thrd2Rsrp").attr("value","-90");
		//
		$("#u8A5Thrd2Rsrq").removeAttr("disabled");
		$("#u8A5Thrd2Rsrq").attr("name","u8A5Thrd2Rsrq");
		$("#u8A5Thrd2Rsrq").attr("value","-11.5");
		//
		$("#radio1").removeAttr("name");
		$("#radio1").removeAttr("checked");
		$("#radio1").attr("disabled","disabled");
		$("#radio2").removeAttr("name");
		$("#radio2").removeAttr("checked");
		$("#radio2").attr("disabled","disabled");
		//
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}
	}
	$("#u8EvtId").change(function(){
		if($("#u8EvtId").val() == 1){
			//
			$("#u8RsrpThreshold").removeAttr("disabled");
			$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
			
			//
			$("#u8RsrqThreshold").removeAttr("disabled");
			$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
			
			//
			$("#u8A3offset").removeAttr("name");
			$("#u8A3offset").removeAttr("value");
			$("#u8A3offset").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrp").removeAttr("name");
			$("#u8A5Thrd2Rsrp").removeAttr("value");
			$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrq").removeAttr("name");
			$("#u8A5Thrd2Rsrq").removeAttr("value");
			$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
			//
			$("#radio1").removeAttr("name");
			$("#radio1").removeAttr("checked");
			$("#radio1").attr("disabled","disabled");
			$("#radio2").removeAttr("name");
			$("#radio2").removeAttr("checked");
			$("#radio2").attr("disabled","disabled");
			//
			if($("#u8RptCriteria").val() == 1){
				$("#u8PrdRptInterval").removeAttr("disabled");
				$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
				$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
			}else{
				$("#u8PrdRptInterval").removeAttr("name");
				$("#u8PrdRptInterval").attr("disabled","disabled");	
			}
		}
		if($("#u8EvtId").val() == 2){
			//
			$("#u8RsrpThreshold").removeAttr("disabled");
			$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
			
			//
			$("#u8RsrqThreshold").removeAttr("disabled");
			$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
			
			//
			$("#u8A3offset").removeAttr("name");
			$("#u8A3offset").removeAttr("value");
			$("#u8A3offset").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrp").removeAttr("name");
			$("#u8A5Thrd2Rsrp").removeAttr("value");
			$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrq").removeAttr("name");
			$("#u8A5Thrd2Rsrq").removeAttr("value");
			$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
			//
			$("#radio1").removeAttr("name");
			$("#radio1").removeAttr("checked");
			$("#radio1").attr("disabled","disabled");
			$("#radio2").removeAttr("name");
			$("#radio2").removeAttr("checked");
			$("#radio2").attr("disabled","disabled");
			//
			if($("#u8RptCriteria").val() == 1){
				$("#u8PrdRptInterval").removeAttr("disabled");
				$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
				$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
			}else{
				$("#u8PrdRptInterval").removeAttr("name");
				$("#u8PrdRptInterval").attr("disabled","disabled");	
			}

		}
		if($("#u8EvtId").val() == 3){
			//
			$("#u8RsrpThreshold").removeAttr("name");
			$("#u8RsrpThreshold").removeAttr("value");
			$("#u8RsrpThreshold").attr("disabled","disabled");
			//
			$("#u8RsrqThreshold").removeAttr("name");
			$("#u8RsrqThreshold").removeAttr("value");
			$("#u8RsrqThreshold").attr("disabled","disabled");
			//
			$("#u8A3offset").removeAttr("disabled");
			$("#u8A3offset").attr("name","u8A3offset");
			$("#u8A3offset").attr("value","3");
			//
			$("#u8A5Thrd2Rsrp").removeAttr("name");
			$("#u8A5Thrd2Rsrp").removeAttr("value");
			$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrq").removeAttr("name");
			$("#u8A5Thrd2Rsrq").removeAttr("value");
			$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
			//
			$("#radio1").removeAttr("disabled");
			$("#radio1").attr("checked","checked");
			$("#radio1").attr("name","u8ReportOnLeave");
			$("#radio2").removeAttr("disabled");
			$("#radio2").attr("name","u8ReportOnLeave");
			//
			if($("#u8RptCriteria").val() == 1){
				$("#u8PrdRptInterval").removeAttr("disabled");
				$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
				$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
			}else{
				$("#u8PrdRptInterval").removeAttr("name");
				$("#u8PrdRptInterval").attr("disabled","disabled");	
			}

		}
		if($("#u8EvtId").val() == 4){
			//
			$("#u8RsrpThreshold").removeAttr("disabled");
			$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
			
			//
			$("#u8RsrqThreshold").removeAttr("disabled");
			$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
			
			//
			$("#u8A3offset").removeAttr("name");
			$("#u8A3offset").removeAttr("value");
			$("#u8A3offset").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrp").removeAttr("name");
			$("#u8A5Thrd2Rsrp").removeAttr("value");
			$("#u8A5Thrd2Rsrp").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrq").removeAttr("name");
			$("#u8A5Thrd2Rsrq").removeAttr("value");
			$("#u8A5Thrd2Rsrq").attr("disabled","disabled");
			//
			$("#radio1").removeAttr("name");
			$("#radio1").removeAttr("checked");
			$("#radio1").attr("disabled","disabled");
			$("#radio2").removeAttr("name");
			$("#radio2").removeAttr("checked");
			$("#radio2").attr("disabled","disabled");
			//
			if($("#u8RptCriteria").val() == 1){
				$("#u8PrdRptInterval").removeAttr("disabled");
				$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
				$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
			}else{
				$("#u8PrdRptInterval").removeAttr("name");
				$("#u8PrdRptInterval").attr("disabled","disabled");	
			}

		}
		if($("#u8EvtId").val() == 5){
			//
			$("#u8RsrpThreshold").removeAttr("disabled");
			$("#u8RsrpThreshold").attr("name","u8RsrpThreshold");
			
			//
			$("#u8RsrqThreshold").removeAttr("disabled");
			$("#u8RsrqThreshold").attr("name","u8RsrqThreshold");
			
			//
			$("#u8A3offset").removeAttr("name");
			$("#u8A3offset").removeAttr("value");
			$("#u8A3offset").attr("disabled","disabled");
			//
			$("#u8A5Thrd2Rsrp").removeAttr("disabled");
			$("#u8A5Thrd2Rsrp").attr("name","u8A5Thrd2Rsrp");
			$("#u8A5Thrd2Rsrp").attr("value","-90");
			//
			$("#u8A5Thrd2Rsrq").removeAttr("disabled");
			$("#u8A5Thrd2Rsrq").attr("name","u8A5Thrd2Rsrq");
			$("#u8A5Thrd2Rsrq").attr("value","-11.5");
			//
			$("#radio1").removeAttr("name");
			$("#radio1").removeAttr("checked");
			$("#radio1").attr("disabled","disabled");
			$("#radio2").removeAttr("name");
			$("#radio2").removeAttr("checked");
			$("#radio2").attr("disabled","disabled");
			//
			if($("#u8RptCriteria").val() == 1){
				$("#u8PrdRptInterval").removeAttr("disabled");
				$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
				$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
			}else{
				$("#u8PrdRptInterval").removeAttr("name");
				$("#u8PrdRptInterval").attr("disabled","disabled");	
			}

		}							
	});			
	$("#u8RptCriteria").change(function(){
		if($("#u8RptCriteria").val() == 1){
			$("#u8PrdRptInterval").removeAttr("disabled");
			$("#u8PrdRptInterval").attr("name","u8PrdRptInterval");
			$("#u8PrdRptInterval option:eq(4)").attr("selected",true);	
		}else{
			$("#u8PrdRptInterval").removeAttr("name");
			$("#u8PrdRptInterval").attr("disabled","disabled");	
		}							
	});
});