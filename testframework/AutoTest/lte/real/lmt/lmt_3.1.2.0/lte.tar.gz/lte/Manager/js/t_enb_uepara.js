$(function(){
	//内存值转为显示值
	$("#t_enb_uepara1 tr").each(function(index){
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("0");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("50");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("100");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("200");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("500");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("1000");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(1)").text("2000");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("1000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("3000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("5000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("10000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("15000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("20000");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(2)").text("30000");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("100");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("200");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("300");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("400");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("600");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("1000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text() == 6){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("1500");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(3)").text("2000");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("100");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("200");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("300");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("400");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("600");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("1000");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text() == 6){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("1500");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(4)").text("2000");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("50");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("100");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("150");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("200");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("500");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("1000");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(6)").text("2000");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("5");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("10");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("20");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("30");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("60");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("120");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(7)").text("180");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("1");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("2");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("3");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("4");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("6");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("8");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text() == 6){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("10");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(8)").text("20");
		}
		//
		if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 0){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("1");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 1){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("2");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 2){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("3");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 3){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("4");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 4){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("5");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 5){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("6");
		}else if($("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text() == 6){
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("8");
		}else{
			$("#t_enb_uepara1 tr:eq("+index+") td:eq(9)").text("10");
		}
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_uepara"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_uepara1 tr").each(function(index){
		$("#t_enb_uepara1 tr:eq("+index+") td:eq(11)").click(function(){
			var u8CfgIdx = $("#t_enb_uepara1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_uepara&u8CfgIdx="+u8CfgIdx+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_uepara1 input[type=checkbox]").each(function(index){
			if($("#t_enb_uepara1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_enb_uepara1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_uepara&u8CfgIdx="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_uepara"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_uepara"
	});
});