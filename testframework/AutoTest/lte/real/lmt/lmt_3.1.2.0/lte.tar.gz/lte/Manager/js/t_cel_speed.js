$(function(){
	//表单校验
	//整数正则
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8CellId",254,0)){
			index++;
			$("#u8CellIdError").text(dynamicInfo(10000,generateArgments_i18n_num(254,0)));
		}
		if(!checkInputInForm(isNum,"u8NCellMed4Idle",16,1)){
			index++;
			$("#u8NCellMed4IdleError").text(dynamicInfo(10000,generateArgments_i18n_num(16,1)));
		}
		if(!checkInputInForm(isNum,"u8NCellHigh4Idle",16,1)){
			index++;
			$("#u8NCellHigh4IdleError").text(dynamicInfo(10000,generateArgments_i18n_num(16,1)));
		}
		if(!checkInputInForm(isNum,"u8NCellMed4Connect",16,1)){
			index++;
			$("#u8NCellMed4ConnectError").text(dynamicInfo(10000,generateArgments_i18n_num(16,1)));
		}
		if(!checkInputInForm(isNum,"u8NCellHigh4Connect",16,1)){
			index++;
			$("#u8NCellHigh4ConnectError").text(dynamicInfo(10000,generateArgments_i18n_num(16,1)));
		}
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_cel_speed td.u8MS4IdleEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_cel_speed td.u8Teval4Idle").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("s30");
			break;
		case "1":
			$(this).text("s60");
			break;
		case "2":
			$(this).text("s120");
			break;
		case "3":
			$(this).text("s180");
			break;
		case "4":
			$(this).text("s240");
			break;
		}	
	});
	$("#t_cel_speed td.u8Thyst4Idle").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("s30");
			break;
		case "1":
			$(this).text("s60");
			break;
		case "2":
			$(this).text("s120");
			break;
		case "3":
			$(this).text("s180");
			break;
		case "4":
			$(this).text("s240");
			break;
		}	
	});
	$("#t_cel_speed td.u8qHystMed4Idle").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("dB-6");
			break;
		case "1":
			$(this).text("dB-4");
			break;
		case "2":
			$(this).text("dB-2");
			break;
		case "3":
			$(this).text("dB0");
			break;
		}	
	});
	$("#t_cel_speed td.u8qHystHigh4Idle").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("dB-6");
			break;
		case "1":
			$(this).text("dB-4");
			break;
		case "2":
			$(this).text("dB-2");
			break;
		case "3":
			$(this).text("dB0");
			break;
		}	
	});
	$("#t_cel_speed td.u8tRslIntraEutraSF4Mid").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	$("#t_cel_speed td.u8tRslIntraEutraSF4High").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	
	$("#t_cel_speed td.u8tRslInterEutraSF4Mid").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	
	$("#t_cel_speed td.u8tRslInterEutraSF4High").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	$("#t_cel_speed td.u8MS4ConnectEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关");
			break;
		case "1":
			$(this).text("开");
			break;
		}	
	});
	$("#t_cel_speed td.u8Teval4Connect").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("s30");
			break;
		case "1":
			$(this).text("s60");
			break;
		case "2":
			$(this).text("s120");
			break;
		case "3":
			$(this).text("s180");
			break;
		case "4":
			$(this).text("s240");
			break;
		}	
	});
	$("#t_cel_speed td.u8Thyst4Connect").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("s30");
			break;
		case "1":
			$(this).text("s60");
			break;
		case "2":
			$(this).text("s120");
			break;
		case "3":
			$(this).text("s180");
			break;
		case "4":
			$(this).text("s240");
			break;
		}	
	});
	$("#t_cel_speed td.u8qHystMed4Connect").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	$("#t_cel_speed td.u8qHystHigh4Connect").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("oDot25");
			break;
		case "1":
			$(this).text("oDot5");
			break;
		case "2":
			$(this).text("oDot75");
			break;
		case "3":
			$(this).text("lDot0");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_speed"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_speed"
	});
});

