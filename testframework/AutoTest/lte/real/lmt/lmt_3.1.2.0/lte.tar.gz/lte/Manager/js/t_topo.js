$(function(){
	//表单校验
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u8TopoNO").val()) && $("#u8TopoNO").val()<=255  && $("#u8TopoNO").val()>=0)){
			$("#u8TopoNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8TopoNOError").text("");
		}
		if(!(isNum.test($("#u8FiberPort").val()) && $("#u8FiberPort").val()<=2  && $("#u8FiberPort").val()>=0)){
			$("#u8FiberPortError").text("/* 请输入0~2之间的整数 */");
			index++;
		}else{
			$("#u8FiberPortError").text("");
		}
		if($("#u8MRackNO option").length<1){
			$("#u8MRackNOError").text("/* 没有可用的机架号选项 */");
			index++;
		}else{
//			if($("#u8MRackNO").val() == $("#u8SRackNO").val()){
//				$("#u8MRackNOError").text("/* 主、从机架号不可相同 */");
//				index++;
//			}else{
//				$("#u8MRackNOError").text("");
//			}	
			$("#u8MRackNOError").text("");
		}
		if($("#u8MShelfNO option").length<1){
			$("#u8MShelfNOError").text("/* 没有可用的机框号选项 */");
			index++;
		}else{
	//		if($("#u8MShelfNO").val() == $("#u8SShelfNO").val()){
//				$("#u8MShelfNOError").text("/* 主、从机框号不可相同 */");
//				index++;
//			}else{
//				$("#u8MShelfNOError").text("");
//			}
			$("#u8MShelfNOError").text("");
		}
		if($("#u8MSlotNO option").length<1){
			$("#u8MSlotNOError").text("/* 没有可用的槽位号选项 */");
			index++;
		}else{
//			if($("#u8MSlotNO").val() == $("#u8SSlotNO").val()){
//				$("#u8MSlotNOError").text("/* 主、从槽位号不可相同 */");
//				index++;
//			}else{
//				$("#u8MSlotNOError").text("");
//			}
			$("#u8MSlotNOError").text("");
		}
		if($("#u8SRackNO option").length<1){
			$("#u8SRackNOError").text("/* 没有可用的机架号选项 */");
			index++;
		}else{
//			if($("#u8SRackNO").val() == $("#u8MRackNO").val()){
//				$("#u8SRackNOError").text("/* 主、从机架号不可相同 */");
//				index++;
//			}else{
//				$("#u8SRackNOError").text("");
//			}
			$("#u8SRackNOError").text("");
		}
		if($("#u8SShelfNO option").length<1){
			$("#u8SShelfNOError").text("/* 没有可用的机框号选项 */");
			index++;
		}else{
//			if($("#u8MShelfNO").val() == $("#u8SShelfNO").val()){
//				$("#u8SShelfNOError").text("/* 主、从机框号不可相同 */");
//				index++;
//			}else{
//				$("#u8SShelfNOError").text("");
//			}
			$("#u8SShelfNOError").text("");
		}
		if($("#u8SSlotNO option").length<1){
			$("#u8SSlotNOError").text("/* 没有可用的槽位号选项 */");
			index++;
		}else{
//			if($("#u8MSlotNO").val() == $("#u8SSlotNO").val()){
//				$("#u8SSlotNOError").text("/* 主、从槽位号不可相同 */");
//				index++;
//			}else{
//				$("#u8SSlotNOError").text("");
//			}
			$("#u8SSlotNOError").text("");
		}
		
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_topo"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_topo tr").each(function(index){
		$("#t_topo tr:eq("+index+") td:eq(9)").click(function(){
			var u8TopoNO = $("#t_topo tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_topo&u8TopoNO="+u8TopoNO+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_topo input[type=checkbox]").each(function(index){
			if($("#t_topo input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_topo tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_topo&u8TopoNO="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_topo"
	});		   
});