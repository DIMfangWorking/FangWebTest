$(function(){
	//表单校验
	var isNum=/^(-)?\d+$/;
	var isStep=/^-?\d+(\.\d{1}){0,1}$/;
	var isEnbId=/^[a-fA-F0-9]{1,}$/;
	$("#submit_add").click(function(){
		
		//
		var au8MCC1 = $("#au8MCC1").val()+"";
		if(au8MCC1.length<2){
			au8MCC1 = "0" + au8MCC1;	
		}
		var au8MCC2 = $("#au8MCC2").val()+"";
		if(au8MCC2.length<2){
			au8MCC2 = "0" + au8MCC2;	
		}
		var au8MCC3 = $("#au8MCC3").val()+""
		if(au8MCC3.length<2){
			au8MCC3 = "0" + au8MCC3;	
		}
		$("#au8MCC").val(au8MCC1+au8MCC2+au8MCC3);
		//							
		var au8MNC1 = $("#au8MNC1").val()+"";
		if(au8MNC1.length<2){
			au8MNC1 = "0" + au8MNC1;	
		}
		var au8MNC2 = $("#au8MNC2").val()+"";
		if(au8MNC2.length<2){
			au8MNC2 = "0" + au8MNC2;	
		}
		var au8MNC3 = $("#au8MNC3").val()+"";
		if(au8MNC3.length<2){
			au8MNC3 = "0" + au8MNC3;	
		}
		$("#au8MNC").val(au8MNC1+au8MNC2+au8MNC3);	
		//
		var index = 0;
		if(!(isNum.test($("#u8SvrCID").val()) && $("#u8SvrCID").val()<=254  && $("#u8SvrCID").val()>=0)){
			$("#u8SvrCIDError").text("/* 请输入0~254之间的整数 */");
			index++;
		}else{
			$("#u8SvrCIDError").text("");
		}
		
		var u32NbreNBID = $("#u32NbreNBID").val()+"";
		var lengthCoco = u32NbreNBID.length;		
		if(lengthCoco!=8 || !(isEnbId.test(u32NbreNBID)) || parseInt(u32NbreNBID,16) > 1048575){
			$("#u32NbreNBIDError").text("/* 8位,00000000~000FFFFF */");
			index++;
		}else{
			var u32NbreNBIDCoco = parseInt(u32NbreNBID,16);
			$("#u32NbreNBIDCoco").val(u32NbreNBIDCoco);
			$("#u32NbreNBIDError").text("");
		}
		
		if(!(isNum.test($("#u8NbrCID").val()) && $("#u8NbrCID").val()<=255  && $("#u8NbrCID").val()>=0)){
			$("#u8NbrCIDError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8NbrCIDError").text("");
		}
		if(!(isNum.test($("#u16TAC").val()) && $("#u16TAC").val()<=65535 && $("#u16TAC").val()>=0)){
			$("#u16TACError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u16TACError").text("");
		}		
		if(!(isNum.test($("#u16PhyCellId").val()) && $("#u16PhyCellId").val()<=503  && $("#u16PhyCellId").val()>=0)){
			$("#u16PhyCellIdError").text("/* 请输入0~503之间的整数 */");
			index++;
		}else{
			$("#u16PhyCellIdError").text("");
		}
		if(!(isNum.test($("#u8CenterFreqCfgIdx").val()) && $("#u8CenterFreqCfgIdx").val()<=255  && $("#u8CenterFreqCfgIdx").val()>=0)){
			$("#u8CenterFreqCfgIdxError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8CenterFreqCfgIdxError").text("");
		}
		
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	//u32Status
	$("#t_cel_nbrcel1 tr").each(function(index){
										 
		var u32NbreNBID = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(1)").text();
		var u32NbreNBIDHex = parseInt(u32NbreNBID).toString(16) + "";
		var lengthCo = u32NbreNBIDHex.length;
		if(lengthCo <8){
			for(var i=0 ;i<8-lengthCo ;i++){
				u32NbreNBIDHex = "0" + u32NbreNBIDHex;	
			}	
		}
		$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(1)").text(u32NbreNBIDHex);
		//
		if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 0){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-24");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 1){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-22");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 2){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-20");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 3){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-18");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 4){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-16");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 5){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-14");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 6){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-12");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 7){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-10");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 8){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-8");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 9){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-6");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 10){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-5");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 11){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-4");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 12){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-3");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 13){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-2");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 14){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("-1");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 15){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("0");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 16){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("1");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 17){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("2");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 18){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("3");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 19){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("4");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 20){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("5");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 21){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("6");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 22){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("8");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 23){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("10");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 24){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("12");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 25){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("14");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 26){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("16");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 27){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("18");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 28){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("20");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text() == 29){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("22");
		}else{
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(8)").text("24");
		}
		//
		if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 0){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-24");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 1){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-22");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 2){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-20");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 3){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-18");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 4){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-16");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 5){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-14");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 6){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-12");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 7){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-10");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 8){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-8");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 9){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-6");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 10){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-5");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 11){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-4");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 12){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-3");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 13){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-2");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 14){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("-1");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 15){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("0");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 16){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("1");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 17){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("2");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 18){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("3");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 19){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("4");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 20){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("5");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 21){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("6");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 22){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("8");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 23){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("10");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 24){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("12");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 25){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("14");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 26){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("16");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 27){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("18");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 28){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("20");
		}else if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text() == 29){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("22");
		}else{
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(9)").text("24");
		}		
		//
		if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(10)").text() == 0){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(10)").text("否");
		}else{
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(10)").text("是");
		}
		//
		if($("#t_cel_nbrcel1 tr:eq("+index+") td:eq(11)").text() == 0){
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(11)").text("否");
		}else{
			$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(11)").text("是");
		}		
		//
		
		var au8MCC = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(3)").text().split("");
		var s1 = au8MCC[0] + au8MCC[1];
		if(parseInt(parseInt(s1,16).toString(10)) != 255){
			s1 = au8MCC[1];	
		}
		var s2 = au8MCC[2] + au8MCC[3];
		if(parseInt(parseInt(s2,16).toString(10)) != 255){
			s2 = au8MCC[3];	
		}
		var s3 = au8MCC[4] + au8MCC[5];
		
		if(parseInt(parseInt(s3,16).toString(10)) != 255){
			s3 = au8MCC[5];	
		}
		$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(3)").text(s1+" , "+s2+" , "+s3);
		
		//
		var au8MNC = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(4)").text().split("");
		var sq1 = au8MNC[0] + au8MNC[1];
		if(parseInt(parseInt(sq1,16).toString(10)) != 255){
			sq1 = au8MNC[1];	
		}
		var sq2 = au8MNC[2] + au8MNC[3];
		if(parseInt(parseInt(sq2,16).toString(10)) != 255){
			sq2 = au8MNC[3];	
		}
		var sq3 = au8MNC[4] + au8MNC[5];
		if(parseInt(parseInt(sq3,16).toString(10)) != 255){
			sq3 = au8MNC[5];	
		}
		$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(4)").text(sq1+" , "+sq2+" , "+sq3);
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_nbrcel"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_cel_nbrcel1 tr").each(function(index){
		$("#t_cel_nbrcel1 tr:eq("+index+") td:eq(14)").click(function(){
			var u8SvrCID = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(0)").text();
			var u32NbreNBIDHex = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(1)").text();
			var u32NbreNBID = parseInt(u32NbreNBIDHex,16);
			var u8NbrCID = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(2)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_cel_nbrcel&u8SvrCID="+u8SvrCID+"&u32NbreNBID="+u32NbreNBID+"&u8NbrCID="+u8NbrCID+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str1=[];
		var str2=[];
		var str3=[];
		$("#t_cel_nbrcel1 input[type=checkbox]").each(function(index){
			if($("#t_cel_nbrcel1 input[type=checkbox]:eq("+index+")").attr("checked")){
				if(index != 0){
					var temp1 = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(0)").text();
					var temp2Hex = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(1)").text();
					var temp2 = parseInt(temp2Hex,16);
					var temp3 = $("#t_cel_nbrcel1 tr:eq("+index+") td:eq(2)").text();
					str1.push(temp1);
					str2.push(temp2);
					str3.push(temp3);
				}				
			}
		});	
		for(var i=0;i<str1.length;i++){
			if(str1[i]== "" || str1[i]== null){
				str1.splice(i,1);
			}
		}
		for(var i=0;i<str2.length;i++){
			if(str2[i]== "" || str2[i]== null){
				str2.splice(i,1);
			}
		}
		for(var i=0;i<str3.length;i++){
			if(str3[i]== "" || str3[i]== null){
				str3.splice(i,1);
			}
		}
		if(str1.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_cel_nbrcel&u8SvrCID="+str1+"&u32NbreNBID="+str2+"&u8NbrCID="+str3+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_cel_nbrcel"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_cel_nbrcel"
	});
});