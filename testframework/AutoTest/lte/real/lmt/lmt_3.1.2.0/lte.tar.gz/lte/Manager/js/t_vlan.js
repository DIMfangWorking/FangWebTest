$(function(){
	//表单校验
	//整数正则
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8Id",10,1)){
			index++;
			$("#u8IdError").text(dynamicInfo(10000,generateArgments_i18n_num(10,1)));
		}
		if(!checkInputInForm(isNum,"u16VlanId",4094,1)){
			index++;
			$("#u16VlanIdError").text(dynamicInfo(10000,generateArgments_i18n_num(4094,1)));
		}
		if(!checkInputInForm(isNum,"u8VlanPri",7,0)){
			index++;
			$("#u8VlanPriError").text(dynamicInfo(10000,generateArgments_i18n_num(7,0)));
		}
		if(index==0){
			//if(confirm(constantInfoMap["vlan_confirm"])){ 
				$("#form_add").submit();
			//}		
		}		
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_vlan"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_vlan"
	});
});

