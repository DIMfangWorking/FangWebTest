$(function(){
	//表单校验
	//整数正则
	var isNum=/^(-)?\d+$/;
	//精确至0.1的正则
	var isFloatPointOne = /^-?\d+(\.\d{1}){0,1}$/;
	//精确至0.01的正则
	var isFloatPointTwo = /^-?\d+(\.\d{1,2}){0,1}$/;
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if($("#u8LoadA4MeasCfg option").length < 1){
			index++;
			$("#u8LoadA4MeasCfgError").text(constantInfoMap["no_item_exist_info"]);
		}
		if(!checkInputInForm(isNum,"u8LMTimer",30,5)){
			index++;
			$("#u8LMTimerError").text(dynamicInfo(10000,generateArgments_i18n_num(30,5)));
		}
		if(!checkInputInForm(isNum,"u8CellLBHOTimer",240,30)){
			index++;
			$("#u8CellLBHOTimerError").text(dynamicInfo(10000,generateArgments_i18n_num(240,30)));
		}
		if(!checkInputInForm(isNum,"u8LMPingpongHoTimer",240,30)){
			index++;
			$("#u8LMPingpongHoTimerError").text(dynamicInfo(10000,generateArgments_i18n_num(240,30)));
		}				
		if(!checkInputInForm(isFloatPointTwo,"u8MediumLoadThr",1,0.01)){
			index++;
			$("#u8MediumLoadThrError").text(dynamicInfo(10002,generateArgments_i18n_num(1,0.01)));
		}
		if(!checkInputInForm(isFloatPointTwo,"u8HighLoadThr",1,0.01)){
			index++;
			$("#u8HighLoadThrError").text(dynamicInfo(10002,generateArgments_i18n_num(1,0.01)));
		}
		if(!checkInputInForm(isFloatPointTwo,"u8LoadHysteresis",0.08,0.01)){
			index++;
			$("#u8LoadHysteresisError").text(dynamicInfo(10002,generateArgments_i18n_num(0.08,0.01)));
		}
		if(checkInputInForm(isFloatPointTwo,"u8MediumLoadThr",1,0.01) && checkInputInForm(isFloatPointTwo,"u8HighLoadThr",1,0.01) && checkInputInForm(isFloatPointTwo,"u8LoadHysteresis",0.08,0.01)){
			if(accAdd($("#u8MediumLoadThr").val(),accMul($("#u8LoadHysteresis").val(),2)) > $("#u8HighLoadThr").val()){
				index++;
				$("#u8HighLoadThrError").text("/* 中负载阈值+2*负载迟滞不可大于高负载阈值 */");
			}
		}
		if(!checkInputInForm(isFloatPointOne,"u8PriWeighFactor",1,0.1)){
			index++;
			$("#u8PriWeighFactorError").text(dynamicInfo(10001,generateArgments_i18n_num(1,0.1)));
		}
		
		if(!checkInputInForm(isNum,"u8UENumChangeInList",20,1)){
			index++;
			$("#u8UENumChangeInListError").text(dynamicInfo(10000,generateArgments_i18n_num(20,1)));
		}
		if(!checkInputInForm(isNum,"u8MaxUENumInList",100,1)){
			index++;
			$("#u8MaxUENumInListError").text(dynamicInfo(10000,generateArgments_i18n_num(100,1)));
		}
		if(checkInputInForm(isNum,"u8UENumChangeInList",20,1) && checkInputInForm(isNum,"u8MaxUENumInList",100,1)){
			if($("#u8MaxUENumInList").val() < $("#u8UENumChangeInList").val()){
				index++;
				$("#u8MaxUENumInListError").text("/* 不可小于每次为UE列表增加/删除的用户数 */");
			}
		}
		$("input[name='u8EnbLoadCfgIdx']").val($("#u8EnbLoadCfgIdx").val());
		$("input[name='u8MediumLoadThr']").val(accMul($("#u8MediumLoadThr").val(),100));
		$("input[name='u8HighLoadThr']").val(accMul($("#u8HighLoadThr").val(),100));
		$("input[name='u8LoadHysteresis']").val(accMul($("#u8LoadHysteresis").val(),100));
		$("input[name='u8PriWeighFactor']").val(accMul($("#u8PriWeighFactor").val(),10));
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_enb_load td.u8MediumLoadThr").each(function(){
		var value = $.trim($(this).text());
		if(value != null && typeof(value) != "undefined" && value != ""){
			$(this).text(accDiv(value,100));
		}	
	});
	$("#t_enb_load td.u8HighLoadThr").each(function(){
		var value = $.trim($(this).text());
		if(value != null && typeof(value) != "undefined" && value != ""){
			$(this).text(accDiv(value,100));
		}
		
	});
	$("#t_enb_load td.u8LoadHysteresis").each(function(){
		var value = $.trim($(this).text());
		if(value != null && typeof(value) != "undefined" && value != ""){
			$(this).text(accDiv(value,100));
		}
		
	});
	$("#t_enb_load td.u8PriWeighFactor").each(function(){
		var value = $.trim($(this).text());
		if(value != null && typeof(value) != "undefined" && value != ""){
			$(this).text(accDiv(value,10));
		}		
	});

	$("#t_enb_load td.b8LBEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	$("#t_enb_load td.b8LCEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	
	$("#t_enb_load td.u8LoadRptPeriod").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("1");
			break;
		case "1":
			$(this).text("2");
			break;
		case "2":
			$(this).text("5");
			break;
		case "3":
			$(this).text("10");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_load"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_load"
	});
});

