$(function(){
	//表单校验
	var isNum=/^\d+$/;
	var isEnbId=/^[a-fA-F0-9]{1,}$/;
	var isCoco=/^[A-Za-z0-9\u4e00-\u9fa5_]+$/;
	$("#submit_add").click(function(){
		var au8EEA1 = "0" + $("#au8EEA1").val();													
		var au8EEA2 = "0" + $("#au8EEA2").val();								
		var au8EEA3 = "0" + $("#au8EEA3").val();
		
		var au8EIA1 = "0" + $("#au8EIA1").val();													
		var au8EIA2 = "0" + $("#au8EIA2").val();								
		var au8EIA3 = "0" + $("#au8EIA3").val();
		
		$("#au8EEA").val(au8EEA1+au8EEA2+au8EEA3);
		$("#au8EIA").val(au8EIA1+au8EIA2+au8EIA3);
		
		var index = 0;
		if(!(isNum.test($("#u16EndTmpRNTI").val()) && $("#u16EndTmpRNTI").val()<=65523  && $("#u16EndTmpRNTI").val()>=10000)){
			$("#u16EndTmpRNTIError").text("/* 请输入10000~65523之间的整数 */");
			index++;
		}else{
			$("#u16EndTmpRNTIError").text("");
		}
		
		var u32eNBId = $("#u32eNBId").val()+"";
		var lengthCoco = u32eNBId.length;		
		if(lengthCoco!=8 || !(isEnbId.test(u32eNBId)) || parseInt(u32eNBId,16) > 1048575){
			$("#u32eNBIdError").text("/* 8位,00000000~000FFFFF */");
			index++;
		}else{
			var u32eNBIdCoco = parseInt(u32eNBId,16);
			$("#u32eNBIdCoco").val(u32eNBIdCoco);
			$("#u32eNBIdError").text("");
		}
		
		var au8eNBName = $("#au8eNBName").val() + "";
		var length = au8eNBName.length;
		if(length <1){
			$("#au8eNBNameError").text("/* 请输入名称 */");
			index++;
		}else if(length >128){
			$("#au8eNBNameError").text("/* 名称过长 */");
			index++;
		}else if(!isCoco.test(au8eNBName)){
			$("#au8eNBNameError").text("/* 只可输入数字和字母 */");
			index++;
		}else {
			$("#au8eNBNameError").text("");	
		}
		//判断两两不等							
//		for(var i=1;i<4;i++){
//			for(var j=i+1;j<4;j++){
//				if($("#au8EEA"+i).val() == $("#au8EEA"+j).val()){
//					index++;
//					$("#au8EEAError"+i).text("/* 加密算法优先级不可重复 */");
//					$("#au8EEAError"+j).text("/* 加密算法优先级不可重复 */");
//					return ;
//				}else{
//					$("#au8EEAError"+i).text("");
//					$("#au8EEAError"+j).text("");
//				}
//			}
//			
//		}
		//判断两两不等							
//		for(var i=1;i<4;i++){
//			for(var j=i+1;j<4;j++){
//				if($("#au8EIA"+i).val() == $("#au8EIA"+j).val()){
//					index++;
//					$("#au8EIAError"+i).text("/* 完整性保护算法优先级不可重复 */");
//					$("#au8EIAError"+j).text("/* 完整性保护算法优先级不可重复 */");
//					return ;
//				}else{
//					$("#au8EIAError"+i).text("");
//					$("#au8EIAError"+j).text("");
//				}
//			}
//			
//		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_enb_para tr").each(function(index){
		var u32eNBId = $("#t_enb_para tr:eq("+index+") td:eq(0)").text();
		var u32eNBIdHex = parseInt(u32eNBId).toString(16) + "";
		var lengthCo = u32eNBIdHex.length;
		if(lengthCo <8){
			for(var i=0 ;i<8-lengthCo ;i++){
				u32eNBIdHex = "0" + u32eNBIdHex;	
			}	
		}
		$("#t_enb_para tr:eq("+index+") td:eq(0)").text(u32eNBIdHex);
		//u8PageDrxCyc
		if($("#t_enb_para tr:eq("+index+") td:eq(4)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(4)").text("32");
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(4)").text() == 1){
			$("#t_enb_para tr:eq("+index+") td:eq(4)").text("64");
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(4)").text() == 2){
			$("#t_enb_para tr:eq("+index+") td:eq(4)").text("128");
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(4)").text() == 3){
			$("#t_enb_para tr:eq("+index+") td:eq(4)").text("256");
		}
		
		var au8EEA = $("#t_enb_para tr:eq("+index+") td:eq(2)").text().split("");
		$("#t_enb_para tr:eq("+index+") td:eq(2)").text("Snow3G - AES - 祖冲之算法 ("+au8EEA[1]+"-"+au8EEA[3]+"-"+au8EEA[5]+")");
		var au8EIA = $("#t_enb_para tr:eq("+index+") td:eq(3)").text().split("");
		$("#t_enb_para tr:eq("+index+") td:eq(3)").text("Snow3G - AES - 祖冲之算法 ("+au8EIA[1]+"-"+au8EIA[3]+"-"+au8EIA[5]+")");
		
		if($("#t_enb_para tr:eq("+index+") td:eq(6)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(6)").text("否");
		}else{
			$("#t_enb_para tr:eq("+index+") td:eq(6)").text("是");	
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(7)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(7)").text("Not Need");
		}else{
			$("#t_enb_para tr:eq("+index+") td:eq(7)").text("Need");
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("100ms");
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 1){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("500ms");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 2){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("1s");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 3){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("2s");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 4){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("5s");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 5){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("10s");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 6){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("30s");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 7){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("1min");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 8){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("5min");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 9){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("10min");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 10){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("30min");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 11){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("1h");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 12){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("2h");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 13){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("5h");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 14){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("10h");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 15){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("1day");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 16){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("2days");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 17){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("5days");	
		}else if($("#t_enb_para tr:eq("+index+") td:eq(8)").text() == 18){
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("10days");	
		}else{
			$("#t_enb_para tr:eq("+index+") td:eq(8)").text("30days");	
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(9)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(9)").text("Normal");
		}else if($("#t_enb_para tr:eq("+index+") td:eq(9)").text() == 1){
			$("#t_enb_para tr:eq("+index+") td:eq(9)").text("Single");	
		}else{
			$("#t_enb_para tr:eq("+index+") td:eq(9)").text("Auto");
		}
		if($("#t_enb_para tr:eq("+index+") td:eq(10)").text() == 0){
			$("#t_enb_para tr:eq("+index+") td:eq(10)").text("关");
		}else{
			$("#t_enb_para tr:eq("+index+") td:eq(10)").text("开");
		}
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_para"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_enb_para tr").each(function(index){
		$("#t_enb_para tr:eq("+index+") td:eq(12)").click(function(){
			var u32eNBIdHex = $("#t_enb_para tr:eq("+index+") td:eq(0)").text();
			var u32eNBId = parseInt(u32eNBIdHex,16);
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_enb_para&u32eNBId="+u32eNBId+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_enb_para input[type=checkbox]").each(function(index){
			if($("#t_enb_para input[type=checkbox]:eq("+index+")").attr("checked")){
				var tempHex = $("#t_enb_para tr:eq("+index+") td:eq(0)").text();
				var temp = parseInt(tempHex,16);
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_enb_para&u32eNBId="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_para"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_para"
	});
});