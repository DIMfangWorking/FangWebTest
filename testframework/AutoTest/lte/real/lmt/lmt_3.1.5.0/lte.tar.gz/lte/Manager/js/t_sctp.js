$(function(){
	//表单校验
	var isNum=/^\d+$/;
	var isIp=/^((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0))|0$/;
	$("#submit_add").click(function(){
								
		//转移值
		var au8DstIP1q = $("#au8DstIP1q").val()+"";
		var sr = "00000000";
		if(au8DstIP1q != "0"){
			var s = au8DstIP1q.split(".");
			var s1 = parseInt(s[0]).toString(16);
			if(s1.length<2){
				s1 = "0" + s1;	
			}
			var s2 = parseInt(s[1]).toString(16);
			if(s2.length<2){
				s2 = "0" + s2;	
			}
			var s3 = parseInt(s[2]).toString(16);
			if(s3.length<2){
				s3 = "0" + s3;	
			}
			var s4 = parseInt(s[3]).toString(16);
			if(s4.length<2){
				s4 = "0" + s4;	
			}		
			sr = s1+s2+s3+s4;
		}		
		$("#au8DstIP1").val(sr);	
		
		var au8DstIP2q = $("#au8DstIP2q").val()+"";
		var sqr = "00000000";
		if(au8DstIP2q != "0"){
			var sq = au8DstIP2q.split(".");
			var sq1 = parseInt(sq[0]).toString(16);
			if(sq1.length<2){
				sq1 = "0" + sq1;	
			}
			var sq2 = parseInt(sq[1]).toString(16);
			if(sq2.length<2){
				sq2 = "0" + sq2;	
			}
			var sq3 = parseInt(sq[2]).toString(16);
			if(sq3.length<2){
				sq3 = "0" + sq3;	
			}
			var sq4 = parseInt(sq[3]).toString(16);
			if(sq4.length<2){
				sq4 = "0" + sq4;	
			}		
			sqr = sq1+sq2+sq3+sq4;
		}		
		$("#au8DstIP2").val(sqr);
		
		var au8DstIP3q = $("#au8DstIP3q").val()+"";
		var swr = "00000000";
		if(au8DstIP3q != "0"){
			var sw = au8DstIP3q.split(".");
			var sw1 = parseInt(sw[0]).toString(16);
			if(sw1.length<2){
				sw1 = "0" + sw1;	
			}
			var sw2 = parseInt(sw[1]).toString(16);
			if(sw2.length<2){
				sw2 = "0" + sw2;	
			}
			var sw3 = parseInt(sw[2]).toString(16);
			if(sw3.length<2){
				sw3 = "0" + sw3;	
			}
			var sw4 = parseInt(sw[3]).toString(16);
			if(sw4.length<2){
				sw4 = "0" + sw4;	
			}		
			swr = sw1+sw2+sw3+sw4;
		}		
		$("#au8DstIP3").val(swr);
									
		var au8DstIP4q = $("#au8DstIP4q").val()+"";
		var sar = "00000000";
		if(au8DstIP4q != "0"){
			var sa = au8DstIP4q.split(".");
			var sa1 = parseInt(sa[0]).toString(16);
			if(sa1.length<2){
				sa1 = "0" + sa1;	
			}
			var sa2 = parseInt(sa[1]).toString(16);
			if(sa2.length<2){
				sa2 = "0" + sa2;	
			}
			var sa3 = parseInt(sa[2]).toString(16);
			if(sa3.length<2){
				sa3 = "0" + sa3;	
			}
			var sa4 = parseInt(sa[3]).toString(16);
			if(sa4.length<2){
				sa4 = "0" + sa4;	
			}		
			sar = sa1+sa2+sa3+sa4;
		}		
		$("#au8DstIP4").val(sar);							
									
									
		var index = 0;
		if(!(isNum.test($("#u16AssID").val()) && $("#u16AssID").val()<=48  && $("#u16AssID").val()>=1)){
			$("#u16AssIDError").text("/* 请输入1~48之间的整数 */");
			index++;
		}else{
			$("#u16AssIDError").text("");
		}
		if(!(isNum.test($("#u16LocPort").val()) && $("#u16LocPort").val()<=65535  && $("#u16LocPort").val()>=0)){
			$("#u16LocPortError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u16LocPortError").text("");
		}
		if(!(isNum.test($("#u16RemotPort").val()) && $("#u16RemotPort").val()<=65535  && $("#u16RemotPort").val()>=0)){
			$("#u16RemotPortError").text("/* 请输入0~65535之间的整数 */");
			index++;
		}else{
			$("#u16RemotPortError").text("");
		}
		$("#u16LocPort_hidden").val($("#u16LocPort").val());
		$("#u16RemotPort_hidden").val($("#u16RemotPort").val());
		if(!(isNum.test($("#u8InOutStream").val()) && $("#u8InOutStream").val()<=255  && $("#u8InOutStream").val()>=0)){
			$("#u8InOutStreamError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u8InOutStreamError").text("");
		}
		
		if(!(isIp.test($("#au8DstIP1q").val()))){
			$("#au8DstIP1qError").text("/* 请输入正确的IP地址 */");	
			index++;
		}else{
			$("#au8DstIP1qError").text("");	
		}
		if(!(isIp.test($("#au8DstIP2q").val()))){
			$("#au8DstIP2qError").text("/* 请输入正确的IP地址 */");	
			index++;
		}else{
			$("#au8DstIP2qError").text("");	
		}
		if(!(isIp.test($("#au8DstIP3q").val()))){
			$("#au8DstIP3qError").text("/* 请输入正确的IP地址 */");	
			index++;
		}else{
			$("#au8DstIP3qError").text("");	
		}
		if(!(isIp.test($("#au8DstIP4q").val()))){
			$("#au8DstIP4qError").text("/* 请输入正确的IP地址 */");	
			index++;
		}else{
			$("#au8DstIP4qError").text("");	
		}
		if($("#u8SrcIPID1 option").length<1){
			$("#u8SrcIPIDError1").text("/* 没有可用的源IP地址选项 */");
			index++;
		}else{
			$("#u8SrcIPIDError1").text("");
		}
		if($("#u8SrcIPID2 option").length<1){
			$("#u8SrcIPIDError2").text("/* 没有可用的源IP地址选项 */");
			index++;
		}else{
			$("#u8SrcIPIDError2").text("");
		}
		if($("#u8SrcIPID3 option").length<1){
			$("#u8SrcIPIDError3").text("/* 没有可用的源IP地址选项 */");
			index++;
		}else{
			$("#u8SrcIPIDError3").text("");
		}
		if($("#u8SrcIPID4 option").length<1){
			$("#u8SrcIPIDError4").text("/* 没有可用的源IP地址选项 */");
			index++;
		}else{
			$("#u8SrcIPIDError4").text("");
		}
		//判断两两不等							
		for(var i=1;i<5;i++){
			for(var j=i+1;j<5;j++){
				if(($("#u8SrcIPID"+i).val() == $("#u8SrcIPID"+j).val()) && $("#u8SrcIPID"+i).val() != 0 ){
					index++;
					$("#u8SrcIPIDError"+i).text("/* 源IP地址除为0外不可相同 */");
					$("#u8SrcIPIDError"+j).text("/* 源IP地址除为0外不可相同 */");
					return ;
				}else{
					$("#u8SrcIPIDError"+i).text("");
					$("#u8SrcIPIDError"+j).text("");
				}
			}
			
		}
		for(var i=1;i<5;i++){
			for(var j=i+1;j<5;j++){
				if(!isIp.test($("#au8DstIP"+i+"q").val())){
					index++;
					$("#au8DstIP"+i+"qError").text("/* 请输入正确的IP地址 */");
					return;
				}
				if(!isIp.test($("#au8DstIP"+j+"q").val())){
					index++;
					$("#au8DstIP"+j+"qError").text("/* 请输入正确的IP地址 */");
					return;
				}
				if(($("#au8DstIP"+i).val() == $("#au8DstIP"+j).val()) && $("#au8DstIP"+i).val() != "00000000"){
					index++;
					$("#au8DstIP"+i+"qError").text("/* 目的IP地址除为0外不可相同 */");
					$("#au8DstIP"+j+"qError").text("/* 目的IP地址除为0外不可相同 */");
					return ;
				}else{
					$("#au8DstIP"+i+"qError").text("");
					$("#au8DstIP"+j+"qError").text("");
				}
			}
			
		}
		$("input[name='u8LinkType']").val($("input[name='u8LinkType_h']:checked").val());
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//内存值转为显示值
	$("#t_sctp1 tr").each(function(index){
		//u8ManualOP
		if($("#t_sctp1 tr:eq("+index+") td.u8ManualOP").text() == 0){
			$("#t_sctp1 tr:eq("+index+") td.u8ManualOP").text("解闭塞");
		}else{
			$("#t_sctp1 tr:eq("+index+") td.u8ManualOP").text("闭塞");
		}	
		//u32Status
		if($("#t_sctp1 tr:eq("+index+") td.u32Status").text() == 0){
			$("#t_sctp1 tr:eq("+index+") td.u32Status").text("正常");
		}else{
			$("#t_sctp1 tr:eq("+index+") td.u32Status").text("不正常");
		}	
		//u8LinkType
		if($("#t_sctp1 tr:eq("+index+") td.u8LinkType").text() == 0){
			$("#t_sctp1 tr:eq("+index+") td.u8LinkType").text("S1");
		}else{
			$("#t_sctp1 tr:eq("+index+") td.u8LinkType").text("X2");
		}	
		//u8AssocStatus
		if($("#t_sctp1 tr:eq("+index+") td.u8AssocStatus").text() == 0){
			$("#t_sctp1 tr:eq("+index+") td.u8AssocStatus").text("正常");
		}else{
			$("#t_sctp1 tr:eq("+index+") td.u8AssocStatus").text("不正常");
		}	
		
		var au8DstIP1 = $("#t_sctp1 tr:eq("+index+") td.au8DstIP1").text();	
		var result1 = "0";
		if(au8DstIP1 != "00000000"){
			au8DstIP1 = au8DstIP1.split("");
			var str1 = au8DstIP1[0] + au8DstIP1[1] ;
			var str2 = au8DstIP1[2] + au8DstIP1[3] ;
			var str3 = au8DstIP1[4] + au8DstIP1[5] ;
			var str4 = au8DstIP1[6] + au8DstIP1[7] ;
			var no1 = parseInt(str1,16).toString(10);
			var no2 = parseInt(str2,16).toString(10);
			var no3 = parseInt(str3,16).toString(10);
			var no4 = parseInt(str4,16).toString(10);
			result1 = no1 + "." + no2 + "." + no3 + "." + no4;	
		}			
		$("#t_sctp1 tr:eq("+index+") td.au8DstIP1").text(result1);	
	});	
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_sctp"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_sctp1 tr").each(function(index){
		$("#t_sctp1 tr:eq("+index+") td:eq(10)").click(function(){
			var u16AssID  = $("#t_sctp1 tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_sctp&u16AssID="+u16AssID +"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_sctp1 input[type=checkbox]").each(function(index){
			if($("#t_sctp1 input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_sctp1 tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_sctp&u16AssID="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_sctp"
	});
});
function setU8SrcIPID1(u8LinkType){
	if(u8LinkType == 1){
		$("#u16LocPort").val(36422);
		$("#u16RemotPort").val(36422);
		$("#u16LocPort").attr("disabled","disabled");
		$("#u16RemotPort").attr("disabled","disabled");
	}else{
		$("#u16LocPort").val(36412);
		$("#u16RemotPort").val(36412);
		$("#u16LocPort").attr("disabled",false);
		$("#u16RemotPort").attr("disabled",false);
	}
}