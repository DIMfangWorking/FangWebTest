$(function(){
	//表单校验
	//整数正则
	var isNum=/^(-)?\d+$/;

	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if(!checkInputInForm(isNum,"u8CfgIndex",255,0)){
			index++;
			$("#u8CfgIndexError").text(dynamicInfo(10000,generateArgments_i18n_num(255,0)));
		}
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_enb_alg td.u8RtpTrafficQualityParse").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	$("#t_enb_alg td.u8TcpTrafficQualityParse").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	$("#t_enb_alg td.u8CheckSumJudge").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_alg"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_alg"
	});
});
function setU8CheckSumJudge(u8TcpTrafficQualityParse){
	if(u8TcpTrafficQualityParse == 0){
		$("#u8CheckSumJudge_1").attr("disabled","disabled");
		checkRadio("u8CheckSumJudge","0");
	}else{
		$("#u8CheckSumJudge_1").attr("disabled",false);
	}
}

