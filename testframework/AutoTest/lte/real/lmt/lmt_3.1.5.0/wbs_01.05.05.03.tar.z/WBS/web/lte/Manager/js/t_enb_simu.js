$(function(){
	//表单校验
	//整数正则
	var isNum=/^(-)?\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		
		if(!checkInputInForm(isNum,"u8CfgIdx",255,0)){
			index++;
			$("#u8CfgIdxError").text(dynamicInfo(10000,generateArgments_i18n_num(255,0)));
		}
		if(!checkInputInForm(isNum,"u8SyncSeqSndDelay",15,0)){
			index++;
			$("#u8SyncSeqSndDelayError").text(dynamicInfo(10000,generateArgments_i18n_num(15,0)));
		}
		if(!checkInputInForm(isNum,"u8SCSignalMCS",28,0)){
			index++;
			$("#u8SCSignalMCSError").text(dynamicInfo(10000,generateArgments_i18n_num(28,0)));
		}
		if(!checkInputInForm(isNum,"u8SCDataMCS",28,0)){
			index++;
			$("#u8SCDataMCSError").text(dynamicInfo(10000,generateArgments_i18n_num(28,0)));
		}
		if(!checkInputInForm(isNum,"u8SCMaxRBRatio",100,0)){
			index++;
			$("#u8SCMaxRBRatioError").text(dynamicInfo(10000,generateArgments_i18n_num(100,0)));
		}
		
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_enb_simu td.u8SCMaxRBRatio").each(function(){
		var value = $.trim($(this).text());
		if(value != null && typeof(value) != "undefined" && value != ""){
			$(this).text(value+"%");
		}	
	});
	$("#t_enb_simu td.u8SyncSeqSndStrategy").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("Send");
			break;
		case "1":
			$(this).text("Discard");
			break;
		}	
	});
	$("#t_enb_simu td.u8SCEnable").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	
	$("#t_enb_simu td.u8SyncPeriod").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("128");
			break;
		case "1":
			$(this).text("256");
			break;
		case "2":
			$(this).text("512");
			break;
		case "3":
			$(this).text("1024");
			break;
		case "4":
			$(this).text("2048");
			break;
		case "5":
			$(this).text("4096");
			break;
		case "6":
			$(this).text("8192");
			break;
		case "7":
			$(this).text("16384");
			break;
		}	
	});
	$("#t_enb_simu td.u8SyncSeq").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("20");
			break;
		case "1":
			$(this).text("40");
			break;
		case "2":
			$(this).text("80");
			break;
		case "3":
			$(this).text("160");
			break;
		case "4":
			$(this).text("320");
			break;
		case "5":
			$(this).text("640");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_enb_simu"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_enb_simu"
	});
});

