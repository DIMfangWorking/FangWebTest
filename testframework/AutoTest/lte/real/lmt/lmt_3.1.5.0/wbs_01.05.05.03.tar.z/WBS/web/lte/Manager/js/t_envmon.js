$(function(){
	//表单校验
	var isNum=/^\d+$/;
	var isMac=/^[0-9A-Fa-f]{2}$/;
	$("#submit_add").click(function(){
		var index = 0;
		if(!(isNum.test($("#u32EnvMNO").val()) && $("#u32EnvMNO").val()<=255  && $("#u32EnvMNO").val()>=0)){
			$("#u32EnvMNOError").text("/* 请输入0~255之间的整数 */");
			index++;
		}else{
			$("#u32EnvMNOError").text("");
		}
		
		if(!(isNum.test($("#u32EnvMType").val()) && $("#u32EnvMType").val()<=2147483647  && $("#u32EnvMType").val()>=0)){
			$("#u32EnvMTypeError").text("/* 请输入0~2147483647之间的整数 */");
			index++;
		}else{
			$("#u32EnvMTypeError").text("");
		}
		if(!(isNum.test($("#u32EnvMax").val()) && $("#u32EnvMax").val()<=2147483647  && $("#u32EnvMax").val()>=0)){
			$("#u32EnvMaxError").text("/* 请输入0~2147483647之间的整数 */");
			index++;
		}else{
			$("#u32EnvMaxError").text("");
		}
		if(!(isNum.test($("#u32EnvMin").val()) && $("#u32EnvMin").val()<=2147483647  && $("#u32EnvMin").val()>=0)){
			$("#u32EnvMinError").text("/* 请输入0~2147483647之间的整数 */");
			index++;
		}else if(parseInt($("#u32EnvMin").val()) > parseInt($("#u32EnvMax").val())){
			$("#u32EnvMinError").text("/* 监控最小值不可大于监控最大值 */");	
			index++;
		}else{
			$("#u32EnvMinError").text("");
		}
		if(!(isNum.test($("#u32Rsv").val()) && $("#u32Rsv").val()<=2147483647  && $("#u32Rsv").val()>=0)){
			$("#u32RsvError").text("/* 请输入0~2147483647之间的整数 */");
			index++;
		}else{
			$("#u32RsvError").text("");
		}
		
		if($("#u8RackNO option").length<1){
			$("#u8RackNOError").text("/* 没有可用的机架号选项 */");
			index++;
		}else{
			$("#u8RackNOError").text("");
		}
		if($("#u8ShelfNO option").length<1){
			$("#u8ShelfNOError").text("/* 没有可用的机框号选项 */");
			index++;
		}else{
			$("#u8ShelfNOError").text("");
		}
		if($("#u8SlotNO option").length<1){
			$("#u8SlotNOError").text("/* 没有可用的槽位号选项 */");
			index++;
		}else{
			$("#u8SlotNOError").text("");
		}
		if(index==0){
			$("#form_add").submit();	
		}
		
	});
	//刷新按钮
	$("#fresh").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_envmon"
	});
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});
	//删除
	$("#t_envmon tr").each(function(index){
		$("#t_envmon tr:eq("+index+") td:eq(9)").click(function(){
			var u32EnvMNO = $("#t_envmon tr:eq("+index+") td:eq(0)").text();
			if(confirm("确定要删除该条记录?")){
				window.location.href=
				"lteBts?operationType=delete&target=single&tableName=t_envmon&u32EnvMNO="+u32EnvMNO+"";
			}
		});					   
	});	
	//批量删除
	$("#delete").click(function(){
		var str=[];
		$("#t_envmon input[type=checkbox]").each(function(index){
			if($("#t_envmon input[type=checkbox]:eq("+index+")").attr("checked")){
				var temp = $("#t_envmon tr:eq("+index+") td:eq(0)").text();
				str.push(temp);
			}
		});	
		for(var i=0;i<str.length;i++){
			if(str[i]== "" || str[i]== null){
				str.splice(i,1);
			}
		}
		if(str.length < 1){
			alert("您并未选中任何记录...");
		}else{
			if(confirm("确定要删除所有选择的记录?")){
				window.location.href="lteBts?operationType=delete&target=multi&tableName=t_envmon&u32EnvMNO="+str+"";
			}
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_envmon"
	});
});