//固定的提示信息----中文
var constantInfoMap_zh = {
	"no_selected_item_info":"您并未选中任何记录...",
	"confirm_deleteAll_info":"确定要删除所有选择的记录?",
	"confirm_delete_info":"确定要删除该条记录?",
	"no_item_exist_info":"/* 没有可用的选项 */",
	"vlan_confirm":"进行此操作后需要复位基站,确定进行此操作?"
};

//固定的提示信息----英文
var constantInfoMap_en = {
	"no_selected_item_info":"no record has been selected...",
	"confirm_deleteAll_info":"confirm to delete all the selected records?",
	"confirm_delete_info":"confirm to delete the selected record?",
	"no_item_exist_info":"/* no items can be selected */",
	"vlan_confirm":"you must restart the eNB later,confirm to do this ?"
};

//最终选择的固定提示信息的map
var constantInfoMap = null;

//当前语言环境
var i18n_type = "zh";

$(function(){  
		   
	//获取当前语言环境
	i18n_type = "zh";
	if(i18n_type == "zh"){
		constantInfoMap = constantInfoMap_zh;
	}
	if(i18n_type == "en"){
		constantInfoMap = constantInfoMap_en;
	}//待补充
		   	
	//窗口高度
	var winhei=$(window).height();
	//窗口宽度
	var winWid=$(window).width();
	//蓝条高度
 	var pathHei=$(".path_nav").height();
	
	if(pathHei==null){
		pathHei=28;
	}
	//左部宽度
	var leftWid = $(".leftTop").width();
	//左部菜单栏高度
	$(".left_nav").css({"height":winhei-pathHei,"overflow":"auto"});
	//welcome页高度
	$(".pageContent").css("height",winhei-pathHei-40);
	//右部数据高度
	//$(".ltePage").css("height",winhei-pathHei-40);	
	$(".ltePage").css({"height":winhei-pathHei-40,"overflow":"auto"});
	//单表高度
	//$(".tableHeight").css({"height":winhei-pathHei-65,"overflow":"auto"});
	$(".tableHeight").css("height",winhei-pathHei-65);
	//新增配置页面高度
	//$(".ad_Input").css("height",winhei-pathHei-20);
	$(".add_div").css("height",winhei-pathHei);
	$(".ad_Input1").css("height",winhei-pathHei-20);
	//小区表配置
	$("#cocoA").css("margin-left",winWid-leftWid-850);
	//组合表高度
	$("#t_sctp_div").css("height",winhei-pathHei-65);
	$("#t_cel_alg2_div").css("height",winhei-pathHei-65);
	$("#t_cel_para_div").css("height",winhei-pathHei-65);
	$("#t_cel_puch_div").css("height",winhei-pathHei-65);	
	$("#t_cel_prach_div").css("height",winhei-pathHei-65);
	$("#t_cel_ulpc_div").css("height",winhei-pathHei-65);
	$("#t_cel_dlpc_div").css("height",winhei-pathHei-65);
	$("#t_cel_nbrcel_div").css("height",winhei-pathHei-65);
	$("#t_enb_meascfg_div").css("height",winhei-pathHei-65);
	$("#t_enb_srvqos_div").css("height",winhei-pathHei-65);
	$("#t_enb_rlc_div").css("height",winhei-pathHei-65);
	$("#t_enb_ctltmr_div").css("height",winhei-pathHei-65);
	$("#t_enb_uepara_div").css("height",winhei-pathHei-65);
	$("#t_enb_srvpc_div").css("height",winhei-pathHei-65);
	$("#t_cel_resel_div").css("height",winhei-pathHei-65);	
	$("#t_enb_ctfreq_div").css("height",winhei-pathHei-65);	
	$("#t_cel_pdch_div").css("height",winhei-pathHei-65);	
	$("#t_enb_srvmac_div").css("height",winhei-pathHei-65);
	$("#t_enb_srvqci_div").css("height",winhei-pathHei-65);	
	$("#t_cel_ptt_div").css("height",winhei-pathHei-65);
	$("#t_enb_para_div").css("height",winhei-pathHei-65);
	$("#t_cel_alg_div").css("height",winhei-pathHei-65);
	$("#t_cel_drx_div").css("height",winhei-pathHei-65);
	$("#t_enb_pdcp_div").css("height",winhei-pathHei-65);
	$("#t_cel_speed_div").css("height",winhei-pathHei-65);
	$("#t_enb_load_div").css("height",winhei-pathHei-65);
	window.onresize = function(){
		//窗口高度
		var winhei=$(window).height();
		//窗口宽度
		var winWid=$(window).width();
		//蓝条高度
		var pathHei=$(".path_nav").height();
		
		if(pathHei==null){
			pathHei=28;
		}
		//左部宽度
		var leftWid = $(".leftTop").width();
		//左部菜单栏高度
		$(".left_nav").css({"height":winhei-pathHei,"overflow":"auto"});
		//welcome页高度
		$(".pageContent").css("height",winhei-pathHei-40);
		//右部数据高度
		//$(".ltePage").css("height",winhei-pathHei-40);	
		$(".ltePage").css({"height":winhei-pathHei-40,"overflow":"auto"});
		//单表高度
		//$(".tableHeight").css({"height":winhei-pathHei-65,"overflow":"auto"});
		$(".tableHeight").css("height",winhei-pathHei-65);
		//新增配置页面高度
		//$(".ad_Input").css("height",winhei-pathHei-20);
		$(".add_div").css("height",winhei-pathHei);
		$(".ad_Input1").css("height",winhei-pathHei-20);
		//小区表配置
		$("#cocoA").css("margin-left",winWid-leftWid-850);
		//组合表高度
		$("#t_sctp_div").css("height",winhei-pathHei-65);
		$("#t_cel_alg2_div").css("height",winhei-pathHei-65);
		$("#t_cel_para_div").css("height",winhei-pathHei-65);
		$("#t_cel_puch_div").css("height",winhei-pathHei-65);	
		$("#t_cel_prach_div").css("height",winhei-pathHei-65);
		$("#t_cel_ulpc_div").css("height",winhei-pathHei-65);
		$("#t_cel_dlpc_div").css("height",winhei-pathHei-65);
		$("#t_cel_nbrcel_div").css("height",winhei-pathHei-65);
		$("#t_enb_meascfg_div").css("height",winhei-pathHei-65);
		$("#t_enb_srvqos_div").css("height",winhei-pathHei-65);
		$("#t_enb_rlc_div").css("height",winhei-pathHei-65);
		$("#t_enb_srvqci_div").css("height",winhei-pathHei-65);
		$("#t_enb_ctltmr_div").css("height",winhei-pathHei-65);
		$("#t_enb_uepara_div").css("height",winhei-pathHei-65);
		$("#t_enb_srvpc_div").css("height",winhei-pathHei-65);
		$("#t_cel_resel_div").css("height",winhei-pathHei-65);	
		$("#t_enb_ctfreq_div").css("height",winhei-pathHei-65);	
		$("#t_cel_pdch_div").css("height",winhei-pathHei-65);	
		$("#t_enb_srvmac_div").css("height",winhei-pathHei-65);
		$("#t_cel_ptt_div").css("height",winhei-pathHei-65);
		$("#t_enb_para_div").css("height",winhei-pathHei-65);
		$("#t_cel_alg_div").css("height",winhei-pathHei-65);
		$("#t_cel_drx_div").css("height",winhei-pathHei-65);
		$("#t_enb_pdcp_div").css("height",winhei-pathHei-65);
		$("#t_cel_speed_div").css("height",winhei-pathHei-65);
		$("#t_enb_load_div").css("height",winhei-pathHei-65);
	}
	//全选
	$("#checkfather").live("click",function(){
		$("[name=checkson]:checkbox").attr("checked",this.checked);
	});
	$("[name=checkson]:checkbox").live("click",function(){
		var flag=true;
		$("[name=checkson]:checkbox").each(function(){
			if(!this.checked){
				flag=false;
			}
		});
		$("#checkfather").attr("checked",flag);
	});	
});
//根据字段名和字段值选中单选框
function checkRadio(name,value){
	$("input[name='"+name+"']").each(function(){
		var thisValue = $(this).val();
		if(thisValue == value || parseInt(thisValue) == parseInt(value)){
			$(this).attr("checked","checked");
		}
	});
}
//带有参数的信息国际化
//type 提示类别，获取哪条提示消息 
//argments 参数，如"请输入1~10之间的整数"中的1和10
function dynamicInfo(type,argment){
	console.log(argment);
	var info = "";
	if(i18n_type == "zh"){
		//type=10000,input输入数字校验,校验整数
		if(type == 10000){
			info =  "/* 请输入"+argment.min+"~"+argment.max+"之间的整数 */";
		}
		//type=10001,input输入数字校验,校验步长为0.1的小数
		if(type == 10001){
			info =  "/* 请输入"+argment.min+"~"+argment.max+"之间的小数,步长0.1 */";
		}
		//type=10002,input输入数字校验,校验步长为0.01的小数
		if(type == 10002){
			info =  "/* 请输入"+argment.min+"~"+argment.max+"之间的小数,步长0.01 */";
		}
	}
	if(i18n_type == "en"){
		//type=10000,input输入数字校验,校验整数
		if(type == 10000){
			info =  "/* please input an integer between "+argment.min+" and "+argment.max+" */";
		}
		//type=10001,input输入数字校验,校验步长为0.1的小数
		if(type == 10001){
			info =  "/* please input an integer between "+argment.min+" and "+argment.max+",step is 0.1 */";
		}
		//type=10002,input输入数字校验,校验步长为0.01的小数
		if(type == 10002){
			info =  "/* please input an integer between "+argment.min+" and "+argment.max+",step is 0.01 */";
		}
	}//待补充
	return info;
}
//方法顾名思义
function generateArgments_i18n_num(max,min){
	var object = new Object();
	object.max = max;
	object.min = min;
	return object;
}
//根据正则表达式，id，最大值，最小值校验简单的闭区间input提交
function checkInputInForm(regex,id,max,min){
	if(!(regex.test($("#"+id).val()) && $("#"+id).val()<=max  && $("#"+id).val()>=min)){
		return false;
	}else{
		return true;
	}
}
//刷新
function freshTable(tableName){
	window.location.href = "lteBts?operationType=select&target=query&tableName="+tableName;	
}
//同步删除更新表    单主键表 ,argment参数是预留值
function delete_sync(obj,pk,tableName,argment){
	var obj_dom = $(obj);
	var pk_value = obj_dom.parents("tr:first").find("."+pk).text();
	if(confirm(constantInfoMap["confirm_delete_info"])){
		if(argment == "" || argment == null || typeof(argment) == "undefined"){	
			window.location.href="lteBts?operationType=delete&target=single&tableName="+tableName+"&"+pk+"="+pk_value;
		}
	}		
} 
//同步批量删除更新表    单主键表 ,argment参数是预留值
function multiDelete_sync(tableId,pk,tableName,argment){
	var pkArray = [];
	$("#"+tableId+" input[name='checkson']").each(function(){
		if($(this).attr("checked")){
			var pk_value = $(this).parents("tr:first").find("."+pk).text();
			pkArray.push(pk_value);
		}
	});	
	if(pkArray.length < 1){
		alert(constantInfoMap["no_selected_item_info"]);
	}else{
		if(confirm(constantInfoMap["confirm_deleteAll_info"])){
			if(argment == "" || argment == null || typeof(argment) == "undefined"){	
				window.location.href="lteBts?operationType=delete&target=multi&tableName="+tableName+"&"+pk+"="+pkArray;
			}
		}
	}			
} 
function accAdd(arg1,arg2){
	var r1,r2,m;
	try{
		r1 = arg1.toString().split(".")[1].length;	
	}catch(e){
		r1 = 0;	
	}
	try{
		r2 = arg2.toString().split(".")[1].length;	
	}catch(e){
		r2 = 0;	
	}
	m = Math.pow(10,Math.max(r1,r2));
	return (arg1*m + arg2*m)/m;
}
function accSub(arg1,arg2){
	var r1,r2,m,n;
	try{
		r1 = arg1.toString().split(".")[1].length;	
	}catch(e){
		r1 = 0;	
	}
	try{
		r2 = arg2.toString().split(".")[1].length;	
	}catch(e){
		r2 = 0;	
	}
	m = Math.pow(10,Math.max(r1,r2));
	n = (r1>=r2)?r1:r2;
	return ((arg1*m - arg2*m)/m).toFixed(n);
}
function accMul(arg1,arg2){
	var m = 0;
	var s1 = arg1.toString();
	var s2 = arg2.toString();
	try{
		m += s1.split(".")[1].length	;
	}catch(e){}
	try{
		m += s2.split(".")[1].length	;
	}catch(e){}
	return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
}
function accDiv(arg1,arg2){
	var t1 = 0;
	var t2 = 0;
	var r1,r2;
	try{
		t1 = arg1.toString().split(".")[1].length;
	}catch(e){}
	try{
		t2 = arg2.toString().split(".")[1].length;	
	}catch(e){}
	with(Math){
		r1 = Number(arg1.toString().replace(".",""));
		r2 = Number(arg2.toString().replace(".",""));
		return (r1/r2)*pow(10,t2-t1);
	}
}
