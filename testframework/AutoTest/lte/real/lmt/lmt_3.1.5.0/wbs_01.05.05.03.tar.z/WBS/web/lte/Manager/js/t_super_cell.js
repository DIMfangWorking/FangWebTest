$(function(){
	//表单校验
	//整数正则
	var isNum=/^\d+$/;
	$("#submit_add").click(function(){
		var index = 0;
		$(".error").text("");
		if($("#u8SuperCellId option").length < 1){
			index++;
			$("#u8SuperCellIdError").text(constantInfoMap["no_item_exist_info"]);
		}
		var au8SecondaryCellId = "";
		if($("#au8SecondaryCellId_ul li").length <= 1){
			index++;
			$("#au8SecondaryCellIdError").text(constantInfoMap["no_item_exist_info"]);
		}else{
			$("#au8SecondaryCellId_ul input").each(function(){
				if(!$(this).attr("disabled")){
					if($(this).attr("checked")){
						var v = parseInt($(this).val()).toString(16);
						if(v.length != 2){
							v = "0" + v;
						}
						au8SecondaryCellId = au8SecondaryCellId + v;
					}else{
						au8SecondaryCellId = au8SecondaryCellId + "ff";
					}				
				}
			});
			if(au8SecondaryCellId.length != 4){
				au8SecondaryCellId = au8SecondaryCellId + "ff";
			}
			if(au8SecondaryCellId == "ffff"){
				index++;
				$("#au8SecondaryCellIdError").text("/* 请至少选择一个可用的辅小区 */");
			}

		}
		if(!checkInputInForm(isNum,"u8ThrForCp",20,0)){
			index++;
			$("#u8ThrForCpError").text(dynamicInfo(10000,generateArgments_i18n_num(20,0)));
		}
		$("input[name='u8SuperCellId']").val($("#u8SuperCellId").val());
		$("input[name='au8SecondaryCellId']").val(au8SecondaryCellId);
		if(index==0){
			$("#form_add").submit();
		}		
	});
	//内存值转为显示值
	$("#t_super_cell td.au8SecondaryCellId").each(function(){
		var value = $.trim($(this).text());
		if(value != null && value != ""){
			var result = "",
				cellIdArray = value.split("");
			for(var i=0;i<4;i=i+2){
				result = result + parseInt(""+cellIdArray[i]+cellIdArray[i+1],16)+",";
			}
			result = result.substring(0, result.length-1);
		}
		$(this).text(result);
	});
	
	$("#t_super_cell td.u8UlSDMASwitch").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("关闭");
			break;
		case "1":
			$(this).text("打开");
			break;
		}	
	});
	$("#t_super_cell td.u32Status").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("正常");
			break;
		case "1":
			$(this).text("不正常");
			break;
		}	
	});	
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_super_cell"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_super_cell"
	});
});
function setCellId(u8SuperCellId){
	$("#au8SecondaryCellId_ul input").each(function(){
		if($(this).val() == u8SuperCellId){
			$(this).attr("disabled","disabled");
			$(this).attr("checked",false);
		}else{
			$(this).attr("disabled",false);
		}
	});
}
