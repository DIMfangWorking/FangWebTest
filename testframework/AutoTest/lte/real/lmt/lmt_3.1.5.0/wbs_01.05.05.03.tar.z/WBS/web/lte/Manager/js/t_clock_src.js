$(function(){
	$("#submit_add").click(function(){
		if($("#u8ClockSrc_hidden").val() != $("input[name='u8ClockSrc']:checked").val()){
			alert("修改时钟源可能出现暂时的单板状态故障以及小区退服");
		}
		$("#form_add").submit();	
	});
	//内存值转为显示值
	$("#t_clock_src td.u8ClockSrc").each(function(){
		var value = $.trim($(this).text());
		switch (value){
		case "0":
			$(this).text("GPS");
			break;
		case "1":
			$(this).text("北斗");
			break;
		}	
	});
	//取消按钮
	$("#cancel").click(function(){
		window.location.href="../../cgi-bin/lteBts?operationType=select&target=query&tableName=t_clock_src"
	});
	$("#cancelx").click(function(){
		window.location.href="lteBts?operationType=select&target=query&tableName=t_clock_src"
	});
});

